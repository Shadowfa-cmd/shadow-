'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const env = require('./env');

function int(value, fallback, min, max) {
  const n = Number.parseInt(value, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function loadSecret(dataDir) {
  const file = path.join(dataDir, 'secret.key');
  try {
    const existing = fs.readFileSync(file, 'utf8').trim();
    if (existing.length >= 32) return existing;
  } catch { /* create below */ }
  const secret = crypto.randomBytes(48).toString('hex');
  fs.writeFileSync(file, secret, { mode: 0o600 });
  return secret;
}

/**
 * Build the runtime configuration. `overrides` is used by the tests.
 * Throws a readable Error if the configuration is unsafe.
 */
function buildConfig(overrides = {}) {
  env.load();
  const e = process.env;
  const cfg = {
    port: int(e.PORT, 3000, 0, 65535),
    host: e.HOST || '0.0.0.0',
    dataDir: path.resolve(e.DATA_DIR || path.join(__dirname, '..', 'data')),
    adminUsername: (e.ADMIN_USERNAME || 'admin').trim(),
    adminPassword: e.ADMIN_PASSWORD || '',
    jwtSecret: e.JWT_SECRET || '',
    groupName: (e.GROUP_NAME || 'Shadow').trim().slice(0, 40) || 'Shadow',
    maxOnline: int(e.MAX_ONLINE, 100, 1, 1000),
    maxStoredMessages: int(e.MAX_STORED_MESSAGES, 1000, 50, 20000),
    tokenTtlDays: int(e.TOKEN_TTL_DAYS, 30, 1, 365),
    corsOrigin: e.CORS_ORIGIN || '*',
    trustProxy: e.TRUST_PROXY === '1' || e.TRUST_PROXY === 'true',
    serveFrontend: e.SERVE_FRONTEND !== '0' && e.SERVE_FRONTEND !== 'false',
    frontendDir: path.resolve(e.FRONTEND_DIR || path.join(__dirname, '..', '..', 'frontend', 'www')),
    ...overrides,
  };

  if (!/^[A-Za-z0-9_.]{3,24}$/.test(cfg.adminUsername)) {
    throw new Error('ADMIN_USERNAME must be 3-24 characters: letters, digits, "_" or ".".');
  }
  if (!cfg.adminPassword || cfg.adminPassword.length < 8) {
    throw new Error('ADMIN_PASSWORD is required and must be at least 8 characters (set it in .env).');
  }
  if (cfg.adminPassword === 'change-me-to-a-strong-password') {
    throw new Error('Please change ADMIN_PASSWORD in .env - the example value is not allowed.');
  }

  fs.mkdirSync(cfg.dataDir, { recursive: true });
  if (!cfg.jwtSecret) cfg.jwtSecret = loadSecret(cfg.dataDir);
  if (cfg.jwtSecret.length < 16) throw new Error('JWT_SECRET must be at least 16 characters.');
  return cfg;
}

module.exports = { buildConfig };
