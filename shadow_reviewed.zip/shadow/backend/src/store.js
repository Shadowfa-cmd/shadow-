'use strict';
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

/**
 * Tiny JSON-file persistence with atomic writes and debounced saving.
 * Everything lives in memory; at <=100 concurrent users this is more than enough.
 */
class Store {
  constructor(dir, { maxMessages = 1000 } = {}) {
    this.file = path.join(dir, 'shadow-data.json');
    this.tmp = `${this.file}.tmp`;
    this.maxMessages = maxMessages;
    this.data = { version: 1, users: [], messages: [] };
    this.byId = new Map();
    this.byName = new Map();
    this._timer = null;
    this._writing = false;
    this._again = false;
    this._load();
  }

  _load() {
    let raw;
    try {
      raw = fs.readFileSync(this.file, 'utf8');
    } catch (err) {
      if (err.code === 'ENOENT') return;
      throw err;
    }
    try {
      const parsed = JSON.parse(raw);
      this.data.users = Array.isArray(parsed.users) ? parsed.users : [];
      this.data.messages = Array.isArray(parsed.messages) ? parsed.messages : [];
    } catch {
      const backup = `${this.file}.corrupt-${Date.now()}`;
      fs.renameSync(this.file, backup);
      console.error(`[store] data file was corrupt; moved to ${backup} and started empty.`);
    }
    for (const u of this.data.users) this._index(u);
  }

  _index(u) {
    this.byId.set(u.id, u);
    this.byName.set(u.username.toLowerCase(), u);
  }

  getUser(id) { return this.byId.get(id) || null; }
  findByUsername(name) { return this.byName.get(String(name).toLowerCase()) || null; }
  get users() { return this.data.users; }

  addUser(user) {
    this.data.users.push(user);
    this._index(user);
    this.save();
    return user;
  }

  renameUsername(user, newName) {
    this.byName.delete(user.username.toLowerCase());
    user.username = newName;
    this.byName.set(newName.toLowerCase(), user);
    this.save();
  }

  removeUser(id) {
    const u = this.byId.get(id);
    if (!u) return null;
    this.byId.delete(id);
    this.byName.delete(u.username.toLowerCase());
    this.data.users = this.data.users.filter((x) => x.id !== id);
    this.save();
    return u;
  }

  addMessage(msg) {
    const list = this.data.messages;
    list.push(msg);
    if (list.length > this.maxMessages) list.splice(0, list.length - this.maxMessages);
    this.save();
    return msg;
  }

  removeMessage(id) {
    const i = this.data.messages.findIndex((m) => m.id === id);
    if (i === -1) return false;
    this.data.messages.splice(i, 1);
    this.save();
    return true;
  }

  removeMessagesByUser(userId) {
    const ids = [];
    this.data.messages = this.data.messages.filter((m) => {
      if (m.userId === userId) { ids.push(m.id); return false; }
      return true;
    });
    if (ids.length) this.save();
    return ids;
  }

  recentMessages(n = 200) { return this.data.messages.slice(-n); }

  save() {
    if (this._timer) return;
    this._timer = setTimeout(() => { this._timer = null; this._write(); }, 150);
  }

  async _write() {
    if (this._writing) { this._again = true; return; }
    this._writing = true;
    try {
      await fsp.writeFile(this.tmp, JSON.stringify(this.data));
      await fsp.rename(this.tmp, this.file);
    } catch (err) {
      console.error('[store] save failed:', err.message);
    } finally {
      this._writing = false;
      if (this._again) { this._again = false; this._write(); }
    }
  }

  /** Synchronous flush used on shutdown. */
  flushSync() {
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    try {
      fs.writeFileSync(this.tmp, JSON.stringify(this.data));
      fs.renameSync(this.tmp, this.file);
    } catch (err) {
      console.error('[store] final save failed:', err.message);
    }
  }
}

module.exports = { Store };
