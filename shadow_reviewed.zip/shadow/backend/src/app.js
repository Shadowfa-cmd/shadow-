'use strict';
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');

const { Store } = require('./store');
const { Hub } = require('./hub');
const { createLimiter } = require('./ratelimit');
const { hashPassword, verifyPassword, createTokens, createTickets } = require('./auth');
const v = require('./validate');
const { HttpError, sendJson, readJson, serveStatic } = require('./http-utils');

const DUMMY_HASH = `${'0'.repeat(32)}:${'0'.repeat(128)}`;

async function createApp(config) {
  const store = new Store(config.dataDir, { maxMessages: config.maxStoredMessages });
  const hub = new Hub({ maxOnline: config.maxOnline });
  const tokens = createTokens(config.jwtSecret, config.tokenTtlDays);
  const tickets = createTickets();

  const loginIpLimit = createLimiter({ max: 30, windowMs: 10 * 60 * 1000 });
  const loginNameLimit = createLimiter({ max: 10, windowMs: 10 * 60 * 1000 });
  const registerLimit = createLimiter({ max: 30, windowMs: 60 * 60 * 1000 });
  const messageLimit = createLimiter({ max: 8, windowMs: 10 * 1000 });
  const streamTicketLimit = createLimiter({ max: 20, windowMs: 60 * 1000 });
  const editLimit = createLimiter({ max: 10, windowMs: 10 * 60 * 1000 });
  // Password hashing is asynchronous; reserve usernames before awaiting it so
  // simultaneous sign-ups cannot create duplicate case-insensitive usernames.
  const registeringUsernames = new Set();
  const limiters = [loginIpLimit, loginNameLimit, registerLimit, messageLimit, streamTicketLimit, editLimit];

  /* ---------- admin account (single, from .env) ---------- */
  async function ensureAdmin() {
    let admin = store.users.find((u) => u.role === 'admin');
    if (!admin) {
      const clash = store.findByUsername(config.adminUsername);
      if (clash) throw new Error(`ADMIN_USERNAME "${config.adminUsername}" is already used by a normal user.`);
      admin = store.addUser({
        id: 'admin',
        username: config.adminUsername,
        displayName: config.adminUsername,
        passwordHash: await hashPassword(config.adminPassword),
        role: 'admin',
        banned: false,
        tokenVersion: 0,
        createdAt: Date.now(),
      });
      return;
    }
    if (admin.username.toLowerCase() !== config.adminUsername.toLowerCase()) {
      const clash = store.findByUsername(config.adminUsername);
      if (clash && clash.id !== admin.id) throw new Error(`ADMIN_USERNAME "${config.adminUsername}" is already used by a normal user.`);
      store.renameUsername(admin, config.adminUsername);
    }
    if (!(await verifyPassword(config.adminPassword, admin.passwordHash))) {
      admin.passwordHash = await hashPassword(config.adminPassword);
      const version = Number.isSafeInteger(admin.tokenVersion) && admin.tokenVersion >= 0
        ? admin.tokenVersion : 0;
      admin.tokenVersion = version + 1;
      store.save();
    }
  }
  await ensureAdmin();

  /* ---------- helpers ---------- */
  const publicUser = (u) => ({ id: u.id, username: u.username, displayName: u.displayName, role: u.role });
  const publicMessage = (m) => ({ id: m.id, userId: m.userId, name: m.name, text: m.text, kind: m.kind, ts: m.ts });

  function clientIp(req) {
    if (config.trustProxy) {
      const xff = req.headers['x-forwarded-for'];
      if (xff) return String(xff).split(',')[0].trim();
    }
    return req.socket.remoteAddress || 'unknown';
  }

  function authenticate(req) {
    const header = req.headers.authorization || '';
    const claims = header.startsWith('Bearer ') ? tokens.verify(header.slice(7)) : null;
    const user = claims ? store.getUser(claims.sub) : null;
    const version = user && Number.isSafeInteger(user.tokenVersion) && user.tokenVersion >= 0
      ? user.tokenVersion : 0;
    if (!user || claims.version !== version) throw new HttpError(401, 'unauthorized');
    if (user.banned) throw new HttpError(403, 'banned');
    return user;
  }

  function requireAdmin(req) {
    const user = authenticate(req);
    if (user.role !== 'admin') throw new HttpError(403, 'forbidden');
    return user;
  }

  function limit(limiter, key) {
    const retry = limiter.hit(key);
    if (retry) {
      const err = new HttpError(429, 'rate_limited');
      err.retryAfter = retry;
      throw err;
    }
  }

  function newMessage(user, text, kind) {
    return store.addMessage({
      id: crypto.randomUUID(),
      userId: user.id,
      name: user.displayName,
      text,
      kind,
      ts: Date.now(),
    });
  }

  /* ---------- route handlers ---------- */
  const routes = [];
  const route = (method, pattern, handler) => {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:([a-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method, re, keys, handler });
  };

  route('GET', '/api/health', async (ctx) => sendJson(ctx.res, 200, { ok: true, online: hub.onlineCount }));

  route('GET', '/api/config', async (ctx) =>
    sendJson(ctx.res, 200, { groupName: config.groupName, maxOnline: config.maxOnline }));

  route('POST', '/api/auth/register', async (ctx) => {
    limit(registerLimit, ctx.ip);
    const body = await readJson(ctx.req);
    const username = v.username(body.username);
    if (!username) throw new HttpError(400, 'invalid_username');
    const password = v.password(body.password);
    if (!password) throw new HttpError(400, 'invalid_password');
    const displayName = v.displayName(body.displayName ?? body.username);
    if (!displayName) throw new HttpError(400, 'invalid_display_name');
    const usernameKey = username.toLowerCase();
    if (store.findByUsername(usernameKey) || registeringUsernames.has(usernameKey)) {
      throw new HttpError(409, 'username_taken');
    }

    registeringUsernames.add(usernameKey);
    try {
      const user = store.addUser({
        id: crypto.randomUUID(),
        username,
        displayName,
        passwordHash: await hashPassword(password),
        role: 'user',
        banned: false,
        tokenVersion: 0,
        createdAt: Date.now(),
      });
      sendJson(ctx.res, 201, { token: tokens.issue(user.id, user.tokenVersion || 0), user: publicUser(user) });
    } finally {
      registeringUsernames.delete(usernameKey);
    }
  });

  route('POST', '/api/auth/login', async (ctx) => {
    limit(loginIpLimit, ctx.ip);
    const body = await readJson(ctx.req);
    const name = String(body.username ?? '').trim().toLowerCase().slice(0, 40);
    const password = String(body.password ?? '').slice(0, 128);
    limit(loginNameLimit, name);
    const user = store.findByUsername(name);
    const ok = await verifyPassword(password, user ? user.passwordHash : DUMMY_HASH);
    if (!user || !ok) throw new HttpError(401, 'invalid_credentials');
    if (user.banned) throw new HttpError(403, 'banned');
    sendJson(ctx.res, 200, { token: tokens.issue(user.id, user.tokenVersion || 0), user: publicUser(user) });
  });

  route('GET', '/api/me', async (ctx) => {
    const user = authenticate(ctx.req);
    sendJson(ctx.res, 200, { user: publicUser(user) });
  });

  route('PATCH', '/api/me', async (ctx) => {
    const user = authenticate(ctx.req);
    limit(editLimit, user.id);
    const body = await readJson(ctx.req);
    const displayName = v.displayName(body.displayName);
    if (!displayName) throw new HttpError(400, 'invalid_display_name');
    user.displayName = displayName;
    store.save();
    hub.rename(user.id, displayName);
    sendJson(ctx.res, 200, { user: publicUser(user) });
  });

  route('POST', '/api/stream-ticket', async (ctx) => {
    const user = authenticate(ctx.req);
    // Bound pending tickets as well as active streams to resist resource exhaustion.
    if (!hub.canAccept(user.id)) {
      throw new HttpError(503, hub.isOnline(user.id) ? 'too_many_connections' : 'server_full');
    }
    limit(streamTicketLimit, user.id);
    sendJson(ctx.res, 200, { ticket: tickets.issue(user.id) });
  });

  route('GET', '/api/stream', async (ctx) => {
    const userId = tickets.consume(ctx.url.searchParams.get('ticket') || '');
    const user = userId ? store.getUser(userId) : null;
    if (!user) throw new HttpError(401, 'unauthorized');
    if (user.banned) throw new HttpError(403, 'banned');
    if (!hub.canAccept(user.id)) {
      throw new HttpError(503, hub.isOnline(user.id) ? 'too_many_connections' : 'server_full');
    }

    const { req, res } = ctx;
    req.socket.setTimeout(0);
    req.socket.setNoDelay(true);
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.write('retry: 3000\n\n');
    hub.send(res, 'init', {
      me: publicUser(user),
      groupName: config.groupName,
      messages: store.recentMessages(200).map(publicMessage),
      presence: hub.presence(),
    });
    hub.add(user, res);
    req.on('close', () => hub.remove(user.id, res));
  });

  route('POST', '/api/messages', async (ctx) => {
    const user = authenticate(ctx.req);
    limit(messageLimit, user.id);
    const body = await readJson(ctx.req);
    const text = v.messageText(body.text);
    if (!text) throw new HttpError(400, 'invalid_message');
    const msg = publicMessage(newMessage(user, text, 'text'));
    hub.broadcast('message', msg);
    sendJson(ctx.res, 201, { message: msg });
  });

  /* ----- admin ----- */
  route('GET', '/api/admin/users', async (ctx) => {
    requireAdmin(ctx.req);
    const users = store.users.map((u) => ({
      id: u.id,
      username: u.username,
      displayName: u.displayName,
      role: u.role,
      banned: !!u.banned,
      online: hub.isOnline(u.id),
      createdAt: u.createdAt,
    }));
    sendJson(ctx.res, 200, { users, online: hub.onlineCount, total: users.length });
  });

  function targetUser(id) {
    const user = store.getUser(id);
    if (!user) throw new HttpError(404, 'not_found');
    if (user.role === 'admin') throw new HttpError(400, 'cannot_target_admin');
    return user;
  }

  route('POST', '/api/admin/users/:id/ban', async (ctx) => {
    requireAdmin(ctx.req);
    const user = targetUser(ctx.params.id);
    user.banned = true;
    store.save();
    hub.kick(user.id, 'banned');
    sendJson(ctx.res, 200, { ok: true });
  });

  route('POST', '/api/admin/users/:id/unban', async (ctx) => {
    requireAdmin(ctx.req);
    const user = targetUser(ctx.params.id);
    user.banned = false;
    store.save();
    sendJson(ctx.res, 200, { ok: true });
  });

  route('DELETE', '/api/admin/users/:id', async (ctx) => {
    requireAdmin(ctx.req);
    const user = targetUser(ctx.params.id);
    hub.kick(user.id, 'removed');
    store.removeUser(user.id);
    const ids = store.removeMessagesByUser(user.id);
    if (ids.length) hub.broadcast('messages_removed', { ids });
    sendJson(ctx.res, 200, { ok: true });
  });

  route('DELETE', '/api/admin/messages/:id', async (ctx) => {
    requireAdmin(ctx.req);
    if (!store.removeMessage(ctx.params.id)) throw new HttpError(404, 'not_found');
    hub.broadcast('messages_removed', { ids: [ctx.params.id] });
    sendJson(ctx.res, 200, { ok: true });
  });

  route('POST', '/api/admin/announcements', async (ctx) => {
    const admin = requireAdmin(ctx.req);
    const body = await readJson(ctx.req);
    const text = v.messageText(body.text);
    if (!text) throw new HttpError(400, 'invalid_message');
    const msg = publicMessage(newMessage(admin, text, 'announcement'));
    hub.broadcast('message', msg);
    sendJson(ctx.res, 201, { message: msg });
  });

  /* ---------- HTTP server ---------- */
  function corsHeaders(req) {
    const allowed = config.corsOrigin;
    const origin = req.headers.origin;
    let allow = null;
    if (allowed === '*') allow = '*';
    else if (origin && allowed.split(',').map((s) => s.trim()).includes(origin)) allow = origin;
    if (!allow) return {};
    return {
      'Access-Control-Allow-Origin': allow,
      'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Authorization,Content-Type',
      'Access-Control-Max-Age': '86400',
      Vary: 'Origin',
    };
  }

  const frontendReady = config.serveFrontend && fs.existsSync(config.frontendDir);

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const isApi = url.pathname.startsWith('/api/');

    try {
      if (isApi) {
        const cors = corsHeaders(req);
        for (const [k, val] of Object.entries(cors)) res.setHeader(k, val);
        res.setHeader('X-Content-Type-Options', 'nosniff');
        if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

        for (const r of routes) {
          if (r.method !== req.method) continue;
          const m = r.re.exec(url.pathname);
          if (!m) continue;
          const params = {};
          r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
          return await r.handler({ req, res, url, params, ip: clientIp(req) });
        }
        throw new HttpError(404, 'not_found');
      }

      if (frontendReady && (req.method === 'GET' || req.method === 'HEAD')) {
        if (serveStatic(config.frontendDir, url.pathname, res)) return;
        if (serveStatic(config.frontendDir, '/', res)) return;
      }
      throw new HttpError(404, 'not_found');
    } catch (err) {
      if (res.headersSent) { res.destroy(); return; }
      if (err instanceof HttpError) {
        const headers = err.status === 429
          ? { 'Retry-After': String(Math.max(1, err.retryAfter || 30)) }
          : {};
        return sendJson(res, err.status, { error: err.code }, headers);
      }
      console.error('[error]', err);
      sendJson(res, 500, { error: 'server_error' });
    }
  });

  server.keepAliveTimeout = 65000;
  server.headersTimeout = 70000;

  async function close() {
    hub.close();
    limiters.forEach((l) => l.stop());
    tickets.stop();
    store.flushSync();
    await new Promise((resolve) => {
      server.close(() => resolve());
      server.closeAllConnections?.();
    });
  }

  return { server, store, hub, close, frontendReady };
}

module.exports = { createApp };
