# Shadow

پیام‌رسان سبک با **یک گروه عمومی**، حداکثر **۱۰۰ کاربر هم‌زمان**، فقط **پیام متنی**، یک **ادمین اصلی**، تم تیره (مشکی/خاکستری/بنفش) و پشتیبانی کامل از **فارسی، دری، عربی و انگلیسی** (RTL/LTR).

```
shadow/
├── backend/      سرور Node.js (بدون وابستگی خارجی، فقط خود Node)
│   ├── server.js
│   ├── src/      config, store, auth, hub (SSE), ratelimit, validate, app (API)
│   ├── test/     تست‌های یکپارچه (npm test)
│   └── .env.example
└── frontend/     وب‌اپ (ES modules خالص) + پوستهٔ Capacitor برای APK
    ├── src/      index.html, css/, js/
    ├── www/      خروجی Build (از قبل ساخته شده)
    ├── scripts/build.js
    └── capacitor.config.json
```

Backend و Frontend کاملاً جدا هستند و فقط از طریق API ‏(`/api/*`) صحبت می‌کنند.
در حالت پیش‌فرض سرور خروجی Build فرانت‌اند را هم سرو می‌کند تا فقط یک پروسه برای اجرا لازم باشد.

---

## اجرای سریع (لینوکس / VPS / Termux)

نیازمند **Node.js 18 یا بالاتر**.

```bash
cd backend
cp .env.example .env
nano .env            # ADMIN_USERNAME و ADMIN_PASSWORD را حتماً تنظیم کنید
node server.js       # یا: npm start
```

سپس `http://IP-SERVER:3000` را باز کنید. با نام کاربری/رمز ادمین وارد شوید.

نکته‌ها:
- اگر `ADMIN_PASSWORD` تنظیم نشده یا کمتر از ۸ نویسه باشد یا همان مقدار نمونه باشد، سرور با پیام روشن بالا نمی‌آید.
- `JWT_SECRET` اختیاری است؛ اگر خالی بماند یک کلید تصادفی در `DATA_DIR/secret.key` ساخته و ذخیره می‌شود.
- با هر بار اجرا، حساب ادمین از روی `.env` ساخته/به‌روز می‌شود. **برای تغییر رمز ادمین کافی است `ADMIN_PASSWORD` را عوض و سرور را ری‌استارت کنید.**
- فقط یک ادمین وجود دارد؛ راهی برای ثبت‌نام ادمین دوم نیست.

### متغیرهای `.env`

| متغیر | پیش‌فرض | توضیح |
|---|---|---|
| `PORT` / `HOST` | `3000` / `0.0.0.0` | آدرس شنود |
| `ADMIN_USERNAME` | `admin` | نام کاربری ادمین (حروف انگلیسی، عدد، `_` `.`) |
| `ADMIN_PASSWORD` | — (الزامی) | رمز ادمین، حداقل ۸ نویسه |
| `JWT_SECRET` | خودکار | کلید امضای توکن |
| `DATA_DIR` | `./data` | محل ذخیرهٔ کاربران و پیام‌ها |
| `GROUP_NAME` | `Shadow` | نام گروه |
| `MAX_ONLINE` | `100` | سقف کاربران هم‌زمان آنلاین |
| `MAX_STORED_MESSAGES` | `1000` | تعداد پیام‌های نگهداری‌شده |
| `TOKEN_TTL_DAYS` | `30` | مدت اعتبار ورود |
| `CORS_ORIGIN` | `*` | مبدأهای مجاز (برای APK مقدار `*` مناسب است) |
| `TRUST_PROXY` | `0` | پشت nginx/Caddy/پروکسی هاست مقدار `1` بگذارید |
| `SERVE_FRONTEND` | `1` | سرو کردن `frontend/www` از همین سرور |

---

## استقرار روی VPS (پیشنهادی: systemd + HTTPS)

۱. فایل‌ها را در `/opt/shadow` بگذارید و `.env` را در `/opt/shadow/backend/.env` بسازید.

۲. سرویس systemd — فایل `/etc/systemd/system/shadow.service`:

```ini
[Unit]
Description=Shadow messenger
After=network.target

[Service]
WorkingDirectory=/opt/shadow/backend
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=3
User=www-data
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

```bash
chown -R www-data /opt/shadow/backend/data   # یا پوشهٔ DATA_DIR
systemctl daemon-reload && systemctl enable --now shadow
journalctl -u shadow -f
```

۳. HTTPS با Caddy (گواهی خودکار) — فایل `Caddyfile`:

```
chat.example.com {
    reverse_proxy 127.0.0.1:3000 {
        flush_interval -1
    }
}
```

و در `.env` مقدار `TRUST_PROXY=1` بگذارید.
اگر از nginx استفاده می‌کنید برای مسیر `/api/stream` حتماً `proxy_buffering off;` و `proxy_read_timeout 1h;` تنظیم کنید (اتصال زنده از نوع SSE است).

## استقرار روی هاست Node.js (مثل WispByte)

۱. کل پوشهٔ پروژه را آپلود کنید (پوشهٔ `frontend/www` از قبل Build شده است).
۲. Startup command را روی `node backend/server.js` (یا `npm start`) بگذارید.
۳. در بخش Environment/Variables پنل، حداقل `ADMIN_USERNAME` و `ADMIN_PASSWORD` را تعریف کنید و اگر پنل پورت می‌دهد `PORT` را همان بگذارید. اگر پنل متغیر محیطی ندارد، فایل `backend/.env` را بسازید.
۴. `TRUST_PROXY=1` را فعال کنید.
۵. اگر هاست دیسک پایدار ندارد، `DATA_DIR` را روی مسیر پایدار بگذارید؛ وگرنه با هر دیپلوی کاربران و پیام‌ها پاک می‌شوند.

---

## ساخت APK

اپ اندروید همان فرانت‌اند است که با **Capacitor** بسته‌بندی می‌شود. APK به یک **آدرس سرور** نیاز دارد (چون خودش سرور ندارد). برای کاربران واقعی از **HTTPS** استفاده کنید؛ فرمان APK فقط URL با `https://` را می‌پذیرد و cleartext در تنظیمات اندروید غیرفعال است تا رمز، توکن و پیام‌ها از راه HTTP ارسال نشوند.

پیش‌نیاز: Node 18+، **JDK 17**، **Android SDK** (یا Android Studio) و متغیر `ANDROID_HOME`.

```bash
cd frontend
cp .env.example .env
nano .env                      # SHADOW_API_URL=https://chat.example.com

npm install
npm run cap:add                # فقط بار اول: پروژهٔ android/ ساخته می‌شود
npm run apk:debug              # Build + sync + gradle assembleDebug
```

خروجی: `frontend/android/app/build/outputs/apk/debug/app-debug.apk`

- آیکن و اسپلش (اختیاری): `npx @capacitor/assets generate --android` (فایل‌های اولیه در `frontend/resources/` آماده‌اند).
- نسخهٔ Release: `npm run apk:release` و سپس امضای APK با keystore خودتان (`apksigner`) یا ساخت AAB از Android Studio.
- فرمان APK اکنون اگر `SHADOW_API_URL` خالی باشد پیش از بازسازی فایل‌ها متوقف می‌شود؛ این کار جلوی APK ظاهراً ساخته‌شده‌ای را می‌گیرد که به سرور وصل نمی‌شود.
- هر حساب حداکثر ۵ اتصال زندهٔ هم‌زمان دارد تا یک حساب نتواند با بازکردن تعداد نامحدود اتصال، سرور را تحت فشار بگذارد؛ درخواست ساخت تیکت اتصال نیز محدود شده است.
- برای آزمایش موقت با سرور HTTP باید تنظیمات توسعه را آگاهانه و جدا از نسخهٔ انتشار تغییر دهید؛ APK پیش‌فرض به سرور HTTPS نیاز دارد.

---

## امکانات

**کاربر:** ثبت‌نام، ورود، ویرایش نام نمایشی، خروج، مشاهدهٔ کاربران آنلاین، ارسال پیام متنی در تنها گروه.
**ادمین:** حذف کاربر (با پیام‌هایش)، بن، رفع بن، حذف پیام، مشاهدهٔ تعداد آنلاین‌ها، ارسال اطلاعیه برای همه.
**امنیت و پایداری:** رمزها با scrypt هش می‌شوند؛ توکن امضاشده با انقضا و ابطال نشست‌های قبلی ادمین هنگام چرخش رمز؛ اتصال زنده با تیکت یک‌بارمصرف (توکن اصلی هرگز در URL نمی‌آید)؛ محدودیت نرخ برای ورود/ثبت‌نام/پیام/تیکت اتصال و سقف ۵ اتصال برای هر حساب؛ پاک‌سازی نویسه‌های کنترلی و بیدی‌ریشنال (برای جلوگیری از جعل/وارونه‌نمایی متن)؛ همهٔ متن‌ها فقط با `textContent` رندر می‌شوند (بدون XSS)؛ ذخیره‌سازی اتمی؛ بازاتصال خودکار با backoff.

## تست

```bash
npm test          # ۱۱ تست یکپارچهٔ بک‌اند (ثبت‌نام هم‌زمان، توکن، SSE، محدودیت نرخ، ادمین، ماندگاری)
```

## محدودیت‌های آگاهانهٔ نسخهٔ اول (MVP)

- ذخیره‌سازی در یک فایل JSON است؛ برای ≤۱۰۰ کاربر کافی و ساده است. اجرای بیش از یک پروسه/نمونه از سرور پشتیبانی نمی‌شود.
- نام فرستنده در هر پیام هنگام ارسال ذخیره می‌شود؛ تغییر نام نمایشی روی پیام‌های قبلی اثر نمی‌گذارد.
- اعلان Push وجود ندارد (فقط وقتی اپ باز است پیام زنده می‌رسد).
- متن‌های دری بر پایهٔ فارسی با واژگان دری نوشته شده‌اند؛ بازبینی توسط یک دری‌زبان توصیه می‌شود (فایل `frontend/src/js/i18n.js`).
