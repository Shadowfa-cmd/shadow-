import { api, session, ApiError } from './api.js';
import { initLang, applyLanguage, t, errorText, getLocale } from './i18n.js';
import { createStream } from './stream.js';
import { h, icons, toast, confirmDialog, closeAllSheets } from './ui.js';
import { languageChips, openOnlineSheet, openSettingsSheet, openAdminSheet } from './sheets.js';

const $ = (id) => document.getElementById(id);
const MAX_DOM_MESSAGES = 400;

const state = {
  me: null,
  groupName: 'Shadow',
  presence: { count: 0, users: [] },
  ids: new Set(),
  messages: [],
  status: 'connecting',
  mode: 'login',
  sending: false,
};

let stream = null;
let onlineSheet = null;
let adminSheet = null;

/* ---------------- views ---------------- */
function showView(name) {
  $('auth').hidden = name !== 'auth';
  $('chat').hidden = name !== 'chat';
}

/* ---------------- auth ---------------- */
function setMode(mode) {
  state.mode = mode;
  document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('active', b.dataset.mode === mode));
  document.querySelectorAll('.reg-only').forEach((el) => { el.hidden = mode !== 'register'; });
  $('authSubmit').textContent = t(mode === 'login' ? 'auth.login' : 'auth.register');
  $('fPassword').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
  $('authHint').textContent = `${t('auth.usernameHint')} · ${t('auth.passwordHint')}`;
  showAuthError('');
}

function showAuthError(text) {
  $('authError').hidden = !text;
  $('authError').textContent = text || '';
}

async function submitAuth(e) {
  e.preventDefault();
  const username = $('fUsername').value.trim();
  const password = $('fPassword').value;
  if (!username || !password) return;
  const btn = $('authSubmit');
  btn.disabled = true;
  showAuthError('');
  try {
    const body = { username, password };
    if (state.mode === 'register') body.displayName = $('fDisplay').value.trim() || username;
    const { token, user } = await api('POST', `/api/auth/${state.mode}`, body);
    session.token = token;
    $('fPassword').value = '';
    enterChat(user);
  } catch (err) {
    showAuthError(errorText(err instanceof ApiError ? err.code : 'generic'));
  } finally {
    btn.disabled = false;
  }
}

function logout(message) {
  stream?.stop();
  stream = null;
  closeAllSheets();
  session.token = '';
  state.me = null;
  state.ids.clear();
  state.messages = [];
  state.presence = { count: 0, users: [] };
  $('messages').replaceChildren();
  showView('auth');
  setMode('login');
  showAuthError(message || '');
}

/* ---------------- chat ---------------- */
function enterChat(user) {
  state.me = user;
  state.ids.clear();
  state.messages = [];
  $('messages').replaceChildren();
  $('adminBtn').hidden = user.role !== 'admin';
  updateHeader();
  setStatus('connecting');
  showView('chat');

  stream?.stop();
  stream = createStream({
    onStatus: setStatus,
    onInit: (d) => {
      state.me = d.me;
      state.groupName = d.groupName;
      state.ids.clear();
      state.messages = [];
      d.messages.forEach((m) => { state.ids.add(m.id); state.messages.push(m); });
      state.presence = d.presence;
      updateHeader();
      renderAll();
    },
    onMessage: (m) => addMessage(m),
    onMessagesRemoved: ({ ids }) => removeMessages(ids),
    onPresence: (p) => {
      state.presence = p;
      updateHeader();
      onlineSheet?.refresh?.();
      adminSheet?.refresh?.();
    },
    onKick: ({ reason }) => logout(t(reason === 'removed' ? 'kick.removed' : 'kick.banned')),
    onAuthError: (code) => logout(code === 'banned' ? t('kick.banned') : t('err.unauthorized')),
    onFull: () => toast(t('err.server_full')),
    onConnectionLimit: () => toast(t('chat.connectionLimit')),
  });
  stream.start();
}

function setStatus(status) {
  state.status = status;
  const bar = $('statusBar');
  bar.hidden = status === 'online';
  const statusKey = status === 'connecting'
    ? 'chat.connecting'
    : status === 'connectionLimit' ? 'chat.connectionLimit' : 'chat.reconnecting';
  bar.textContent = t(statusKey);
  $('onlineBtn').classList.toggle('offline', status !== 'online');
}

function updateHeader() {
  $('groupName').textContent = state.groupName;
  $('onlineText').textContent = t('chat.online', { n: new Intl.NumberFormat(getLocale()).format(state.presence.count) });
}

function formatTime(ts) {
  const d = new Date(ts);
  const sameDay = d.toDateString() === new Date().toDateString();
  try {
    return new Intl.DateTimeFormat(getLocale(), sameDay
      ? { hour: '2-digit', minute: '2-digit' }
      : { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(d);
  } catch {
    return d.toLocaleTimeString();
  }
}

function buildMessage(m, prev) {
  const isAdmin = state.me?.role === 'admin';
  const delBtn = isAdmin
    ? h('button', { class: 'del', type: 'button', 'aria-label': t('chat.deleteMessage'), html: icons.trash, onclick: async () => {
        if (!(await confirmDialog(t('admin.confirmMessage'), { danger: true }))) return;
        try { await api('DELETE', `/api/admin/messages/${m.id}`); } catch (err) { toast(errorText(err instanceof ApiError ? err.code : 'generic')); }
      } })
    : null;

  if (m.kind === 'announcement') {
    return h('div', { class: 'announce', 'data-id': m.id },
      h('div', { class: 'label' }, h('span', { html: icons.megaphone }), t('chat.announcement'), delBtn),
      h('div', { class: 'text', dir: 'auto', text: m.text }),
      h('div', { class: 'meta' }, formatTime(m.ts)));
  }

  const mine = m.userId === state.me?.id;
  const cont = prev && prev.kind === 'text' && prev.userId === m.userId && m.ts - prev.ts < 120000;
  return h('div', { class: `msg ${mine ? 'me' : 'other'}${cont ? ' cont' : ''}`, 'data-id': m.id },
    h('div', { class: 'bubble' },
      !mine && !cont ? h('div', { class: 'sender', dir: 'auto' }, m.name) : null,
      h('div', { class: 'text', dir: 'auto', text: m.text }),
      h('div', { class: 'meta' }, delBtn, formatTime(m.ts))));
}

function emptyState() {
  return h('div', { class: 'empty', id: 'emptyState', text: t('chat.empty') });
}

function nearBottom() {
  const el = $('messages');
  return el.scrollHeight - el.scrollTop - el.clientHeight < 140;
}

function scrollBottom() {
  const el = $('messages');
  el.scrollTop = el.scrollHeight;
}

function renderAll() {
  const el = $('messages');
  el.replaceChildren();
  if (!state.messages.length) el.append(emptyState());
  let prev = null;
  for (const m of state.messages) { el.append(buildMessage(m, prev)); prev = m; }
  scrollBottom();
}

function addMessage(m) {
  if (state.ids.has(m.id)) return;
  const el = $('messages');
  const stick = nearBottom() || m.userId === state.me?.id;
  const prev = state.messages.at(-1) || null;
  state.ids.add(m.id);
  state.messages.push(m);
  $('emptyState')?.remove();
  el.append(buildMessage(m, prev));
  while (el.children.length > MAX_DOM_MESSAGES) {
    el.firstElementChild.remove();
    const old = state.messages.shift();
    state.ids.delete(old.id);
  }
  if (stick) scrollBottom();
}

function removeMessages(ids) {
  const gone = new Set(ids);
  state.messages = state.messages.filter((m) => !gone.has(m.id));
  ids.forEach((id) => state.ids.delete(id));
  renderAllKeepScroll();
}

function renderAllKeepScroll() {
  const el = $('messages');
  const top = el.scrollTop;
  const stick = nearBottom();
  renderAll();
  if (!stick) el.scrollTop = top;
}

/* ---------------- composer ---------------- */
function autoGrow() {
  const input = $('input');
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 120)}px`;
  $('sendBtn').disabled = !input.value.trim() || state.sending;
}

async function sendMessage(e) {
  e?.preventDefault();
  const input = $('input');
  const text = input.value.trim();
  if (!text || state.sending) return;
  state.sending = true;
  input.value = '';
  autoGrow();
  try {
    const { message } = await api('POST', '/api/messages', { text });
    addMessage(message);
  } catch (err) {
    input.value = text;
    toast(errorText(err instanceof ApiError ? err.code : 'generic'));
    if (err instanceof ApiError && err.status === 401) logout(t('err.unauthorized'));
  } finally {
    state.sending = false;
    autoGrow();
    input.focus();
  }
}

/* ---------------- wiring ---------------- */
function onLanguageChanged() {
  applyLanguage();
  $('authLangs').replaceChildren(languageChips(onLanguageChanged));
  setMode(state.mode);
  if (state.me) { updateHeader(); setStatus(state.status); renderAll(); }
}

function wire() {
  document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => setMode(b.dataset.mode)));
  $('authForm').addEventListener('submit', submitAuth);
  $('authLangs').replaceChildren(languageChips(onLanguageChanged));

  $('composer').addEventListener('submit', sendMessage);
  $('input').addEventListener('input', autoGrow);
  $('input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && matchMedia('(pointer: fine)').matches) sendMessage(e);
  });

  $('sendBtn').innerHTML = icons.send;
  $('settingsBtn').innerHTML = icons.settings;
  $('adminBtn').innerHTML = icons.shield;

  $('onlineBtn').addEventListener('click', () => {
    onlineSheet = openOnlineSheet(() => state.presence);
    onlineSheet.onClose = () => { onlineSheet = null; };
  });
  $('settingsBtn').addEventListener('click', () => {
    openSettingsSheet({
      me: () => state.me,
      onSaved: (user) => { state.me = user; },
      onLogout: () => logout(''),
      onLanguage: onLanguageChanged,
    });
  });
  $('adminBtn').addEventListener('click', () => {
    adminSheet = openAdminSheet();
    adminSheet.onClose = () => { adminSheet = null; };
  });
}

async function boot() {
  initLang();
  wire();
  setMode('login');
  if (!session.token) { showView('auth'); return; }
  try {
    const { user } = await api('GET', '/api/me');
    enterChat(user);
  } catch (err) {
    if (err instanceof ApiError && err.code === 'network') {
      // Server unreachable: keep the session and let the stream retry.
      showView('auth');
      showAuthError(errorText('network'));
      return;
    }
    logout(err instanceof ApiError && err.code === 'banned' ? t('kick.banned') : '');
  }
}

boot();
