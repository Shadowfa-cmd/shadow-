import { api, ApiError } from './api.js';
import { t, errorText, LANGS, getLang, setLang } from './i18n.js';
import { h, icons, openSheet, confirmDialog, toast } from './ui.js';

const fail = (err) => toast(errorText(err instanceof ApiError ? err.code : 'generic'));

export function languageChips(onChange) {
  const wrap = h('div', { class: 'seg' });
  const render = () => {
    wrap.replaceChildren(...Object.entries(LANGS).map(([code, l]) =>
      h('button', {
        type: 'button', class: `chip${code === getLang() ? ' active' : ''}`, text: l.name,
        onclick: () => { setLang(code); onChange?.(code); render(); },
      })));
  };
  render();
  return wrap;
}

/** Online users list; `sheet.refresh()` is called when presence changes. */
export function openOnlineSheet(getPresence) {
  return openSheet(t('online.title'), (body, sheet) => {
    sheet.refresh = () => {
      const { users } = getPresence();
      body.replaceChildren(...users.map((u) =>
        h('div', { class: 'row' },
          h('div', { class: 'grow' }, h('div', { class: 'name', dir: 'auto', text: u.name })),
          h('span', { class: 'pill ok', text: t('admin.online') }))));
    };
    sheet.refresh();
  });
}

export function openSettingsSheet({ me, onSaved, onLogout, onLanguage }) {
  return openSheet(t('settings.title'), (body, sheet) => {
    const input = h('input', { dir: 'auto', maxlength: '32', value: me().displayName, autocomplete: 'nickname' });
    const save = h('button', { class: 'btn primary', type: 'button', text: t('settings.save') });
    save.addEventListener('click', async () => {
      save.disabled = true;
      try {
        const { user } = await api('PATCH', '/api/me', { displayName: input.value });
        onSaved(user);
        toast(t('settings.saved'));
      } catch (err) { fail(err); } finally { save.disabled = false; }
    });
    body.append(h('div', { class: 'stack' },
      h('div', { class: 'section' },
        h('label', { class: 'field' }, h('span', { text: t('settings.displayName') }), input),
        save),
      h('div', { class: 'section' },
        h('h4', { text: t('settings.language') }),
        languageChips(() => { sheet.close(); onLanguage(); })),
      h('button', { class: 'btn danger', type: 'button', text: t('settings.logout'), onclick: () => { sheet.close(); onLogout(); } })));
  });
}

export function openAdminSheet() {
  return openSheet(t('admin.title'), (body, sheet) => {
    const statOnline = h('b', { text: '–' });
    const statTotal = h('b', { text: '–' });
    const list = h('div');
    const textarea = h('textarea', { rows: '3', maxlength: '1000', dir: 'auto', placeholder: t('admin.announcePlaceholder') });
    const sendBtn = h('button', { class: 'btn primary', type: 'button', text: t('admin.sendAnnounce') });

    async function load() {
      try {
        const data = await api('GET', '/api/admin/users');
        statOnline.textContent = String(data.online);
        statTotal.textContent = String(data.total);
        list.replaceChildren(...data.users.filter((u) => u.role !== 'admin').map(userRow));
      } catch (err) { fail(err); }
    }
    sheet.refresh = load;

    function userRow(u) {
      const act = async (fn) => { try { await fn(); await load(); } catch (err) { fail(err); } };
      const banBtn = u.banned
        ? h('button', { class: 'btn small', type: 'button', text: t('admin.unban'), onclick: () => act(() => api('POST', `/api/admin/users/${u.id}/unban`)) })
        : h('button', { class: 'btn small danger', type: 'button', text: t('admin.ban'), onclick: async () => {
            if (await confirmDialog(t('admin.confirmBan', { name: u.displayName }), { danger: true })) act(() => api('POST', `/api/admin/users/${u.id}/ban`));
          } });
      const delBtn = h('button', { class: 'btn small danger', type: 'button', text: t('admin.delete'), onclick: async () => {
        if (await confirmDialog(t('admin.confirmDelete', { name: u.displayName }), { danger: true })) act(() => api('DELETE', `/api/admin/users/${u.id}`));
      } });
      return h('div', { class: 'row' },
        h('div', { class: 'grow' },
          h('div', { class: 'name', dir: 'auto', text: u.displayName }),
          h('div', { class: 'sub', dir: 'ltr', text: `@${u.username}` })),
        u.banned ? h('span', { class: 'pill bad', text: t('admin.banned') }) : u.online ? h('span', { class: 'pill ok', text: t('admin.online') }) : null,
        h('div', { class: 'actions' }, banBtn, delBtn));
    }

    sendBtn.addEventListener('click', async () => {
      if (!textarea.value.trim()) return;
      sendBtn.disabled = true;
      try {
        await api('POST', '/api/admin/announcements', { text: textarea.value });
        textarea.value = '';
        toast(t('admin.sent'));
      } catch (err) { fail(err); } finally { sendBtn.disabled = false; }
    });

    body.append(
      h('div', { class: 'section stats' },
        h('div', { class: 'stat' }, statOnline, h('span', { text: t('admin.onlineNow') })),
        h('div', { class: 'stat' }, statTotal, h('span', { text: t('admin.totalUsers') }))),
      h('div', { class: 'section stack' },
        h('h4', { text: t('admin.announce') }), textarea, sendBtn),
      h('div', { class: 'section' }, h('h4', { text: t('admin.users') }), list));
    load();
  });
}
