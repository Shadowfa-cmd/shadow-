import { t } from './i18n.js';

const svg = (d) =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;

// Static, trusted markup (never built from user data).
export const icons = {
  send: svg('<path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4 20-7z"/>'),
  settings: svg('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
  shield: svg('<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>'),
  close: svg('<path d="M18 6 6 18M6 6l12 12"/>'),
  trash: svg('<path d="M3 6h18M8 6V4h8v2m-9 0 1 14h8l1-14"/>'),
  megaphone: svg('<path d="M3 11v2a1 1 0 0 0 1 1h3l8 5V5L7 10H4a1 1 0 0 0-1 1z"/><path d="M19 9a4 4 0 0 1 0 6"/>'),
};

/** Tiny element builder. Text is always set via textContent / text nodes. */
export function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'text') el.textContent = v;
    else if (k === 'html') el.innerHTML = v; // only used with `icons`
    else if (k === 'dir') el.dir = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return el;
}

let toastTimer = null;
export function toast(message) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}

const root = () => document.getElementById('sheetRoot');
let openSheets = [];

function onKey(e) {
  if (e.key === 'Escape' && openSheets.length) openSheets[openSheets.length - 1].close();
}
document.addEventListener('keydown', onKey);

/** Bottom sheet. `build(body, sheet)` fills the body. Returns { close, body, onClose }. */
export function openSheet(title, build) {
  const body = h('div');
  const sheet = { body, close: null, onClose: null };
  const backdrop = h('div', { class: 'backdrop' },
    h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
      h('div', { class: 'sheet-head' },
        h('h3', { text: title }),
        h('button', { class: 'icon-btn', type: 'button', 'aria-label': t('common.close'), html: icons.close, onclick: () => sheet.close() })),
      body));
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) sheet.close(); });
  sheet.close = () => {
    backdrop.remove();
    openSheets = openSheets.filter((s) => s !== sheet);
    sheet.onClose?.();
  };
  root().append(backdrop);
  openSheets.push(sheet);
  build(body, sheet);
  return sheet;
}

export function closeAllSheets() {
  [...openSheets].forEach((s) => s.close());
}

/** Promise-based confirm dialog (window.confirm is unreliable in WebViews). */
export function confirmDialog(message, { danger = false } = {}) {
  return new Promise((resolve) => {
    const done = (v) => { backdrop.remove(); resolve(v); };
    const backdrop = h('div', { class: 'backdrop dialog' },
      h('div', { class: 'box', role: 'alertdialog', 'aria-modal': 'true' },
        h('p', { text: message }),
        h('div', { class: 'btns' },
          h('button', { class: 'btn', type: 'button', text: t('common.cancel'), onclick: () => done(false) }),
          h('button', { class: `btn ${danger ? 'danger' : 'primary'}`, type: 'button', text: t('common.confirm'), onclick: () => done(true) }))));
    backdrop.addEventListener('click', (e) => { if (e.target === backdrop) done(false); });
    root().append(backdrop);
  });
}
