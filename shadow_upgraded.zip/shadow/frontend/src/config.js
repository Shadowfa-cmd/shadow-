// Overwritten by "npm run build" from SHADOW_API_URL.
// Empty apiUrl = same origin (the backend serves this frontend).
window.SHADOW_CONFIG = { apiUrl: '' };
