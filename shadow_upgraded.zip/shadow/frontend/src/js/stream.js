import { api, streamUrl, ApiError } from './api.js';

const EVENTS = {
  init: 'onInit',
  message: 'onMessage',
  messages_removed: 'onMessagesRemoved',
  presence: 'onPresence',
  kick: 'onKick',
};

/**
 * Live connection (Server-Sent Events) with automatic reconnect.
 * A fresh one-time ticket is requested for every (re)connection, so the
 * long-lived login token never appears in a URL.
 */
export function createStream(handlers) {
  let es = null;
  let stopped = true;
  let retry = 0;
  let timer = null;

  function closeSource() {
    if (es) { es.close(); es = null; }
  }

  function schedule() {
    if (stopped) return;
    retry += 1;
    handlers.onStatus?.('reconnecting');
    const delay = Math.min(15000, 1000 * 2 ** Math.min(retry, 4)) + Math.random() * 500;
    clearTimeout(timer);
    timer = setTimeout(connect, delay);
  }

  async function connect() {
    if (stopped) return;
    handlers.onStatus?.(retry === 0 ? 'connecting' : 'reconnecting');
    let ticket;
    try {
      ({ ticket } = await api('POST', '/api/stream-ticket'));
    } catch (err) {
      if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
        stopped = true;
        handlers.onAuthError?.(err.code);
        return;
      }
      if (err instanceof ApiError && err.code === 'too_many_connections') {
        stopped = true;
        handlers.onStatus?.('connectionLimit');
        handlers.onConnectionLimit?.();
        return;
      }
      if (err instanceof ApiError && err.status === 503) handlers.onFull?.();
      schedule();
      return;
    }
    if (stopped) return;

    closeSource();
    es = new EventSource(streamUrl(ticket));
    for (const [name, handler] of Object.entries(EVENTS)) {
      es.addEventListener(name, (e) => {
        let data;
        try { data = JSON.parse(e.data); } catch { return; }
        if (name === 'init') { retry = 0; handlers.onStatus?.('online'); }
        if (name === 'kick') { stopped = true; closeSource(); }
        handlers[handler]?.(data);
      });
    }
    // EventSource would retry with an already-used ticket, so reconnects are managed here.
    es.onerror = () => { closeSource(); schedule(); };
  }

  return {
    start() { stopped = false; retry = 0; connect(); },
    stop() { stopped = true; clearTimeout(timer); closeSource(); },
  };
}
