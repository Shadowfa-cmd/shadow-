// Translations: English, Persian (fa), Dari (prs), Arabic (ar).
const en = {
  'app.name': 'Shadow',
  'auth.login': 'Log in', 'auth.register': 'Sign up',
  'auth.username': 'Username', 'auth.password': 'Password', 'auth.displayName': 'Display name',
  'auth.usernameHint': 'Letters, digits, _ and . (3-24)',
  'auth.passwordHint': 'At least 6 characters',
  'chat.placeholder': 'Write a message…', 'chat.send': 'Send',
  'chat.online': '{n} online', 'chat.empty': 'No messages yet. Say hello!',
  'chat.announcement': 'Announcement', 'chat.connecting': 'Connecting…', 'chat.reconnecting': 'Reconnecting…',
  'chat.connectionLimit': 'Too many active devices. Close another session, then reopen this app.',
  'chat.deleteMessage': 'Delete message', 'chat.you': 'You',
  'settings.title': 'Settings', 'settings.displayName': 'Display name', 'settings.save': 'Save',
  'settings.saved': 'Saved', 'settings.language': 'Language', 'settings.logout': 'Log out',
  'online.title': 'Online users', 'online.admin': 'Admin',
  'admin.title': 'Admin panel', 'admin.onlineNow': 'Online now', 'admin.totalUsers': 'Total users',
  'admin.announce': 'Announcement to everyone', 'admin.announcePlaceholder': 'Write an announcement…',
  'admin.sendAnnounce': 'Send announcement', 'admin.sent': 'Announcement sent',
  'admin.users': 'Users', 'admin.ban': 'Ban', 'admin.unban': 'Unban', 'admin.delete': 'Delete',
  'admin.banned': 'Banned', 'admin.online': 'Online',
  'admin.confirmBan': 'Ban {name}?', 'admin.confirmDelete': 'Delete {name} and all their messages?',
  'admin.confirmMessage': 'Delete this message?', 'admin.done': 'Done',
  'common.cancel': 'Cancel', 'common.confirm': 'Confirm', 'common.close': 'Close',
  'kick.banned': 'You have been banned by the admin.', 'kick.removed': 'Your account was removed by the admin.',
  'err.invalid_username': 'Username must be 3-24 characters: English letters, digits, _ or .',
  'err.invalid_password': 'Password must be 6-128 characters.',
  'err.invalid_display_name': 'Display name must be 2-32 characters.',
  'err.username_taken': 'This username is already taken.',
  'err.invalid_credentials': 'Wrong username or password.',
  'err.banned': 'This account is banned.',
  'err.rate_limited': 'Too many attempts. Please wait a moment.',
  'err.unauthorized': 'Please log in again.',
  'err.forbidden': 'Not allowed.', 'err.not_found': 'Not found.',
  'err.invalid_message': 'Message must be 1-1000 characters.',
  'err.server_full': 'The group is full right now. Try again soon.',
  'err.cannot_target_admin': 'The admin cannot be changed.',
  'err.network': 'Cannot reach the server. Check your connection.',
  'online.none': 'No one is online right now.',
  'settings.avatar': 'Choose an avatar color', 'avatar.violet': 'Violet', 'avatar.blue': 'Blue', 'avatar.pink': 'Pink', 'avatar.green': 'Green', 'avatar.orange': 'Orange', 'avatar.teal': 'Teal',
  'settings.notifications': 'Notifications', 'settings.systemNotifications': 'System notifications when the app is in the background',
  'settings.notificationsHint': 'Permission is requested only after you turn this on. Notifications use generic text to avoid exposing message contents.',
  'settings.notificationsUnsupported': 'System notifications are not supported in this browser.', 'settings.notificationsDenied': 'Notification permission was not granted.',
  'notify.title': 'Notifications', 'notify.empty': 'You are all caught up.', 'notify.newActivity': 'New group activity',
  'ai.title': 'AI assistant', 'ai.privacy': 'Messages sent here may be forwarded to the AI service configured by the server administrator. Do not send sensitive information.',
  'ai.placeholder': 'Ask a question…', 'ai.send': 'Send', 'ai.working': 'Thinking…', 'ai.you': 'You', 'ai.assistant': 'Assistant',
  'ai.notConfigured': 'The AI assistant has not been configured by the server administrator.', 'ai.timeout': 'The AI service took too long to respond. Please try again.',
  'admin.search': 'Search display name or username', 'admin.filter': 'Filter users', 'admin.filterAll': 'All users', 'admin.filterOnline': 'Online', 'admin.filterOffline': 'Offline', 'admin.filterBanned': 'Banned', 'admin.noUsers': 'No users match this filter.', 'admin.joined': 'Joined', 'admin.offline': 'Offline', 'admin.audit': 'Review admin activity', 'admin.auditEmpty': 'No recorded admin activity.',
  'api.title': 'External API keys', 'api.labelPlaceholder': 'Key label (for example, website)', 'api.defaultLabel': 'automation', 'api.scopeRead': 'Read messages', 'api.scopeWrite': 'Send messages', 'api.scopeAnnouncements': 'Read announcements',
  'api.generatedKey': 'Generated API key', 'api.create': 'Create key', 'api.revoke': 'Revoke', 'api.confirmRevoke': 'Revoke API key “{label}”?', 'api.revoked': 'API key revoked', 'api.none': 'No active API keys.', 'api.labelRequired': 'Enter a label of at least 2 characters.', 'api.createdOnce': 'Copy this key now. It will not be shown again.', 'api.copy': 'Copy key', 'api.copied': 'Copied', 'api.copyManual': 'Select and copy the key manually.',
  'err.invalid_avatar': 'Choose one of the available avatar colors.', 'err.ai_not_configured': 'AI is not configured.', 'err.ai_timeout': 'AI request timed out.', 'err.ai_provider_error': 'AI service is unavailable.', 'err.ai_busy': 'AI service is busy. Please try again.', 'err.ai_empty_response': 'AI returned an empty response.', 'err.api_key_required': 'An API key is required.', 'err.invalid_api_key': 'The API key is invalid or revoked.', 'err.api_scope_denied': 'This API key does not have the required scope.', 'err.invalid_key_label': 'The API key label is invalid.', 'err.invalid_api_scopes': 'Select a valid API scope.', 'err.telegram_not_configured': 'Telegram integration is not configured.', 'err.whatsapp_not_configured': 'WhatsApp integration is not configured.',
  'err.generic': 'Something went wrong.',
};

const fa = {
  'app.name': 'Shadow',
  'auth.login': 'ورود', 'auth.register': 'ثبت‌نام',
  'auth.username': 'نام کاربری', 'auth.password': 'رمز عبور', 'auth.displayName': 'نام نمایشی',
  'auth.usernameHint': 'حروف انگلیسی، عدد، _ و . (۳ تا ۲۴ نویسه)',
  'auth.passwordHint': 'حداقل ۶ نویسه',
  'chat.placeholder': 'پیام خود را بنویسید…', 'chat.send': 'ارسال',
  'chat.online': '{n} آنلاین', 'chat.empty': 'هنوز پیامی نیست. سلام کنید!',
  'chat.announcement': 'اطلاعیه', 'chat.connecting': 'در حال اتصال…', 'chat.reconnecting': 'اتصال دوباره…',
  'chat.connectionLimit': 'تعداد دستگاه‌های فعال زیاد است. یک نشست دیگر را ببندید و برنامه را دوباره باز کنید.',
  'chat.deleteMessage': 'حذف پیام', 'chat.you': 'شما',
  'settings.title': 'تنظیمات', 'settings.displayName': 'نام نمایشی', 'settings.save': 'ذخیره',
  'settings.saved': 'ذخیره شد', 'settings.language': 'زبان', 'settings.logout': 'خروج از حساب',
  'online.title': 'کاربران آنلاین', 'online.admin': 'ادمین',
  'admin.title': 'پنل ادمین', 'admin.onlineNow': 'آنلاین‌ها', 'admin.totalUsers': 'کل کاربران',
  'admin.announce': 'اطلاع‌رسانی به همه', 'admin.announcePlaceholder': 'متن اطلاعیه را بنویسید…',
  'admin.sendAnnounce': 'ارسال اطلاعیه', 'admin.sent': 'اطلاعیه ارسال شد',
  'admin.users': 'کاربران', 'admin.ban': 'بن', 'admin.unban': 'رفع بن', 'admin.delete': 'حذف',
  'admin.banned': 'بن‌شده', 'admin.online': 'آنلاین',
  'admin.confirmBan': '{name} بن شود؟', 'admin.confirmDelete': '{name} و همهٔ پیام‌هایش حذف شود؟',
  'admin.confirmMessage': 'این پیام حذف شود؟', 'admin.done': 'انجام شد',
  'common.cancel': 'انصراف', 'common.confirm': 'تأیید', 'common.close': 'بستن',
  'kick.banned': 'ادمین شما را بن کرده است.', 'kick.removed': 'حساب شما توسط ادمین حذف شد.',
  'err.invalid_username': 'نام کاربری باید ۳ تا ۲۴ نویسه باشد: حروف انگلیسی، عدد، _ یا .',
  'err.invalid_password': 'رمز عبور باید ۶ تا ۱۲۸ نویسه باشد.',
  'err.invalid_display_name': 'نام نمایشی باید ۲ تا ۳۲ نویسه باشد.',
  'err.username_taken': 'این نام کاربری قبلاً گرفته شده است.',
  'err.invalid_credentials': 'نام کاربری یا رمز عبور اشتباه است.',
  'err.banned': 'این حساب بن شده است.',
  'err.rate_limited': 'تلاش‌های زیاد. کمی صبر کنید.',
  'err.unauthorized': 'لطفاً دوباره وارد شوید.',
  'err.forbidden': 'مجاز نیست.', 'err.not_found': 'پیدا نشد.',
  'err.invalid_message': 'پیام باید بین ۱ تا ۱۰۰۰ نویسه باشد.',
  'err.server_full': 'ظرفیت گروه الان پر است. کمی بعد دوباره تلاش کنید.',
  'err.cannot_target_admin': 'ادمین قابل تغییر نیست.',
  'err.network': 'اتصال به سرور برقرار نشد. اینترنت خود را بررسی کنید.',
  'online.none': 'در حال حاضر کسی آنلاین نیست.',
  'settings.avatar': 'رنگ آواتار را انتخاب کنید', 'avatar.violet': 'بنفش', 'avatar.blue': 'آبی', 'avatar.pink': 'صورتی', 'avatar.green': 'سبز', 'avatar.orange': 'نارنجی', 'avatar.teal': 'فیروزه‌ای',
  'settings.notifications': 'اعلان‌ها', 'settings.systemNotifications': 'اعلان سیستم وقتی برنامه در پس‌زمینه است',
  'settings.notificationsHint': 'اجازه فقط پس از فعال‌کردن این گزینه درخواست می‌شود. برای حفظ حریم خصوصی، متن اعلان محتوای پیام را نشان نمی‌دهد.',
  'settings.notificationsUnsupported': 'این مرورگر از اعلان سیستم پشتیبانی نمی‌کند.', 'settings.notificationsDenied': 'اجازهٔ اعلان داده نشد.',
  'notify.title': 'اعلان‌ها', 'notify.empty': 'اعلان تازه‌ای ندارید.', 'notify.newActivity': 'فعالیت تازه در گروه',
  'ai.title': 'دستیار هوش مصنوعی', 'ai.privacy': 'پیام‌های این بخش ممکن است برای سرویس هوش مصنوعی تنظیم‌شده در سرور فرستاده شوند. اطلاعات حساس نفرستید.',
  'ai.placeholder': 'پرسش خود را بنویسید…', 'ai.send': 'ارسال', 'ai.working': 'در حال پاسخ…', 'ai.you': 'شما', 'ai.assistant': 'دستیار',
  'ai.notConfigured': 'دستیار هوش مصنوعی هنوز توسط مدیر سرور تنظیم نشده است.', 'ai.timeout': 'پاسخ سرویس هوش مصنوعی بیش از حد طول کشید. دوباره تلاش کنید.',
  'admin.search': 'جست‌وجوی نام یا نام کاربری', 'admin.filter': 'فیلتر کاربران', 'admin.filterAll': 'همه کاربران', 'admin.filterOnline': 'آنلاین', 'admin.filterOffline': 'آفلاین', 'admin.filterBanned': 'بن‌شده', 'admin.noUsers': 'کاربری با این فیلتر پیدا نشد.', 'admin.joined': 'تاریخ عضویت', 'admin.offline': 'آفلاین', 'admin.audit': 'بررسی فعالیت مدیر', 'admin.auditEmpty': 'هنوز فعالیت مدیریتی ثبت نشده است.',
  'api.title': 'کلیدهای API بیرونی', 'api.labelPlaceholder': 'نام کلید (مثلاً وب‌سایت)', 'api.defaultLabel': 'سرویس', 'api.scopeRead': 'خواندن پیام‌ها', 'api.scopeWrite': 'فرستادن پیام', 'api.scopeAnnouncements': 'خواندن اطلاعیه‌ها',
  'api.generatedKey': 'کلید ساخته‌شدهٔ API', 'api.create': 'ساخت کلید', 'api.revoke': 'لغو', 'api.confirmRevoke': 'کلید «{label}» لغو شود؟', 'api.revoked': 'کلید API لغو شد', 'api.none': 'کلید فعال API وجود ندارد.', 'api.labelRequired': 'نامی با حداقل ۲ نویسه وارد کنید.', 'api.createdOnce': 'همین حالا کلید را کاپی کنید؛ دوباره نمایش داده نمی‌شود.', 'api.copy': 'کاپی کلید', 'api.copied': 'کاپی شد', 'api.copyManual': 'کلید را انتخاب کرده و دستی کاپی کنید.',
  'err.invalid_avatar': 'یکی از رنگ‌های موجود آواتار را انتخاب کنید.', 'err.ai_not_configured': 'هوش مصنوعی تنظیم نشده است.', 'err.ai_timeout': 'زمان درخواست هوش مصنوعی تمام شد.', 'err.ai_provider_error': 'سرویس هوش مصنوعی در دسترس نیست.', 'err.ai_busy': 'سرویس هوش مصنوعی مصروف است. دوباره تلاش کنید.', 'err.ai_empty_response': 'پاسخ هوش مصنوعی خالی بود.', 'err.api_key_required': 'کلید API لازم است.', 'err.invalid_api_key': 'کلید API نامعتبر یا لغو شده است.', 'err.api_scope_denied': 'این کلید API اجازهٔ لازم را ندارد.', 'err.invalid_key_label': 'نام کلید API نامعتبر است.', 'err.invalid_api_scopes': 'سطح دسترسی API را درست انتخاب کنید.', 'err.telegram_not_configured': 'اتصال تلگرام تنظیم نشده است.', 'err.whatsapp_not_configured': 'اتصال واتساپ تنظیم نشده است.',
  'err.generic': 'مشکلی پیش آمد.',
};

// Dari (Afghan Persian): same script, with Dari wording where it differs.
const prs = {
  ...fa,
  'auth.password': 'کلمه عبور',
  'chat.placeholder': 'پیام‌تان را بنویسید…', 'chat.send': 'فرستادن',
  'chat.connectionLimit': 'تعداد دستگاه‌های فعال زیاد است. یک نشست دیگر را ببندید و برنامه را دوباره باز کنید.',
  'chat.empty': 'هنوز پیامی نیست. سلام بگویید!',
  'settings.logout': 'بیرون شدن از حساب',
  'admin.sendAnnounce': 'فرستادن اطلاعیه', 'admin.sent': 'اطلاعیه فرستاده شد',
  'admin.confirmBan': '{name} بن شود؟',
  'err.invalid_password': 'کلمه عبور باید ۶ تا ۱۲۸ نویسه باشد.',
  'err.invalid_credentials': 'نام کاربری یا کلمه عبور اشتباه است.',
  'err.rate_limited': 'تلاش‌های بیش از حد. لطفاً کمی صبر کنید.',
  'err.network': 'اتصال با سرور برقرار نشد. انترنت‌تان را بررسی کنید.',
  'err.server_full': 'گنجایش گروه حالا پر است. کمی بعد دوباره امتحان کنید.',
};

const ar = {
  'app.name': 'Shadow',
  'auth.login': 'تسجيل الدخول', 'auth.register': 'إنشاء حساب',
  'auth.username': 'اسم المستخدم', 'auth.password': 'كلمة المرور', 'auth.displayName': 'الاسم المعروض',
  'auth.usernameHint': 'أحرف إنجليزية وأرقام و _ و . (من 3 إلى 24)',
  'auth.passwordHint': '6 أحرف على الأقل',
  'chat.placeholder': 'اكتب رسالة…', 'chat.send': 'إرسال',
  'chat.online': '{n} متصل', 'chat.empty': 'لا توجد رسائل بعد. ابدأ بالتحية!',
  'chat.announcement': 'إعلان', 'chat.connecting': 'جارٍ الاتصال…', 'chat.reconnecting': 'إعادة الاتصال…',
  'chat.connectionLimit': 'عدد الأجهزة النشطة كبير. أغلق جلسة أخرى ثم أعد فتح التطبيق.',
  'chat.deleteMessage': 'حذف الرسالة', 'chat.you': 'أنت',
  'settings.title': 'الإعدادات', 'settings.displayName': 'الاسم المعروض', 'settings.save': 'حفظ',
  'settings.saved': 'تم الحفظ', 'settings.language': 'اللغة', 'settings.logout': 'تسجيل الخروج',
  'online.title': 'المستخدمون المتصلون', 'online.admin': 'المشرف',
  'admin.title': 'لوحة المشرف', 'admin.onlineNow': 'المتصلون الآن', 'admin.totalUsers': 'إجمالي المستخدمين',
  'admin.announce': 'إعلان للجميع', 'admin.announcePlaceholder': 'اكتب الإعلان…',
  'admin.sendAnnounce': 'إرسال الإعلان', 'admin.sent': 'تم إرسال الإعلان',
  'admin.users': 'المستخدمون', 'admin.ban': 'حظر', 'admin.unban': 'إلغاء الحظر', 'admin.delete': 'حذف',
  'admin.banned': 'محظور', 'admin.online': 'متصل',
  'admin.confirmBan': 'هل تريد حظر {name}؟', 'admin.confirmDelete': 'حذف {name} وكل رسائله؟',
  'admin.confirmMessage': 'حذف هذه الرسالة؟', 'admin.done': 'تم',
  'common.cancel': 'إلغاء', 'common.confirm': 'تأكيد', 'common.close': 'إغلاق',
  'kick.banned': 'لقد حظرك المشرف.', 'kick.removed': 'تم حذف حسابك من قبل المشرف.',
  'err.invalid_username': 'اسم المستخدم من 3 إلى 24 حرفاً: أحرف إنجليزية وأرقام و _ أو .',
  'err.invalid_password': 'يجب أن تكون كلمة المرور من 6 إلى 128 حرفاً.',
  'err.invalid_display_name': 'يجب أن يكون الاسم المعروض من 2 إلى 32 حرفاً.',
  'err.username_taken': 'اسم المستخدم مستخدم بالفعل.',
  'err.invalid_credentials': 'اسم المستخدم أو كلمة المرور غير صحيحة.',
  'err.banned': 'هذا الحساب محظور.',
  'err.rate_limited': 'محاولات كثيرة. انتظر قليلاً.',
  'err.unauthorized': 'يرجى تسجيل الدخول مرة أخرى.',
  'err.forbidden': 'غير مسموح.', 'err.not_found': 'غير موجود.',
  'err.invalid_message': 'يجب أن تتكون الرسالة من 1 إلى 1000 حرف.',
  'err.server_full': 'المجموعة ممتلئة حالياً. حاول بعد قليل.',
  'err.cannot_target_admin': 'لا يمكن تعديل المشرف.',
  'err.network': 'تعذر الوصول إلى الخادم. تحقق من اتصالك.',
  'online.none': 'لا يوجد مستخدمون متصلون الآن.',
  'settings.avatar': 'اختر لون الصورة الرمزية', 'avatar.violet': 'بنفسجي', 'avatar.blue': 'أزرق', 'avatar.pink': 'وردي', 'avatar.green': 'أخضر', 'avatar.orange': 'برتقالي', 'avatar.teal': 'فيروزي',
  'settings.notifications': 'الإشعارات', 'settings.systemNotifications': 'إشعارات النظام عند وجود التطبيق في الخلفية',
  'settings.notificationsHint': 'لن يُطلب الإذن إلا بعد تفعيل هذا الخيار. تستخدم الإشعارات نصاً عاماً لحماية محتوى الرسائل.',
  'settings.notificationsUnsupported': 'هذا المتصفح لا يدعم إشعارات النظام.', 'settings.notificationsDenied': 'لم يتم منح إذن الإشعارات.',
  'notify.title': 'الإشعارات', 'notify.empty': 'لا توجد إشعارات جديدة.', 'notify.newActivity': 'نشاط جديد في المجموعة',
  'ai.title': 'مساعد الذكاء الاصطناعي', 'ai.privacy': 'قد تُرسل الرسائل هنا إلى خدمة الذكاء الاصطناعي التي يحددها مسؤول الخادم. لا ترسل معلومات حساسة.',
  'ai.placeholder': 'اكتب سؤالك…', 'ai.send': 'إرسال', 'ai.working': 'جارٍ التفكير…', 'ai.you': 'أنت', 'ai.assistant': 'المساعد',
  'ai.notConfigured': 'لم يضبط مسؤول الخادم مساعد الذكاء الاصطناعي بعد.', 'ai.timeout': 'استغرق رد خدمة الذكاء الاصطناعي وقتاً طويلاً. حاول مرة أخرى.',
  'admin.search': 'البحث بالاسم أو اسم المستخدم', 'admin.filter': 'تصفية المستخدمين', 'admin.filterAll': 'جميع المستخدمين', 'admin.filterOnline': 'متصل', 'admin.filterOffline': 'غير متصل', 'admin.filterBanned': 'محظور', 'admin.noUsers': 'لا يوجد مستخدمون يطابقون التصفية.', 'admin.joined': 'تاريخ الانضمام', 'admin.offline': 'غير متصل', 'admin.audit': 'مراجعة نشاط المشرف', 'admin.auditEmpty': 'لا توجد أنشطة إدارية مسجلة.',
  'api.title': 'مفاتيح API خارجية', 'api.labelPlaceholder': 'اسم المفتاح (مثل موقع)', 'api.defaultLabel': 'خدمة', 'api.scopeRead': 'قراءة الرسائل', 'api.scopeWrite': 'إرسال الرسائل', 'api.scopeAnnouncements': 'قراءة الإعلانات',
  'api.generatedKey': 'مفتاح API المُنشأ', 'api.create': 'إنشاء مفتاح', 'api.revoke': 'إلغاء', 'api.confirmRevoke': 'إلغاء مفتاح API «{label}»؟', 'api.revoked': 'تم إلغاء مفتاح API', 'api.none': 'لا توجد مفاتيح API نشطة.', 'api.labelRequired': 'أدخل اسماً من حرفين على الأقل.', 'api.createdOnce': 'انسخ المفتاح الآن؛ لن يظهر مرة أخرى.', 'api.copy': 'نسخ المفتاح', 'api.copied': 'تم النسخ', 'api.copyManual': 'حدد المفتاح وانسخه يدوياً.',
  'err.invalid_avatar': 'اختر لوناً متاحاً للصورة الرمزية.', 'err.ai_not_configured': 'الذكاء الاصطناعي غير مضبوط.', 'err.ai_timeout': 'انتهت مهلة طلب الذكاء الاصطناعي.', 'err.ai_provider_error': 'خدمة الذكاء الاصطناعي غير متاحة.', 'err.ai_busy': 'خدمة الذكاء الاصطناعي مشغولة. حاول لاحقاً.', 'err.ai_empty_response': 'أعاد الذكاء الاصطناعي رداً فارغاً.', 'err.api_key_required': 'مفتاح API مطلوب.', 'err.invalid_api_key': 'مفتاح API غير صالح أو ملغى.', 'err.api_scope_denied': 'لا يملك هذا المفتاح الصلاحية المطلوبة.', 'err.invalid_key_label': 'اسم مفتاح API غير صالح.', 'err.invalid_api_scopes': 'حدد نطاق API صالحاً.', 'err.telegram_not_configured': 'لم يتم إعداد تكامل Telegram.', 'err.whatsapp_not_configured': 'لم يتم إعداد تكامل WhatsApp.',
  'err.generic': 'حدث خطأ ما.',
};

export const LANGS = {
  fa: { name: 'فارسی', dir: 'rtl', locale: 'fa-IR', dict: fa },
  prs: { name: 'دری', dir: 'rtl', locale: 'fa-AF', dict: prs },
  ar: { name: 'العربية', dir: 'rtl', locale: 'ar', dict: ar },
  en: { name: 'English', dir: 'ltr', locale: 'en', dict: en },
};

const KEY = 'shadow.lang';
let current = 'en';

function detect() {
  try {
    const saved = localStorage.getItem(KEY);
    if (saved && LANGS[saved]) return saved;
  } catch { /* storage unavailable */ }
  const nav = (navigator.language || 'en').toLowerCase();
  if (nav === 'fa-af' || nav === 'prs' || nav.startsWith('prs')) return 'prs';
  if (nav.startsWith('fa')) return 'fa';
  if (nav.startsWith('ar')) return 'ar';
  return 'en';
}

export function getLang() { return current; }
export function getLocale() { return LANGS[current].locale; }

export function t(key, vars) {
  let s = LANGS[current].dict[key] ?? en[key] ?? key;
  if (vars) for (const [k, val] of Object.entries(vars)) s = s.replaceAll(`{${k}}`, String(val));
  return s;
}

export function errorText(code) {
  const key = `err.${code}`;
  return (LANGS[current].dict[key] ?? en[key]) ? t(key) : t('err.generic');
}

/** Apply translations to every [data-i18n*] element and set <html lang/dir>. */
export function applyLanguage(root = document) {
  const { dir } = LANGS[current];
  document.documentElement.lang = current === 'prs' ? 'fa-AF' : current;
  document.documentElement.dir = dir;
  document.title = t('app.name');
  root.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  root.querySelectorAll('[data-i18n-placeholder]').forEach((el) => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  root.querySelectorAll('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
}

export function setLang(code) {
  if (!LANGS[code]) return;
  current = code;
  try { localStorage.setItem(KEY, code); } catch { /* ignore */ }
  applyLanguage();
}

export function initLang() {
  current = detect();
  applyLanguage();
}
