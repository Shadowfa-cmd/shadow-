import { api, ApiError } from './api.js';
import { t, errorText, LANGS, getLang, getLocale, setLang } from './i18n.js';
import { h, icons, openSheet, confirmDialog, toast, userAvatar } from './ui.js';

const fail = (err) => toast(errorText(err instanceof ApiError ? err.code : 'generic'));
const formattedDate = (ts) => {
  if (!ts) return '—';
  try { return new Intl.DateTimeFormat(getLocale(), { year: 'numeric', month: 'short', day: 'numeric' }).format(new Date(ts)); }
  catch { return new Date(ts).toLocaleDateString(); }
};

export function languageChips(onChange) {
  const wrap = h('div', { class: 'seg' });
  const render = () => {
    wrap.replaceChildren(...Object.entries(LANGS).map(([code, l]) =>
      h('button', {
        type: 'button', class: `chip${code === getLang() ? ' active' : ''}`, text: l.name,
        onclick: () => { setLang(code); onChange?.(code); render(); },
      })));
  };
  render();
  return wrap;
}

/** Online users list; `sheet.refresh()` is called when presence changes. */
export function openOnlineSheet(getPresence) {
  return openSheet(t('online.title'), (body, sheet) => {
    sheet.refresh = () => {
      const { users } = getPresence();
      if (!users.length) { body.replaceChildren(h('p', { class: 'empty-inline', text: t('online.none') })); return; }
      body.replaceChildren(...users.map((u) =>
        h('div', { class: 'row' },
          userAvatar({ name: u.name, avatar: u.avatar }, 'avatar-sm'),
          h('div', { class: 'grow' },
            h('div', { class: 'name', dir: 'auto', text: u.name }),
            u.username ? h('div', { class: 'sub', dir: 'ltr', text: `@${u.username}` }) : null),
          h('span', { class: 'pill ok', text: t('admin.online') }))));
    };
    sheet.refresh();
  });
}

export function openSettingsSheet({ me, onSaved, onLogout, onLanguage, notificationsEnabled, onNotifications }) {
  return openSheet(t('settings.title'), (body, sheet) => {
    const input = h('input', { dir: 'auto', maxlength: '32', value: me().displayName, autocomplete: 'nickname' });
    const avatarChoices = h('div', { class: 'avatar-choices', role: 'group', 'aria-label': t('settings.avatar') });
    const avatarNames = ['violet', 'blue', 'pink', 'green', 'orange', 'teal'];
    let selectedAvatar = avatarNames.includes(me().avatar) ? me().avatar : 'violet';
    const renderAvatars = () => avatarChoices.replaceChildren(...avatarNames.map((avatar) =>
      h('button', { type: 'button', class: `avatar-choice ${avatar}${selectedAvatar === avatar ? ' selected' : ''}`, 'aria-label': t(`avatar.${avatar}`), title: t(`avatar.${avatar}`), onclick: () => { selectedAvatar = avatar; renderAvatars(); } },
        h('span', { text: Array.from(me().displayName || me().username || '?')[0] || '?' }))));
    renderAvatars();
    const save = h('button', { class: 'btn primary', type: 'button', text: t('settings.save') });
    save.addEventListener('click', async () => {
      save.disabled = true;
      try {
        const { user } = await api('PATCH', '/api/me', { displayName: input.value, avatar: selectedAvatar });
        onSaved(user);
        toast(t('settings.saved'));
      } catch (err) { fail(err); } finally { save.disabled = false; }
    });

    const notifications = h('input', { type: 'checkbox', class: 'notify-checkbox' });
    notifications.checked = !!notificationsEnabled();
    notifications.addEventListener('change', async () => {
      notifications.disabled = true;
      try {
        const enabled = await onNotifications(notifications.checked);
        notifications.checked = !!enabled;
      } catch { notifications.checked = false; }
      finally { notifications.disabled = false; }
    });

    body.append(h('div', { class: 'stack' },
      h('div', { class: 'section stack' },
        h('label', { class: 'field' }, h('span', { text: t('settings.displayName') }), input),
        h('div', { class: 'field' }, h('span', { text: t('settings.avatar') }), avatarChoices),
        save),
      h('div', { class: 'section' },
        h('h4', { text: t('settings.notifications') }),
        h('label', { class: 'toggle-row' }, notifications, h('span', { text: t('settings.systemNotifications') })),
        h('p', { class: 'hint', text: t('settings.notificationsHint') })),
      h('div', { class: 'section' },
        h('h4', { text: t('settings.language') }),
        languageChips(() => { sheet.close(); onLanguage(); })),
      h('button', { class: 'btn danger', type: 'button', text: t('settings.logout'), onclick: () => { sheet.close(); onLogout(); } })));
  });
}

export function openNotificationsSheet(notifications, onRead) {
  return openSheet(t('notify.title'), (body) => {
    onRead();
    if (!notifications.length) {
      body.append(h('p', { class: 'empty-inline', text: t('notify.empty') }));
      return;
    }
    body.append(...notifications.map((item) => h('div', { class: 'notification-row' },
      h('div', { class: 'notification-dot' }),
      h('div', { class: 'grow' },
        h('div', { class: 'name', dir: 'auto', text: item.name || t('notify.newActivity') }),
        h('p', { class: 'notification-text', dir: 'auto', text: item.text || t('notify.newActivity') }),
        h('div', { class: 'sub', text: `${item.sourceLabel || ''}${item.sourceLabel ? ' · ' : ''}${formattedDate(item.ts)}` })))));
  });
}

export function openAiSheet() {
  return openSheet(t('ai.title'), (body) => {
    const history = [];
    const transcript = h('div', { class: 'ai-transcript', role: 'log', 'aria-live': 'polite' });
    const input = h('textarea', { rows: '2', maxlength: '1000', dir: 'auto', placeholder: t('ai.placeholder') });
    const send = h('button', { class: 'btn primary', type: 'button', text: t('ai.send') });
    const error = h('p', { class: 'error', hidden: true, role: 'alert' });
    const addTurn = (role, content) => {
      transcript.append(h('div', { class: `ai-turn ${role}`, dir: 'auto' },
        h('div', { class: 'ai-role', text: role === 'user' ? t('ai.you') : t('ai.assistant') }),
        h('div', { class: 'text', text: content })));
      transcript.scrollTop = transcript.scrollHeight;
    };
    async function submit() {
      const message = input.value.trim();
      if (!message || send.disabled) return;
      const prior = history.slice(-8);
      input.value = '';
      error.hidden = true;
      addTurn('user', message);
      history.push({ role: 'user', content: message });
      send.disabled = true; send.textContent = t('ai.working');
      try {
        const result = await api('POST', '/api/ai/chat', { message, history: prior });
        addTurn('assistant', result.answer);
        history.push({ role: 'assistant', content: result.answer });
      } catch (err) {
        history.pop();
        input.value = message;
        error.hidden = false;
        error.textContent = err instanceof ApiError
          ? (err.code === 'ai_not_configured' ? t('ai.notConfigured') : err.code === 'ai_timeout' ? t('ai.timeout') : errorText(err.code))
          : errorText('generic');
      } finally { send.disabled = false; send.textContent = t('ai.send'); }
    }
    send.addEventListener('click', submit);
    input.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' && !event.shiftKey && !event.isComposing && matchMedia('(pointer: fine)').matches) { event.preventDefault(); submit(); }
    });
    body.append(h('p', { class: 'hint', text: t('ai.privacy') }), transcript, error,
      h('div', { class: 'ai-composer' }, input, send));
  });
}

export function openAdminSheet() {
  return openSheet(t('admin.title'), (body, sheet) => {
    const statOnline = h('b', { text: '–' });
    const statTotal = h('b', { text: '–' });
    const statBanned = h('b', { text: '–' });
    const list = h('div', { class: 'user-list' });
    const search = h('input', { type: 'search', maxlength: '80', placeholder: t('admin.search'), 'aria-label': t('admin.search') });
    const filter = h('select', { 'aria-label': t('admin.filter') },
      h('option', { value: 'all', text: t('admin.filterAll') }),
      h('option', { value: 'online', text: t('admin.filterOnline') }),
      h('option', { value: 'offline', text: t('admin.filterOffline') }),
      h('option', { value: 'banned', text: t('admin.filterBanned') }));
    let users = [];
    const textarea = h('textarea', { rows: '3', maxlength: '1000', dir: 'auto', placeholder: t('admin.announcePlaceholder') });
    const sendBtn = h('button', { class: 'btn primary', type: 'button', text: t('admin.sendAnnounce') });

    function renderUsers() {
      const query = search.value.trim().toLowerCase();
      const mode = filter.value;
      const filtered = users.filter((u) => {
        const match = !query || `${u.displayName} ${u.username}`.toLowerCase().includes(query);
        const status = mode === 'all' || (mode === 'online' && u.online && !u.banned)
          || (mode === 'offline' && !u.online && !u.banned) || (mode === 'banned' && u.banned);
        return match && status && u.role !== 'admin';
      });
      list.replaceChildren(...filtered.map(userRow));
      if (!filtered.length) list.append(h('p', { class: 'empty-inline', text: t('admin.noUsers') }));
    }

    async function load() {
      try {
        const data = await api('GET', '/api/admin/users');
        statOnline.textContent = String(data.online);
        statTotal.textContent = String(data.total);
        statBanned.textContent = String(data.banned || 0);
        users = data.users;
        renderUsers();
      } catch (err) { fail(err); }
    }
    sheet.refresh = load;

    function userRow(u) {
      const act = async (fn) => { try { await fn(); await load(); } catch (err) { fail(err); } };
      const banBtn = u.banned
        ? h('button', { class: 'btn small', type: 'button', text: t('admin.unban'), onclick: () => act(() => api('POST', `/api/admin/users/${u.id}/unban`)) })
        : h('button', { class: 'btn small danger', type: 'button', text: t('admin.ban'), onclick: async () => {
            if (await confirmDialog(t('admin.confirmBan', { name: u.displayName }), { danger: true })) act(() => api('POST', `/api/admin/users/${u.id}/ban`));
          } });
      const delBtn = h('button', { class: 'btn small danger', type: 'button', text: t('admin.delete'), onclick: async () => {
        if (await confirmDialog(t('admin.confirmDelete', { name: u.displayName }), { danger: true })) act(() => api('DELETE', `/api/admin/users/${u.id}`));
      } });
      return h('div', { class: 'row admin-user' },
        userAvatar({ displayName: u.displayName, avatar: u.avatar }, 'avatar-sm'),
        h('div', { class: 'grow' },
          h('div', { class: 'name', dir: 'auto', text: u.displayName }),
          h('div', { class: 'sub', dir: 'ltr', text: `@${u.username}` }),
          h('div', { class: 'sub', text: `${t('admin.joined')}: ${formattedDate(u.createdAt)}` })),
        u.banned ? h('span', { class: 'pill bad', text: t('admin.banned') }) : u.online ? h('span', { class: 'pill ok', text: t('admin.online') }) : h('span', { class: 'pill', text: t('admin.offline') }),
        h('div', { class: 'actions' }, banBtn, delBtn));
    }

    sendBtn.addEventListener('click', async () => {
      if (!textarea.value.trim()) return;
      sendBtn.disabled = true;
      try {
        await api('POST', '/api/admin/announcements', { text: textarea.value });
        textarea.value = ''; toast(t('admin.sent'));
      } catch (err) { fail(err); } finally { sendBtn.disabled = false; }
    });
    search.addEventListener('input', renderUsers);
    filter.addEventListener('change', renderUsers);

    const keyLabel = h('input', { maxlength: '40', placeholder: t('api.labelPlaceholder'), value: t('api.defaultLabel') });
    const keyScope = h('select', {},
      h('option', { value: 'messages:read', text: t('api.scopeRead') }),
      h('option', { value: 'messages:write', text: t('api.scopeWrite') }),
      h('option', { value: 'announcements:read', text: t('api.scopeAnnouncements') }));
    const keyResult = h('textarea', { rows: '2', readonly: true, hidden: true, dir: 'ltr', 'aria-label': t('api.generatedKey') });
    const keyList = h('div', { class: 'key-list' });
    const makeKey = h('button', { class: 'btn primary', type: 'button', text: t('api.create') });
    async function loadKeys() {
      try {
        const { keys } = await api('GET', '/api/admin/api-keys');
        keyList.replaceChildren(...keys.filter((k) => !k.revokedAt).map((key) => h('div', { class: 'row' },
          h('div', { class: 'grow' }, h('div', { class: 'name', text: key.label }),
            h('div', { class: 'sub', dir: 'ltr', text: `${key.prefix}… · ${key.scopes.join(', ')}` })),
          h('button', { class: 'btn small danger', type: 'button', text: t('api.revoke'), onclick: async () => {
            if (!(await confirmDialog(t('api.confirmRevoke', { label: key.label }), { danger: true }))) return;
            try { await api('DELETE', `/api/admin/api-keys/${key.id}`); toast(t('api.revoked')); await loadKeys(); }
            catch (err) { fail(err); }
          } }))));
        if (!keyList.children.length) keyList.append(h('p', { class: 'empty-inline', text: t('api.none') }));
      } catch (err) { fail(err); }
    }
    makeKey.addEventListener('click', async () => {
      if (keyLabel.value.trim().length < 2) { toast(t('api.labelRequired')); return; }
      makeKey.disabled = true;
      try {
        const result = await api('POST', '/api/admin/api-keys', { label: keyLabel.value.trim(), scopes: [keyScope.value] });
        keyResult.hidden = false; keyResult.value = result.apiKey; keyResult.focus(); keyResult.select();
        toast(t('api.createdOnce')); await loadKeys();
      } catch (err) { fail(err); } finally { makeKey.disabled = false; }
    });

    const auditList = h('div', { class: 'audit-list' });
    const auditBtn = h('button', { class: 'btn', type: 'button', text: t('admin.audit') });
    auditBtn.addEventListener('click', async () => {
      if (!auditList.hidden) { auditList.hidden = true; return; }
      try {
        const { entries } = await api('GET', '/api/admin/audit');
        auditList.replaceChildren(...entries.slice(0, 20).map((entry) => h('div', { class: 'audit-row' },
          h('b', { text: entry.action }),
          h('span', { text: `${formattedDate(entry.ts)} · ${new Date(entry.ts).toLocaleTimeString()}` }),
          h('code', { text: entry.targetId || '—' }))));
        if (!entries.length) auditList.append(h('p', { class: 'empty-inline', text: t('admin.auditEmpty') }));
        auditList.hidden = false;
      } catch (err) { fail(err); }
    });

    body.append(
      h('div', { class: 'section stats stats-three' },
        h('div', { class: 'stat' }, statOnline, h('span', { text: t('admin.onlineNow') })),
        h('div', { class: 'stat' }, statTotal, h('span', { text: t('admin.totalUsers') })),
        h('div', { class: 'stat' }, statBanned, h('span', { text: t('admin.banned') }))),
      h('div', { class: 'section stack' }, h('h4', { text: t('admin.announce') }), textarea, sendBtn),
      h('div', { class: 'section stack' }, h('h4', { text: t('admin.users') }), search, filter, list),
      h('div', { class: 'section stack' }, h('h4', { text: t('api.title') }),
        keyLabel, keyScope, makeKey, keyResult,
        h('button', { class: 'btn small', type: 'button', text: t('api.copy'), onclick: async () => {
          try { await navigator.clipboard.writeText(keyResult.value); toast(t('api.copied')); }
          catch { keyResult.focus(); keyResult.select(); toast(t('api.copyManual')); }
        } }), keyList),
      h('div', { class: 'section stack' }, auditBtn, auditList));
    auditList.hidden = true;
    load(); loadKeys();
  });
}
