// Thin fetch wrapper. All requests go to SHADOW_CONFIG.apiUrl (empty = same origin).
const base = ((window.SHADOW_CONFIG && window.SHADOW_CONFIG.apiUrl) || '').replace(/\/+$/, '');
const TOKEN_KEY = 'shadow.token';

export class ApiError extends Error {
  constructor(code, status) { super(code); this.code = code; this.status = status; }
}

export const session = {
  get token() { try { return localStorage.getItem(TOKEN_KEY) || ''; } catch { return ''; } },
  set token(v) { try { v ? localStorage.setItem(TOKEN_KEY, v) : localStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ } },
};

export async function api(method, path, body) {
  let res;
  try {
    res = await fetch(base + path, {
      method,
      headers: {
        ...(body ? { 'Content-Type': 'application/json' } : {}),
        ...(session.token ? { Authorization: `Bearer ${session.token}` } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError('network', 0);
  }
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw new ApiError(data.error || 'generic', res.status);
  return data;
}

export const streamUrl = (ticket) => `${base}/api/stream?ticket=${encodeURIComponent(ticket)}`;
