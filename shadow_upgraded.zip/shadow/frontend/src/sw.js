/* Minimal service worker for persistent notification display when a compatible browser is available. */
self.addEventListener('push', (event) => {
  let data = { title: 'Shadow', body: 'New group activity' };
  try { if (event.data) data = { ...data, ...event.data.json() }; } catch { /* use safe generic notice */ }
  event.waitUntil(self.registration.showNotification(String(data.title || 'Shadow').slice(0, 60), {
    body: String(data.body || 'New group activity').slice(0, 140),
    tag: data.tag ? String(data.tag).slice(0, 100) : undefined,
    data: { url: './' },
  }));
});
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
    for (const client of clients) { if ('focus' in client) return client.focus(); }
    if (self.clients.openWindow) return self.clients.openWindow('./');
    return undefined;
  }));
});
