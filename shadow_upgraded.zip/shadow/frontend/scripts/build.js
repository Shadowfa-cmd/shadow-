'use strict';
// Copies src/ -> www/ and writes www/config.js from SHADOW_API_URL.
// No bundler is needed: the app is plain ES modules, so the build is instant and dependency-free.
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const src = path.join(root, 'src');
const out = path.join(root, 'www');
const androidBuild = process.argv.includes('--android');

function loadEnv() {
  const file = path.join(root, '.env');
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (m && !m[1].startsWith('#') && process.env[m[1]] === undefined) {
      process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  }
}

loadEnv();
const apiUrl = (process.env.SHADOW_API_URL || '').trim().replace(/\/+$/, '');
let parsedApiUrl = null;
if (apiUrl) {
  try { parsedApiUrl = new URL(apiUrl); } catch { /* checked below */ }
  if (!parsedApiUrl || !['http:', 'https:'].includes(parsedApiUrl.protocol) || !parsedApiUrl.hostname) {
    console.error(`SHADOW_API_URL is not a valid absolute http(s) URL: "${apiUrl}"`);
    process.exit(1);
  }
}
if (androidBuild && !apiUrl) {
  console.error('SHADOW_API_URL is required when building the Android APK. Set it in frontend/.env (for example, https://chat.example.com).');
  process.exit(1);
}
if (androidBuild && parsedApiUrl.protocol !== 'https:') {
  console.error('Android APK builds require an HTTPS SHADOW_API_URL to protect passwords, tokens, and messages in transit.');
  process.exit(1);
}

fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(src, out, { recursive: true });
fs.writeFileSync(
  path.join(out, 'config.js'),
  `window.SHADOW_CONFIG = ${JSON.stringify({ apiUrl })};\n`,
);

console.log(`Frontend built -> ${path.relative(process.cwd(), out) || out}`);
console.log(`API URL: ${apiUrl || '(same origin)'}`);
