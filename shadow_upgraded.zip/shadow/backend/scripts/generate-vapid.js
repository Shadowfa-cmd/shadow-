'use strict';
const { generateVapidKeys } = require('../src/webpush');
const keys = generateVapidKeys();
console.log('# Store these only in the server environment; never put the private key in frontend/.env.');
console.log(`WEB_PUSH_VAPID_PUBLIC_KEY=${keys.publicKey}`);
console.log(`WEB_PUSH_VAPID_PRIVATE_KEY=${keys.privateKey}`);
