'use strict';
const { buildConfig } = require('./src/config');
const { createApp } = require('./src/app');

async function main() {
  const config = buildConfig();
  const app = await createApp(config);

  app.server.listen(config.port, config.host, () => {
    console.log(`Shadow server listening on http://${config.host}:${config.port}`);
    console.log(`Admin username: ${config.adminUsername}`);
    console.log(app.frontendReady
      ? `Serving frontend from ${config.frontendDir}`
      : 'Frontend not served (build it with "npm run build" or set SERVE_FRONTEND=0).');
  });

  let stopping = false;
  const stop = async (signal) => {
    if (stopping) return;
    stopping = true;
    console.log(`\n${signal} received, shutting down...`);
    const force = setTimeout(() => process.exit(1), 5000);
    force.unref();
    await app.close();
    process.exit(0);
  };
  process.on('SIGINT', () => stop('SIGINT'));
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('unhandledRejection', (err) => console.error('[unhandledRejection]', err));
}

main().catch((err) => {
  console.error(`\nStartup failed: ${err.message}\n`);
  process.exit(1);
});
