'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('crypto');
const { generateVapidKeys, vapidToken, encryptPayload, isAllowedPushEndpoint } = require('../src/webpush');
const { buildConfig } = require('../src/config');
const { createApp } = require('../src/app');
const fs = require('fs');
const os = require('os');
const path = require('path');

async function boot(overrides = {}) {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'shadow-push-test-'));
  const config = buildConfig({ dataDir, port: 0, host: '127.0.0.1', adminUsername: 'boss', adminPassword: 'super-secret-1', serveFrontend: false, ...overrides });
  const app = await createApp(config);
  await new Promise((resolve) => app.server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const call = async (method, url, { token, body } = {}) => {
    const response = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: response.status, json: await response.json().catch(() => ({})) };
  };
  return { app, call, close: () => app.close() };
}

async function register(call) {
  const res = await call('POST', '/api/auth/register', { body: { username: 'push_user', password: 'pass1234', displayName: 'Push User' } });
  assert.equal(res.status, 201, JSON.stringify(res.json));
  return res.json;
}

test('VAPID key generation, JWT signing, and Web Push payload encryption have the expected structure', () => {
  const keys = generateVapidKeys();
  const endpoint = 'https://fcm.googleapis.com/fcm/send/test';
  const jwt = vapidToken(endpoint, keys.publicKey, keys.privateKey, 'mailto:ops@example.com');
  assert.equal(jwt.split('.').length, 3);
  assert.equal(JSON.parse(Buffer.from(jwt.split('.')[0], 'base64url').toString()).alg, 'ES256');
  assert.equal(JSON.parse(Buffer.from(jwt.split('.')[1], 'base64url').toString()).aud, 'https://fcm.googleapis.com');

  const browser = crypto.createECDH('prime256v1');
  browser.generateKeys();
  const subscription = { endpoint, keys: { p256dh: browser.getPublicKey(undefined, 'uncompressed').toString('base64url'), auth: crypto.randomBytes(16).toString('base64url') } };
  const encrypted = encryptPayload(subscription, Buffer.from(JSON.stringify({ body: 'generic test notice' })));
  assert.equal(encrypted.readUInt32BE(16), 4096);
  assert.equal(encrypted[20], 65);
  assert.ok(encrypted.length > 86);
});

test('Web Push endpoint allowlist blocks insecure and local endpoints', () => {
  assert.equal(isAllowedPushEndpoint('https://fcm.googleapis.com/fcm/send/test'), true);
  assert.equal(isAllowedPushEndpoint('https://updates.push.services.mozilla.com/wpush/v2/test'), true);
  assert.equal(isAllowedPushEndpoint('http://fcm.googleapis.com/test'), false);
  assert.equal(isAllowedPushEndpoint('https://127.0.0.1/private'), false);
  assert.equal(isAllowedPushEndpoint('https://attacker.example/fcm.googleapis.com'), false);
});

test('Web Push is disabled by default and a user can create/remove a valid subscription when configured', async () => {
  const off = await boot();
  try {
    const user = await register(off.call);
    const cfg = await off.call('GET', '/api/push/config', { token: user.token });
    assert.equal(cfg.json.enabled, false);
    assert.equal((await off.call('POST', '/api/push/subscribe', { token: user.token, body: { subscription: {} } })).json.error, 'push_not_configured');
  } finally { await off.close(); }

  const vapid = generateVapidKeys();
  const on = await boot({ webPushEnabled: true, webPushVapidPublicKey: vapid.publicKey, webPushVapidPrivateKey: vapid.privateKey, webPushSubject: 'mailto:ops@example.com' });
  try {
    const user = await register(on.call);
    const config = await on.call('GET', '/api/push/config', { token: user.token });
    assert.equal(config.json.enabled, true);
    assert.equal(config.json.publicKey, vapid.publicKey);
    const browser = crypto.createECDH('prime256v1');
    browser.generateKeys();
    const subscription = { endpoint: 'https://fcm.googleapis.com/fcm/send/test-endpoint', keys: { p256dh: browser.getPublicKey(undefined, 'uncompressed').toString('base64url'), auth: crypto.randomBytes(16).toString('base64url') } };
    assert.equal((await on.call('POST', '/api/push/subscribe', { token: user.token, body: { subscription } })).status, 201);
    assert.equal(on.app.store.pushSubscriptions.length, 1);
    const deletion = await on.call('DELETE', '/api/push/subscribe', { token: user.token, body: { endpoint: subscription.endpoint } });
    assert.equal(deletion.status, 200);
    assert.equal(on.app.store.pushSubscriptions.length, 0);
  } finally { await on.close(); }
});
