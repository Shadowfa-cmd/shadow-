'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const { buildConfig } = require('../src/config');
const { createApp } = require('../src/app');

async function boot(overrides = {}) {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'shadow-test-'));
  const config = buildConfig({
    dataDir,
    port: 0,
    host: '127.0.0.1',
    adminUsername: 'boss',
    adminPassword: 'super-secret-1',
    serveFrontend: false,
    ...overrides,
  });
  const app = await createApp(config);
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const call = async (method, url, { token, body } = {}) => {
    const res = await fetch(base + url, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json, headers: res.headers };
  };
  return { app, base, call, dataDir, config, close: () => app.close() };
}

/** Minimal SSE client collecting events. */
function openStream(base, ticket) {
  return new Promise((resolve, reject) => {
    const events = [];
    const req = http.get(`${base}/api/stream?ticket=${ticket}`, (res) => {
      if (res.statusCode !== 200) {
        let b = '';
        res.on('data', (c) => (b += c));
        res.on('end', () => resolve({ status: res.statusCode, body: b, events, close() {} }));
        return;
      }
      let buf = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => {
        buf += chunk;
        let i;
        while ((i = buf.indexOf('\n\n')) !== -1) {
          const block = buf.slice(0, i);
          buf = buf.slice(i + 2);
          const ev = /^event: (.+)$/m.exec(block);
          const data = /^data: (.+)$/m.exec(block);
          if (ev && data) events.push({ event: ev[1], data: JSON.parse(data[1]) });
        }
      });
      resolve({ status: 200, events, close: () => req.destroy() });
    });
    req.on('error', reject);
  });
}

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(fn, ms = 2000) {
  const end = Date.now() + ms;
  while (Date.now() < end) { const r = fn(); if (r) return r; await wait(20); }
  throw new Error('timeout waiting for condition');
}

async function register(call, username, displayName) {
  const r = await call('POST', '/api/auth/register', { body: { username, password: 'pass1234', displayName } });
  assert.equal(r.status, 201, JSON.stringify(r.json));
  return r.json;
}

test('config refuses weak/missing admin password', () => {
  assert.throws(() => buildConfig({ adminPassword: '' , dataDir: fs.mkdtempSync(path.join(os.tmpdir(), 's-')) }), /ADMIN_PASSWORD/);
});

test('register, login, display name, validation', async () => {
  const s = await boot();
  try {
    const a = await register(s.call, 'ali_1', 'علی');
    assert.equal(a.user.displayName, 'علی');

    assert.equal((await s.call('POST', '/api/auth/register', { body: { username: 'ALI_1', password: 'pass1234' } })).json.error, 'username_taken');
    assert.equal((await s.call('POST', '/api/auth/register', { body: { username: 'x', password: 'pass1234' } })).json.error, 'invalid_username');
    assert.equal((await s.call('POST', '/api/auth/register', { body: { username: 'good_name', password: '123' } })).json.error, 'invalid_password');

    const bad = await s.call('POST', '/api/auth/login', { body: { username: 'ali_1', password: 'wrong' } });
    assert.equal(bad.status, 401);
    const ok = await s.call('POST', '/api/auth/login', { body: { username: 'Ali_1', password: 'pass1234' } });
    assert.equal(ok.status, 200);

    const me = await s.call('GET', '/api/me', { token: ok.json.token });
    assert.equal(me.json.user.username, 'ali_1');

    const upd = await s.call('PATCH', '/api/me', { token: ok.json.token, body: { displayName: '  مریم \u202E  جان ' } });
    assert.equal(upd.json.user.displayName, 'مریم جان'); // bidi override stripped, spaces collapsed
    assert.equal((await s.call('PATCH', '/api/me', { token: ok.json.token, body: { displayName: 'a' } })).json.error, 'invalid_display_name');

    assert.equal((await s.call('GET', '/api/me')).status, 401);
    assert.equal((await s.call('GET', '/api/me', { token: 'garbage.token' })).status, 401);
    assert.equal((await s.call('GET', '/api/me', { token: `${ok.json.token}.unexpected` })).status, 401,
      'bearer token parser must reject extra trailing segments');
  } finally { await s.close(); }
});

test('concurrent registration reserves case-insensitive usernames atomically', async () => {
  const s = await boot();
  try {
    const results = await Promise.all([
      s.call('POST', '/api/auth/register', { body: { username: 'Race_User', password: 'pass1234' } }),
      s.call('POST', '/api/auth/register', { body: { username: 'race_user', password: 'pass5678' } }),
    ]);
    assert.deepEqual(results.map((r) => r.status).sort(), [201, 409]);
    assert.equal(s.app.store.users.filter((u) => u.username.toLowerCase() === 'race_user').length, 1);
  } finally { await s.close(); }
});

test('stream ticket creation is rate-limited per authenticated user', async () => {
  const s = await boot();
  try {
    const user = await register(s.call, 'ticket_user', 'Ticket User');
    let limited = null;
    for (let i = 0; i < 21; i++) {
      const response = await s.call('POST', '/api/stream-ticket', { token: user.token });
      if (response.status === 429) limited = response;
      else assert.equal(response.status, 200);
    }
    assert.ok(limited, 'the 21st ticket request should be rate-limited');
    const retryAfter = Number(limited.headers.get('retry-after'));
    assert.ok(Number.isInteger(retryAfter) && retryAfter >= 1 && retryAfter <= 60);
  } finally { await s.close(); }
});

test('messages broadcast over SSE, with init snapshot and presence', async () => {
  const s = await boot();
  try {
    const a = await register(s.call, 'alice', 'Alice');
    const b = await register(s.call, 'bob', 'بوب');
    const ta = (await s.call('POST', '/api/stream-ticket', { token: a.token })).json.ticket;
    const tb = (await s.call('POST', '/api/stream-ticket', { token: b.token })).json.ticket;

    const sa = await openStream(s.base, ta);
    await until(() => sa.events.find((e) => e.event === 'init'));
    const sb = await openStream(s.base, tb);
    await until(() => sb.events.find((e) => e.event === 'init'));
    await until(() => sa.events.filter((e) => e.event === 'presence').pop()?.data.count === 2);

    // ticket is one-time
    assert.equal((await openStream(s.base, ta)).status, 401);

    const text = 'سلام دنیا مرحبا hello 👋\nخط دوم';
    const sent = await s.call('POST', '/api/messages', { token: a.token, body: { text } });
    assert.equal(sent.status, 201);
    const got = await until(() => sb.events.find((e) => e.event === 'message'));
    assert.equal(got.data.text, text);
    assert.equal(got.data.name, 'Alice');

    assert.equal((await s.call('POST', '/api/messages', { token: a.token, body: { text: '   ' } })).json.error, 'invalid_message');
    assert.equal((await s.call('POST', '/api/messages', { token: a.token, body: { text: 'x'.repeat(1001) } })).json.error, 'invalid_message');

    sb.close();
    await until(() => sa.events.filter((e) => e.event === 'presence').pop()?.data.count === 1);

    // new connection receives history in init
    const t2 = (await s.call('POST', '/api/stream-ticket', { token: b.token })).json.ticket;
    const sb2 = await openStream(s.base, t2);
    const init = await until(() => sb2.events.find((e) => e.event === 'init'));
    assert.equal(init.data.messages.at(-1).text, text);
    sa.close(); sb2.close();
  } finally { await s.close(); }
});

test('message rate limit', async () => {
  const s = await boot();
  try {
    const a = await register(s.call, 'spammer', 'Spam');
    let limited = 0;
    let firstLimited = null;
    for (let i = 0; i < 12; i++) {
      const r = await s.call('POST', '/api/messages', { token: a.token, body: { text: `m${i}` } });
      if (r.status === 429) { limited++; firstLimited ||= r; }
    }
    assert.ok(limited >= 3, `expected rate limiting, got ${limited}`);
    const retryAfter = Number(firstLimited.headers.get('retry-after'));
    assert.ok(Number.isInteger(retryAfter) && retryAfter >= 1 && retryAfter <= 10,
      `Retry-After should reflect the actual 10-second message window, got ${firstLimited.headers.get('retry-after')}`);
  } finally { await s.close(); }
});

test('admin: only the configured admin has powers; ban/unban/delete/announce/delete message', async () => {
  const s = await boot();
  try {
    const user = await register(s.call, 'carol', 'Carol');
    const login = await s.call('POST', '/api/auth/login', { body: { username: 'boss', password: 'super-secret-1' } });
    assert.equal(login.status, 200);
    assert.equal(login.json.user.role, 'admin');
    const admin = login.json.token;

    // normal user cannot use admin routes
    assert.equal((await s.call('GET', '/api/admin/users', { token: user.token })).status, 403);
    assert.equal((await s.call('POST', '/api/admin/announcements', { token: user.token, body: { text: 'x' } })).status, 403);
    // there is no way to register another admin
    const sneaky = await s.call('POST', '/api/auth/register', { body: { username: 'sneaky', password: 'pass1234', role: 'admin', adminKey: 'x' } });
    assert.equal(sneaky.json.user.role, 'user');

    const tc = (await s.call('POST', '/api/stream-ticket', { token: user.token })).json.ticket;
    const sc = await openStream(s.base, tc);
    await until(() => sc.events.find((e) => e.event === 'init'));

    const list = await s.call('GET', '/api/admin/users', { token: admin });
    assert.equal(list.json.online, 1);
    assert.equal(list.json.users.find((u) => u.username === 'carol').online, true);

    // announcement reaches everyone
    await s.call('POST', '/api/admin/announcements', { token: admin, body: { text: 'Maintenance tonight' } });
    const ann = await until(() => sc.events.find((e) => e.event === 'message' && e.data.kind === 'announcement'));
    assert.equal(ann.data.text, 'Maintenance tonight');

    // delete a message
    const m = (await s.call('POST', '/api/messages', { token: user.token, body: { text: 'bad words' } })).json.message;
    assert.equal((await s.call('DELETE', `/api/admin/messages/${m.id}`, { token: admin })).status, 200);
    const removed = await until(() => sc.events.find((e) => e.event === 'messages_removed' && e.data.ids.includes(m.id)));
    assert.ok(removed);

    // ban: kicked live, cannot log in, token dead, unban restores
    const uid = user.user.id;
    assert.equal((await s.call('POST', `/api/admin/users/${uid}/ban`, { token: admin })).status, 200);
    const kick = await until(() => sc.events.find((e) => e.event === 'kick'));
    assert.equal(kick.data.reason, 'banned');
    assert.equal((await s.call('POST', '/api/auth/login', { body: { username: 'carol', password: 'pass1234' } })).json.error, 'banned');
    assert.equal((await s.call('GET', '/api/me', { token: user.token })).status, 403);
    assert.equal((await s.call('POST', `/api/admin/users/${uid}/unban`, { token: admin })).status, 200);
    assert.equal((await s.call('GET', '/api/me', { token: user.token })).status, 200);

    // admin cannot be banned/deleted
    assert.equal((await s.call('POST', '/api/admin/users/admin/ban', { token: admin })).json.error, 'cannot_target_admin');
    assert.equal((await s.call('DELETE', '/api/admin/users/admin', { token: admin })).json.error, 'cannot_target_admin');

    // delete user removes their messages
    await s.call('POST', '/api/messages', { token: user.token, body: { text: 'bye' } });
    assert.equal((await s.call('DELETE', `/api/admin/users/${uid}`, { token: admin })).status, 200);
    assert.equal((await s.call('POST', '/api/auth/login', { body: { username: 'carol', password: 'pass1234' } })).status, 401);
    assert.equal(s.app.store.recentMessages().some((x) => x.userId === uid), false);
    sc.close();
  } finally { await s.close(); }
});

test('concurrent online cap is enforced', async () => {
  const s = await boot({ maxOnline: 2 });
  try {
    const streams = [];
    for (const n of ['u_one', 'u_two']) {
      const u = await register(s.call, n, n);
      const t = (await s.call('POST', '/api/stream-ticket', { token: u.token })).json.ticket;
      streams.push(await openStream(s.base, t));
      assert.equal(streams.at(-1).status, 200);
    }
    // third user is refused at ticket time...
    const third = await register(s.call, 'u_three', 'u_three');
    const denied = await s.call('POST', '/api/stream-ticket', { token: third.token });
    assert.equal(denied.status, 503);
    assert.equal(denied.json.error, 'server_full');
    // ...and also if a ticket was obtained earlier (race) the stream itself refuses.
    streams[0].close();
    await until(() => s.app.hub.onlineCount === 1);
    const t3 = (await s.call('POST', '/api/stream-ticket', { token: third.token })).json.ticket;
    const fill = await register(s.call, 'u_four', 'u_four');
    const t4 = (await s.call('POST', '/api/stream-ticket', { token: fill.token })).json.ticket;
    const s3 = await openStream(s.base, t3);
    assert.equal(s3.status, 200);
    const s4 = await openStream(s.base, t4);
    assert.equal(s4.status, 503);
    // a second device is allowed while the account remains under its connection cap
    const again = await s.call('POST', '/api/stream-ticket', { token: third.token });
    assert.equal(again.status, 200);
    [...streams, s3].forEach((x) => x.close());
  } finally { await s.close(); }
});

test('one user may use multiple devices but active streams are capped per account', async () => {
  const s = await boot({ maxOnline: 2 });
  const streams = [];
  try {
    const user = await register(s.call, 'multi_device', 'Multi Device');
    for (let i = 0; i < 5; i++) {
      const ticketResponse = await s.call('POST', '/api/stream-ticket', { token: user.token });
      assert.equal(ticketResponse.status, 200);
      const stream = await openStream(s.base, ticketResponse.json.ticket);
      assert.equal(stream.status, 200);
      streams.push(stream);
      await until(() => s.app.hub.conns.get(user.user.id)?.size === i + 1);
    }
    const denied = await s.call('POST', '/api/stream-ticket', { token: user.token });
    assert.equal(denied.status, 503);
    assert.equal(denied.json.error, 'too_many_connections');

    streams[0].close();
    await until(() => s.app.hub.conns.get(user.user.id)?.size === 4);
    const allowedAgain = await s.call('POST', '/api/stream-ticket', { token: user.token });
    assert.equal(allowedAgain.status, 200);
  } finally {
    streams.forEach((stream) => stream.close());
    await s.close();
  }
});

test('data persists across restart; admin password can be rotated via .env', async () => {
  const s = await boot();
  const dir = s.dataDir;
  const u = await register(s.call, 'persist', 'Persist');
  await s.call('POST', '/api/messages', { token: u.token, body: { text: 'remember me' } });
  const oldAdminLogin = await s.call('POST', '/api/auth/login', { body: { username: 'boss', password: 'super-secret-1' } });
  assert.equal(oldAdminLogin.status, 200);
  assert.equal((await s.call('GET', '/api/me', { token: oldAdminLogin.json.token })).status, 200);
  await s.close();

  const s2 = await boot({ dataDir: dir, adminPassword: 'rotated-pass-2' });
  try {
    const login = await s2.call('POST', '/api/auth/login', { body: { username: 'persist', password: 'pass1234' } });
    assert.equal(login.status, 200);
    assert.equal(s2.app.store.recentMessages().at(-1).text, 'remember me');
    assert.equal((await s2.call('GET', '/api/me', { token: oldAdminLogin.json.token })).status, 401,
      'rotating the admin password must invalidate tokens issued before the rotation');
    assert.equal((await s2.call('POST', '/api/auth/login', { body: { username: 'boss', password: 'rotated-pass-2' } })).status, 200);
    assert.equal((await s2.call('POST', '/api/auth/login', { body: { username: 'boss', password: 'super-secret-1' } })).status, 401);
  } finally { await s2.close(); }
});

test('CORS preflight and unknown routes', async () => {
  const s = await boot();
  try {
    const pre = await fetch(`${s.base}/api/messages`, { method: 'OPTIONS', headers: { Origin: 'https://localhost' } });
    assert.equal(pre.status, 204);
    assert.equal(pre.headers.get('access-control-allow-origin'), '*');
    assert.equal((await s.call('GET', '/api/nope')).status, 404);
  } finally { await s.close(); }
});
