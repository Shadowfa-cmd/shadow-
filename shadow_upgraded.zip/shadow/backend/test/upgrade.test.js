'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const crypto = require('crypto');

const { buildConfig } = require('../src/config');
const { createApp } = require('../src/app');

async function boot(overrides = {}) {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'shadow-upgrade-test-'));
  const config = buildConfig({ dataDir, port: 0, host: '127.0.0.1', adminUsername: 'boss', adminPassword: 'super-secret-1', serveFrontend: false, ...overrides });
  const app = await createApp(config);
  await new Promise((resolve) => app.server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const call = async (method, url, { token, body, headers = {} } = {}) => {
    const response = await fetch(base + url, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...headers },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const json = await response.json().catch(() => ({}));
    return { status: response.status, json, headers: response.headers };
  };
  return { app, base, config, call, close: () => app.close() };
}

async function adminToken(call) {
  const login = await call('POST', '/api/auth/login', { body: { username: 'boss', password: 'super-secret-1' } });
  assert.equal(login.status, 200);
  return login.json.token;
}

async function register(call, username = 'profile_user') {
  const response = await call('POST', '/api/auth/register', { body: { username, password: 'pass1234', displayName: 'Profile User' } });
  assert.equal(response.status, 201, JSON.stringify(response.json));
  return response.json;
}

test('profile avatar updates are validated and old profile fields remain compatible', async () => {
  const s = await boot();
  try {
    const user = await register(s.call);
    assert.equal(user.user.avatar || 'violet', 'violet');
    const change = await s.call('PATCH', '/api/me', { token: user.token, body: { avatar: 'blue' } });
    assert.equal(change.status, 200);
    assert.equal(change.json.user.avatar, 'blue');
    assert.equal((await s.call('PATCH', '/api/me', { token: user.token, body: { avatar: 'https://example.invalid/avatar.png' } })).json.error, 'invalid_avatar');
    const message = await s.call('POST', '/api/messages', { token: user.token, body: { text: 'hello' } });
    assert.equal(message.json.message.source, 'internal');
    assert.equal(message.json.message.avatar, 'blue');
  } finally { await s.close(); }
});

test('public API keys are separate, scoped, hash-stored, rate limited and revocable', async () => {
  const s = await boot();
  try {
    const admin = await adminToken(s.call);
    const read = await s.call('POST', '/api/admin/api-keys', { token: admin, body: { label: 'Readonly site', scopes: ['messages:read'] } });
    assert.equal(read.status, 201, JSON.stringify(read.json));
    const secret = read.json.apiKey;
    assert.match(secret, /^shd_live_/);
    assert.notEqual(s.app.store.apiKeys[0].hash, secret);
    assert.equal((await s.call('GET', '/api/v1/messages')).status, 401);
    assert.equal((await s.call('GET', '/api/v1/messages', { headers: { 'X-API-Key': secret } })).status, 200);
    assert.equal((await s.call('POST', '/api/v1/messages', { headers: { 'X-API-Key': secret }, body: { text: 'not allowed' } })).json.error, 'api_scope_denied');
    assert.equal((await s.call('GET', '/api/v1/health')).json.ok, true);
    assert.equal((await s.call('DELETE', `/api/admin/api-keys/${read.json.key.id}`, { token: admin })).status, 200);
    assert.equal((await s.call('GET', '/api/v1/messages', { headers: { 'X-API-Key': secret } })).json.error, 'invalid_api_key');
    const audit = await s.call('GET', '/api/admin/audit', { token: admin });
    assert.ok(audit.json.entries.some((entry) => entry.action === 'api_key.create'));
    assert.ok(audit.json.entries.some((entry) => entry.action === 'api_key.revoke'));
  } finally { await s.close(); }
});

test('AI endpoint is explicitly disabled when credentials are absent', async () => {
  const s = await boot();
  try {
    const user = await register(s.call);
    const response = await s.call('POST', '/api/ai/chat', { token: user.token, body: { message: 'Hello' } });
    assert.equal(response.status, 503);
    assert.equal(response.json.error, 'ai_not_configured');
  } finally { await s.close(); }
});

test('AI endpoint calls only the configured server-side provider adapter', async () => {
  let providerAuth = '';
  let providerBody = null;
  const provider = http.createServer((req, res) => {
    providerAuth = req.headers.authorization || '';
    let body = '';
    req.on('data', (chunk) => { body += chunk; });
    req.on('end', () => {
      providerBody = JSON.parse(body);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ choices: [{ message: { content: 'Safe test answer' } }] }));
    });
  });
  await new Promise((resolve) => provider.listen(0, '127.0.0.1', resolve));
  const providerUrl = `http://127.0.0.1:${provider.address().port}/chat/completions`;
  const s = await boot({ aiEnabled: true, aiApiUrl: providerUrl, aiApiKey: 'server-only-test-key', aiModel: 'test-model', aiTimeoutMs: 3000 });
  try {
    const user = await register(s.call);
    const result = await s.call('POST', '/api/ai/chat', { token: user.token, body: { message: 'Hello', history: [{ role: 'assistant', content: 'Prior answer' }] } });
    assert.equal(result.status, 200, JSON.stringify(result.json));
    assert.equal(result.json.answer, 'Safe test answer');
    assert.equal(providerAuth, 'Bearer server-only-test-key');
    assert.equal(providerBody.model, 'test-model');
    assert.deepEqual(providerBody.messages.map((m) => m.role), ['assistant', 'user']);
    assert.equal(JSON.stringify(result.json).includes('server-only-test-key'), false);
  } finally {
    await s.close();
    await new Promise((resolve) => provider.close(resolve));
  }
});

test('Telegram webhook validates secret, only bridges configured chat, and de-duplicates updates', async () => {
  const s = await boot({ telegramEnabled: true, telegramBotToken: 'fake-token', telegramWebhookSecret: 'tg-secret-123', telegramChatId: '-100123' });
  try {
    const payload = { update_id: 12345, message: { message_id: 7, chat: { id: -100123 }, from: { first_name: 'Sam' }, text: 'from Telegram' } };
    const invalid = await s.call('POST', '/api/integrations/telegram/webhook', { body: payload });
    assert.equal(invalid.status, 401);
    const accepted = await s.call('POST', '/api/integrations/telegram/webhook', { headers: { 'X-Telegram-Bot-Api-Secret-Token': 'tg-secret-123' }, body: payload });
    assert.equal(accepted.status, 200);
    assert.equal(s.app.store.recentMessages().at(-1).source, 'telegram');
    assert.equal(s.app.store.recentMessages().at(-1).name, 'Telegram · Sam');
    const duplicate = await s.call('POST', '/api/integrations/telegram/webhook', { headers: { 'X-Telegram-Bot-Api-Secret-Token': 'tg-secret-123' }, body: payload });
    assert.equal(duplicate.json.duplicate, true);
    assert.equal(s.app.store.recentMessages().filter((m) => m.text === 'from Telegram').length, 1);
  } finally { await s.close(); }
});

test('WhatsApp webhook verifies official HMAC signature and verifies subscription challenge', async () => {
  const s = await boot({
    whatsappEnabled: true, whatsappAccessToken: 'fake-access', whatsappPhoneNumberId: 'phone-id-123',
    whatsappVerifyToken: 'verify-token-123', whatsappAppSecret: 'meta-app-secret', whatsappTo: '15550001111',
  });
  try {
    const verifyUrl = '/api/integrations/whatsapp/webhook?hub.mode=subscribe&hub.verify_token=verify-token-123&hub.challenge=challenge-777';
    const verify = await fetch(s.base + verifyUrl);
    assert.equal(verify.status, 200);
    assert.equal(await verify.text(), 'challenge-777');

    const body = JSON.stringify({ object: 'whatsapp_business_account', entry: [{ changes: [{ value: {
      metadata: { phone_number_id: 'phone-id-123' }, contacts: [{ wa_id: '15551234567', profile: { name: 'Test Contact' } }],
      messages: [{ id: 'wamid.test-event-1', from: '15551234567', type: 'text', text: { body: 'from WhatsApp' } }],
    }, field: 'messages' }] }] });
    const signature = 'sha256=' + crypto.createHmac('sha256', 'meta-app-secret').update(Buffer.from(body)).digest('hex');
    const invalid = await fetch(s.base + '/api/integrations/whatsapp/webhook', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Hub-Signature-256': 'sha256=bad' }, body });
    assert.equal(invalid.status, 401);
    const accepted = await fetch(s.base + '/api/integrations/whatsapp/webhook', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Hub-Signature-256': signature }, body });
    assert.equal(accepted.status, 200);
    assert.equal(s.app.store.recentMessages().at(-1).source, 'whatsapp');
    assert.equal(s.app.store.recentMessages().at(-1).name, 'WhatsApp · Test Contact');
    const duplicate = await fetch(s.base + '/api/integrations/whatsapp/webhook', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Hub-Signature-256': signature }, body });
    assert.equal(duplicate.status, 200);
    assert.equal(s.app.store.recentMessages().filter((m) => m.text === 'from WhatsApp').length, 1);
  } finally { await s.close(); }
});

test('AI provider timeout is translated to a safe timeout error', async () => {
  const provider = http.createServer(() => { /* intentionally never respond; AbortSignal should stop the request */ });
  await new Promise((resolve) => provider.listen(0, '127.0.0.1', resolve));
  const providerUrl = `http://127.0.0.1:${provider.address().port}/chat/completions`;
  const s = await boot({ aiEnabled: true, aiApiUrl: providerUrl, aiApiKey: 'timeout-only-test-key', aiModel: 'test-model', aiTimeoutMs: 1000 });
  try {
    const user = await register(s.call, 'timeout_user');
    const result = await s.call('POST', '/api/ai/chat', { token: user.token, body: { message: 'time out please' } });
    assert.equal(result.status, 504);
    assert.equal(result.json.error, 'ai_timeout');
  } finally {
    await s.close();
    provider.closeAllConnections?.();
    await new Promise((resolve) => provider.close(resolve));
  }
});

test('Telegram-origin messages are not echoed back to Telegram', async () => {
  const originalFetch = global.fetch;
  const telegramCalls = [];
  global.fetch = async (url, options) => {
    const target = String(url);
    if (target.startsWith('https://api.telegram.org/')) {
      telegramCalls.push({ url: target, body: JSON.parse(options.body) });
      return new Response(JSON.stringify({ ok: true, result: {} }), { status: 200, headers: { 'Content-Type': 'application/json' } });
    }
    return originalFetch(url, options);
  };
  const s = await boot({ telegramEnabled: true, telegramBotToken: 'fake-token', telegramWebhookSecret: 'tg-secret-123', telegramChatId: '-100123' });
  try {
    const incoming = { update_id: 986, message: { message_id: 3, chat: { id: -100123 }, from: { first_name: 'A' }, text: 'should not echo' } };
    const accepted = await s.call('POST', '/api/integrations/telegram/webhook', { headers: { 'X-Telegram-Bot-Api-Secret-Token': 'tg-secret-123' }, body: incoming });
    assert.equal(accepted.status, 200);
    await new Promise((resolve) => setTimeout(resolve, 20));
    assert.equal(telegramCalls.length, 0);
    const admin = await adminToken(s.call);
    const user = await s.call('POST', '/api/auth/register', { body: { username: 'local_sender', password: 'pass1234', displayName: 'Local Sender' } });
    assert.equal(user.status, 201);
    const sent = await s.call('POST', '/api/messages', { token: user.json.token, body: { text: 'send out normally' } });
    assert.equal(sent.status, 201);
    await new Promise((resolve) => setTimeout(resolve, 20));
    assert.equal(telegramCalls.length, 1);
    assert.equal(telegramCalls[0].body.chat_id, '-100123');
    assert.ok(telegramCalls[0].body.text.includes('send out normally'));
    assert.ok(admin); // ensure the admin account remains usable during bridge operation
  } finally {
    await s.close();
    global.fetch = originalFetch;
  }
});

test('WhatsApp free-form outbound messages are sent only while a verified 24-hour window is open', async () => {
  const originalFetch = global.fetch;
  const outbound = [];
  global.fetch = async (url, options) => {
    const target = String(url);
    if (target.startsWith('https://graph.facebook.com/')) {
      outbound.push({ url: target, body: JSON.parse(options.body) });
      return new Response(JSON.stringify({ messages: [{ id: 'wamid.mock-outbound' }] }), { status: 200, headers: { 'Content-Type': 'application/json' } });
    }
    return originalFetch(url, options);
  };
  const s = await boot({
    whatsappEnabled: true, whatsappAccessToken: 'fake-access', whatsappPhoneNumberId: 'phone-id-123',
    whatsappVerifyToken: 'verify-token-123', whatsappAppSecret: 'meta-app-secret', whatsappTo: '15551234567', whatsappApiVersion: 'v25.0',
  });
  try {
    const user = await register(s.call, 'wa_window_user');
    assert.equal((await s.call('POST', '/api/messages', { token: user.token, body: { text: 'before customer message' } })).status, 201);
    await new Promise((resolve) => setTimeout(resolve, 20));
    assert.equal(outbound.length, 0);

    const payload = JSON.stringify({ entry: [{ changes: [{ value: {
      metadata: { phone_number_id: 'phone-id-123' }, contacts: [{ wa_id: '15551234567', profile: { name: 'Test Contact' } }],
      messages: [{ id: 'wamid.window-open', from: '15551234567', type: 'text', text: { body: 'open the support window' } }],
    } }] }] });
    const signature = 'sha256=' + crypto.createHmac('sha256', 'meta-app-secret').update(Buffer.from(payload)).digest('hex');
    const received = await fetch(s.base + '/api/integrations/whatsapp/webhook', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Hub-Signature-256': signature }, body: payload });
    assert.equal(received.status, 200);
    assert.equal((await s.call('POST', '/api/messages', { token: user.token, body: { text: 'within support window' } })).status, 201);
    await new Promise((resolve) => setTimeout(resolve, 20));
    assert.equal(outbound.length, 1);
    assert.equal(outbound[0].body.to, '15551234567');
    assert.ok(outbound[0].body.text.body.includes('within support window'));
  } finally {
    await s.close();
    global.fetch = originalFetch;
  }
});
