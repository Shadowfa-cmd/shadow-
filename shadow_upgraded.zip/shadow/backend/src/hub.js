'use strict';

/** Server-Sent-Events hub: one group, many connections (a user may have several tabs/devices). */
class Hub {
  constructor({ maxOnline, maxConnectionsPerUser = 5 }) {
    this.maxOnline = maxOnline;
    this.maxConnectionsPerUser = maxConnectionsPerUser;
    this.conns = new Map(); // userId -> Set<res>
    this.names = new Map(); // userId -> display name
    this.profiles = new Map();
    this._beat = setInterval(() => this._heartbeat(), 20000);
    this._beat.unref();
  }

  get onlineCount() { return this.conns.size; }
  isOnline(userId) { return this.conns.has(userId); }
  canAccept(userId) {
    const existing = this.conns.get(userId);
    if (existing) return existing.size < this.maxConnectionsPerUser;
    return this.conns.size < this.maxOnline;
  }

  presence() {
    const users = [...this.names].map(([id, name]) => ({ id, name, ...(this.profiles.get(id) || {}) }));
    users.sort((a, b) => a.name.localeCompare(b.name));
    return { count: users.length, users };
  }

  add(user, res) {
    const first = !this.conns.has(user.id);
    if (first) this.conns.set(user.id, new Set());
    this.conns.get(user.id).add(res);
    this.names.set(user.id, user.displayName);
    this.profiles.set(user.id, { username: user.username, avatar: user.avatar || 'violet', role: user.role || 'user', createdAt: user.createdAt });
    if (first) this.broadcast('presence', this.presence());
    return first;
  }

  remove(userId, res) {
    const set = this.conns.get(userId);
    if (!set) return;
    set.delete(res);
    if (set.size === 0) {
      this.conns.delete(userId);
      this.names.delete(userId);
      this.profiles.delete(userId);
      this.broadcast('presence', this.presence());
    }
  }

  rename(userId, name) {
    if (!this.names.has(userId)) return;
    this.names.set(userId, name);
    const profile = this.profiles.get(userId);
    if (profile) this.profiles.set(userId, { ...profile, displayName: name });
    this.broadcast('presence', this.presence());
  }

  updateProfile(user) {
    if (!user || !this.names.has(user.id)) return;
    this.names.set(user.id, user.displayName);
    this.profiles.set(user.id, { username: user.username, avatar: user.avatar || 'violet', role: user.role || 'user', createdAt: user.createdAt, displayName: user.displayName });
    this.broadcast('presence', this.presence());
  }

  _write(res, chunk) {
    try {
      if (res.destroyed || res.writableLength > 1024 * 1024) { res.destroy(); return false; }
      res.write(chunk);
      return true;
    } catch {
      return false;
    }
  }

  send(res, event, data) {
    return this._write(res, `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  }

  broadcast(event, data) {
    const chunk = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
    for (const set of this.conns.values()) for (const res of set) this._write(res, chunk);
  }

  /** Tell the user why, then drop every connection they have. */
  kick(userId, reason) {
    const set = this.conns.get(userId);
    if (!set) return;
    for (const res of [...set]) {
      this.send(res, 'kick', { reason });
      try { res.end(); } catch { /* already closed */ }
    }
    this.conns.delete(userId);
    this.names.delete(userId);
    this.profiles.delete(userId);
    this.broadcast('presence', this.presence());
  }

  _heartbeat() {
    for (const set of this.conns.values()) for (const res of set) this._write(res, ': ping\n\n');
  }

  close() {
    clearInterval(this._beat);
    for (const set of this.conns.values()) for (const res of set) { try { res.end(); } catch { /* ignore */ } }
    this.conns.clear();
    this.names.clear();
    this.profiles.clear();
  }
}

module.exports = { Hub };
