'use strict';
const crypto = require('crypto');
const { promisify } = require('util');

const scrypt = promisify(crypto.scrypt);
const KEYLEN = 64;

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = (await scrypt(String(password), salt, KEYLEN)).toString('hex');
  return `${salt}:${hash}`;
}

async function verifyPassword(password, stored) {
  const [salt, hash] = String(stored || '').split(':');
  if (!salt || !hash) return false;
  const test = await scrypt(String(password), salt, KEYLEN);
  const expected = Buffer.from(hash, 'hex');
  return expected.length === test.length && crypto.timingSafeEqual(test, expected);
}

const b64 = (buf) => Buffer.from(buf).toString('base64url');

/** Signed, expiring bearer token: base64url(payload).hmac */
function createTokens(secret, ttlDays) {
  const ttl = ttlDays * 86400 * 1000;
  const sign = (data) => crypto.createHmac('sha256', secret).update(data).digest('base64url');

  return {
    issue(userId, version = 0) {
      const body = b64(JSON.stringify({ sub: userId, exp: Date.now() + ttl, ver: version }));
      return `${body}.${sign(body)}`;
    },
    verify(token) {
      if (typeof token !== 'string' || token.length > 512) return null;
      const parts = token.split('.');
      if (parts.length !== 2) return null;
      const [body, sig] = parts;
      if (!body || !sig) return null;
      const expected = Buffer.from(sign(body));
      const given = Buffer.from(sig);
      if (expected.length !== given.length || !crypto.timingSafeEqual(expected, given)) return null;
      try {
        const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
        if (typeof payload.sub !== 'string' || !payload.sub || typeof payload.exp !== 'number' || payload.exp < Date.now()) return null;
        // Tokens issued before versioning remain valid as version 0, unless the
        // account's version was deliberately incremented to revoke old sessions.
        const version = payload.ver === undefined ? 0 : payload.ver;
        if (!Number.isSafeInteger(version) || version < 0) return null;
        return { sub: payload.sub, version };
      } catch {
        return null;
      }
    },
  };
}

/** One-time, short-lived tickets so the SSE URL never contains the real token. */
function createTickets(ttlMs = 30000) {
  const map = new Map();
  const timer = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of map) if (v.exp <= now) map.delete(k);
  }, 15000);
  timer.unref();
  return {
    issue(userId) {
      const t = crypto.randomBytes(24).toString('base64url');
      map.set(t, { userId, exp: Date.now() + ttlMs });
      return t;
    },
    consume(ticket) {
      const e = map.get(ticket);
      if (!e) return null;
      map.delete(ticket);
      return e.exp > Date.now() ? e.userId : null;
    },
    stop() { clearInterval(timer); },
  };
}

module.exports = { hashPassword, verifyPassword, createTokens, createTickets };
