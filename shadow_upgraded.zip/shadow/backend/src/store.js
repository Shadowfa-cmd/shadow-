'use strict';
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

/** Small JSON-file persistence. Keep legacy users/messages readable across schema upgrades. */
class Store {
  constructor(dir, { maxMessages = 1000 } = {}) {
    this.file = path.join(dir, 'shadow-data.json');
    this.tmp = `${this.file}.tmp`;
    this.maxMessages = maxMessages;
    this.data = { version: 3, users: [], messages: [], apiKeys: [], auditLogs: [], processedUpdates: [], pushSubscriptions: [] };
    this.byId = new Map();
    this.byName = new Map();
    this._timer = null;
    this._writing = false;
    this._again = false;
    this._writePromise = null;
    this._load();
  }

  _load() {
    let raw;
    try { raw = fs.readFileSync(this.file, 'utf8'); }
    catch (err) { if (err.code === 'ENOENT') return; throw err; }
    try {
      const parsed = JSON.parse(raw);
      this.data.version = 3;
      this.data.users = Array.isArray(parsed.users) ? parsed.users : [];
      this.data.messages = Array.isArray(parsed.messages) ? parsed.messages : [];
      this.data.apiKeys = Array.isArray(parsed.apiKeys) ? parsed.apiKeys : [];
      this.data.auditLogs = Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [];
      this.data.processedUpdates = Array.isArray(parsed.processedUpdates) ? parsed.processedUpdates : [];
      this.data.pushSubscriptions = Array.isArray(parsed.pushSubscriptions) ? parsed.pushSubscriptions : [];
      // Add safe defaults for records created by older versions.
      for (const user of this.data.users) {
        if (!user.avatar) user.avatar = 'violet';
      }
      for (const message of this.data.messages) {
        if (!message.source) message.source = 'internal';
      }
    } catch {
      const backup = `${this.file}.corrupt-${Date.now()}`;
      fs.renameSync(this.file, backup);
      console.error(`[store] data file was corrupt; moved to ${backup} and started empty.`);
    }
    for (const u of this.data.users) this._index(u);
  }

  _index(u) { this.byId.set(u.id, u); this.byName.set(u.username.toLowerCase(), u); }
  getUser(id) { return this.byId.get(id) || null; }
  findByUsername(name) { return this.byName.get(String(name).toLowerCase()) || null; }
  get users() { return this.data.users; }
  get apiKeys() { return this.data.apiKeys; }
  get pushSubscriptions() { return this.data.pushSubscriptions; }

  savePushSubscription(subscription) {
    const index = this.data.pushSubscriptions.findIndex((item) => item.userId === subscription.userId && item.endpoint === subscription.endpoint);
    if (index >= 0) this.data.pushSubscriptions[index] = { ...this.data.pushSubscriptions[index], ...subscription, updatedAt: Date.now() };
    else this.data.pushSubscriptions.push({ ...subscription, createdAt: Date.now() });
    this.save();
  }
  removePushSubscription(userId, endpoint) {
    const before = this.data.pushSubscriptions.length;
    this.data.pushSubscriptions = this.data.pushSubscriptions.filter((item) => !(item.userId === userId && item.endpoint === endpoint));
    if (before !== this.data.pushSubscriptions.length) this.save();
    return before !== this.data.pushSubscriptions.length;
  }
  removePushSubscriptionsByUser(userId) {
    const before = this.data.pushSubscriptions.length;
    this.data.pushSubscriptions = this.data.pushSubscriptions.filter((item) => item.userId !== userId);
    if (before !== this.data.pushSubscriptions.length) this.save();
  }

  addUser(user) {
    this.data.users.push(user); this._index(user); this.save(); return user;
  }
  renameUsername(user, newName) {
    this.byName.delete(user.username.toLowerCase()); user.username = newName;
    this.byName.set(newName.toLowerCase(), user); this.save();
  }
  removeUser(id) {
    const u = this.byId.get(id); if (!u) return null;
    this.byId.delete(id); this.byName.delete(u.username.toLowerCase());
    this.data.users = this.data.users.filter((x) => x.id !== id);
    this.removePushSubscriptionsByUser(id);
    this.save(); return u;
  }
  addMessage(msg) {
    const list = this.data.messages; list.push(msg);
    if (list.length > this.maxMessages) list.splice(0, list.length - this.maxMessages);
    this.save(); return msg;
  }
  removeMessage(id) {
    const i = this.data.messages.findIndex((m) => m.id === id);
    if (i === -1) return false;
    this.data.messages.splice(i, 1); this.save(); return true;
  }
  removeMessagesByUser(userId) {
    const ids = [];
    this.data.messages = this.data.messages.filter((m) => {
      if (m.userId === userId) { ids.push(m.id); return false; }
      return true;
    });
    if (ids.length) this.save(); return ids;
  }
  recentMessages(n = 200) { return this.data.messages.slice(-n); }

  addAudit(entry) {
    this.data.auditLogs.push({ id: require('crypto').randomUUID(), ts: Date.now(), ...entry });
    if (this.data.auditLogs.length > 500) this.data.auditLogs.splice(0, this.data.auditLogs.length - 500);
    this.save();
  }
  recentAudit(n = 100) { return this.data.auditLogs.slice(-n).reverse(); }

  addApiKey(key) { this.data.apiKeys.push(key); this.save(); return key; }
  findApiKeyByHash(hash) { return this.data.apiKeys.find((k) => k.hash === hash && !k.revokedAt) || null; }
  revokeApiKey(id) {
    const key = this.data.apiKeys.find((k) => k.id === id && !k.revokedAt);
    if (!key) return null;
    key.revokedAt = Date.now(); this.save(); return key;
  }

  hasProcessedUpdate(source, eventId) {
    return this.data.processedUpdates.includes(`${source}:${String(eventId)}`);
  }
  rememberProcessedUpdate(source, eventId) {
    const id = `${source}:${String(eventId)}`;
    if (this.data.processedUpdates.includes(id)) return;
    this.data.processedUpdates.push(id);
    if (this.data.processedUpdates.length > 5000) this.data.processedUpdates.splice(0, this.data.processedUpdates.length - 5000);
    this.save();
  }

  save() {
    if (this._writing) { this._again = true; return; }
    if (this._timer) return;
    this._timer = setTimeout(() => { this._timer = null; void this._write(); }, 150);
  }

  async _write() {
    if (this._writing) { this._again = true; return this._writePromise; }
    this._writing = true;
    this._writePromise = (async () => {
      try {
        do {
          this._again = false;
          // Unique temporary name prevents a close/flush or another writer from
          // renaming the same staging file while an asynchronous write is active.
          const temp = `${this.tmp}.${process.pid}.${require('crypto').randomUUID()}`;
          try {
            await fsp.writeFile(temp, JSON.stringify(this.data), { mode: 0o600 });
            await fsp.rename(temp, this.file);
            await fsp.chmod(this.file, 0o600).catch(() => {});
          } finally {
            await fsp.unlink(temp).catch(() => {});
          }
        } while (this._again);
      } catch (err) { console.error('[store] save failed:', err.message); }
      finally { this._writing = false; this._writePromise = null; }
    })();
    return this._writePromise;
  }

  async flush() {
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    if (this._writing) {
      this._again = true;
      await this._writePromise;
    } else {
      await this._write();
    }
  }

  flushSync() {
    if (this._writing) throw new Error('Store write in progress; await flush() instead.');
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    const temp = `${this.tmp}.${process.pid}.${require('crypto').randomUUID()}`;
    try {
      fs.writeFileSync(temp, JSON.stringify(this.data), { mode: 0o600 });
      fs.renameSync(temp, this.file);
      try { fs.chmodSync(this.file, 0o600); } catch { /* platform may not support chmod */ }
    } catch (err) { console.error('[store] final save failed:', err.message); }
    finally { try { fs.unlinkSync(temp); } catch { /* already renamed or missing */ } }
  }
}
module.exports = { Store };
