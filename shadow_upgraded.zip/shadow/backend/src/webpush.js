'use strict';
const crypto = require('crypto');

const b64url = (value) => Buffer.from(value).toString('base64url');
const fromB64url = (value) => Buffer.from(String(value || ''), 'base64url');

function generateVapidKeys() {
  const pair = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const jwk = pair.privateKey.export({ format: 'jwk' });
  const publicKey = Buffer.concat([Buffer.from([4]), fromB64url(jwk.x), fromB64url(jwk.y)]);
  return { publicKey: b64url(publicKey), privateKey: jwk.d };
}

function publicKeyCoordinates(publicKey) {
  const raw = fromB64url(publicKey);
  if (raw.length !== 65 || raw[0] !== 4) throw new Error('invalid VAPID public key');
  return { x: b64url(raw.subarray(1, 33)), y: b64url(raw.subarray(33, 65)) };
}

function vapidToken(endpoint, publicKey, privateKey, subject = 'mailto:admin@example.invalid') {
  const url = new URL(endpoint);
  const coordinates = publicKeyCoordinates(publicKey);
  const header = b64url(JSON.stringify({ typ: 'JWT', alg: 'ES256' }));
  const payload = b64url(JSON.stringify({ aud: url.origin, exp: Math.floor(Date.now() / 1000) + 12 * 60 * 60, sub: subject }));
  const input = `${header}.${payload}`;
  const signingKey = crypto.createPrivateKey({ key: { kty: 'EC', crv: 'P-256', ...coordinates, d: privateKey }, format: 'jwk' });
  const signature = crypto.sign('sha256', Buffer.from(input), { key: signingKey, dsaEncoding: 'ieee-p1363' });
  return `${input}.${b64url(signature)}`;
}

function encryptPayload(subscription, payload) {
  const uaPublicKey = fromB64url(subscription?.keys?.p256dh);
  const authSecret = fromB64url(subscription?.keys?.auth);
  if (uaPublicKey.length !== 65 || uaPublicKey[0] !== 4 || authSecret.length < 16) throw new Error('invalid subscription keys');

  const ecdh = crypto.createECDH('prime256v1');
  ecdh.generateKeys();
  const asPublicKey = ecdh.getPublicKey(undefined, 'uncompressed');
  const sharedSecret = ecdh.computeSecret(uaPublicKey);
  const keyInfo = Buffer.concat([Buffer.from('WebPush: info\0', 'utf8'), uaPublicKey, asPublicKey]);
  // RFC 8291: first extract with the browser's auth secret, then expand with key_info.
  const authPrk = crypto.createHmac('sha256', authSecret).update(sharedSecret).digest();
  const ikm = crypto.createHmac('sha256', authPrk).update(Buffer.concat([keyInfo, Buffer.from([1])])).digest();
  const salt = crypto.randomBytes(16);
  const cek = Buffer.from(crypto.hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: aes128gcm\0', 'utf8'), 16));
  const nonce = Buffer.from(crypto.hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: nonce\0', 'utf8'), 12));
  const plaintext = Buffer.concat([Buffer.from(payload), Buffer.from([2])]); // final-record delimiter, no message padding
  const cipher = crypto.createCipheriv('aes-128-gcm', cek, nonce);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final(), cipher.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096, 0);
  return Buffer.concat([salt, rs, Buffer.from([asPublicKey.length]), asPublicKey, ciphertext]);
}

function isAllowedPushEndpoint(endpoint) {
  let url;
  try { url = new URL(endpoint); } catch { return false; }
  if (url.protocol !== 'https:' || url.username || url.password || url.port) return false;
  const host = url.hostname.toLowerCase();
  return host === 'fcm.googleapis.com'
    || host === 'updates.push.services.mozilla.com'
    || host.endsWith('.push.services.mozilla.com')
    || host === 'web.push.apple.com'
    || host.endsWith('.push.apple.com')
    || host.endsWith('.notify.windows.com');
}

async function sendWebPush(subscription, payload, { publicKey, privateKey, subject, timeoutMs = 8000 }) {
  if (!isAllowedPushEndpoint(subscription.endpoint)) throw new Error('unsupported push endpoint');
  const body = encryptPayload(subscription, Buffer.from(JSON.stringify(payload)));
  if (body.length > 4096) throw new Error('push payload too large');
  const token = vapidToken(subscription.endpoint, publicKey, privateKey, subject);
  return fetch(subscription.endpoint, {
    method: 'POST',
    headers: {
      Authorization: `vapid t=${token}, k=${publicKey}`,
      'Content-Encoding': 'aes128gcm',
      'Content-Type': 'application/octet-stream',
      TTL: '60',
      Urgency: 'normal',
    },
    body,
    signal: AbortSignal.timeout(timeoutMs),
  });
}

module.exports = { generateVapidKeys, vapidToken, encryptPayload, isAllowedPushEndpoint, sendWebPush };
