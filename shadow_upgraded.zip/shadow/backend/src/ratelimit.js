'use strict';

/** Fixed-window in-memory rate limiter. */
function createLimiter({ max, windowMs }) {
  const hits = new Map();
  const timer = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of hits) if (v.reset <= now) hits.delete(k);
  }, Math.max(windowMs, 30000));
  timer.unref();

  return {
    /** Returns 0 if allowed, otherwise the seconds until retry. */
    hit(key) {
      const now = Date.now();
      let e = hits.get(key);
      if (!e || e.reset <= now) {
        e = { count: 0, reset: now + windowMs };
        hits.set(key, e);
      }
      e.count += 1;
      return e.count > max ? Math.ceil((e.reset - now) / 1000) : 0;
    },
    stop() { clearInterval(timer); },
  };
}

module.exports = { createLimiter };
