'use strict';
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');

const { Store } = require('./store');
const { Hub } = require('./hub');
const { createLimiter } = require('./ratelimit');
const { hashPassword, verifyPassword, createTokens, createTickets } = require('./auth');
const v = require('./validate');
const { HttpError, sendJson, readRaw, readJson, serveStatic } = require('./http-utils');
const { sendWebPush, isAllowedPushEndpoint } = require('./webpush');

const DUMMY_HASH = `${'0'.repeat(32)}:${'0'.repeat(128)}`;

async function createApp(config) {
  const store = new Store(config.dataDir, { maxMessages: config.maxStoredMessages });
  const hub = new Hub({ maxOnline: config.maxOnline });
  const tokens = createTokens(config.jwtSecret, config.tokenTtlDays);
  const tickets = createTickets();

  const loginIpLimit = createLimiter({ max: 30, windowMs: 10 * 60 * 1000 });
  const loginNameLimit = createLimiter({ max: 10, windowMs: 10 * 60 * 1000 });
  const registerLimit = createLimiter({ max: 30, windowMs: 60 * 60 * 1000 });
  const messageLimit = createLimiter({ max: 8, windowMs: 10 * 1000 });
  const streamTicketLimit = createLimiter({ max: 20, windowMs: 60 * 1000 });
  const editLimit = createLimiter({ max: 10, windowMs: 10 * 60 * 1000 });
  const aiLimit = createLimiter({ max: 8, windowMs: 10 * 60 * 1000 });
  const webhookLimit = createLimiter({ max: 300, windowMs: 60 * 1000 });
  const apiKeyLimiters = new Map();
  // WhatsApp free-form text is sent only within the 24-hour customer-service window
  // opened by an inbound message from the configured destination. This fails closed after restart.
  const whatsappLastInboundAt = new Map();
  // Password hashing is asynchronous; reserve usernames before awaiting it so
  // simultaneous sign-ups cannot create duplicate case-insensitive usernames.
  const registeringUsernames = new Set();
  const limiters = [loginIpLimit, loginNameLimit, registerLimit, messageLimit, streamTicketLimit, editLimit, aiLimit, webhookLimit];

  /* ---------- admin account (single, from .env) ---------- */
  async function ensureAdmin() {
    let admin = store.users.find((u) => u.role === 'admin');
    if (!admin) {
      const clash = store.findByUsername(config.adminUsername);
      if (clash) throw new Error(`ADMIN_USERNAME "${config.adminUsername}" is already used by a normal user.`);
      admin = store.addUser({
        id: 'admin',
        username: config.adminUsername,
        displayName: config.adminUsername,
        passwordHash: await hashPassword(config.adminPassword),
        role: 'admin',
        avatar: 'violet',
        banned: false,
        tokenVersion: 0,
        createdAt: Date.now(),
      });
      return;
    }
    if (admin.username.toLowerCase() !== config.adminUsername.toLowerCase()) {
      const clash = store.findByUsername(config.adminUsername);
      if (clash && clash.id !== admin.id) throw new Error(`ADMIN_USERNAME "${config.adminUsername}" is already used by a normal user.`);
      store.renameUsername(admin, config.adminUsername);
    }
    if (!(await verifyPassword(config.adminPassword, admin.passwordHash))) {
      admin.passwordHash = await hashPassword(config.adminPassword);
      const version = Number.isSafeInteger(admin.tokenVersion) && admin.tokenVersion >= 0
        ? admin.tokenVersion : 0;
      admin.tokenVersion = version + 1;
      store.save();
    }
  }
  await ensureAdmin();

  /* ---------- helpers ---------- */
  const publicUser = (u) => ({
    id: u.id, username: u.username, displayName: u.displayName,
    role: u.role, avatar: v.avatar(u.avatar) || 'violet', createdAt: u.createdAt,
  });
  const publicMessage = (m) => ({
    id: m.id, userId: m.userId, name: m.name, text: m.text, kind: m.kind,
    source: ['internal', 'api', 'telegram', 'whatsapp', 'ai'].includes(m.source) ? m.source : 'internal',
    avatar: v.avatar(m.avatar) || 'violet', ts: m.ts,
  });

  function clientIp(req) {
    if (config.trustProxy) {
      const xff = req.headers['x-forwarded-for'];
      if (xff) return String(xff).split(',')[0].trim();
    }
    return req.socket.remoteAddress || 'unknown';
  }

  function authenticate(req) {
    const header = req.headers.authorization || '';
    const claims = header.startsWith('Bearer ') ? tokens.verify(header.slice(7)) : null;
    const user = claims ? store.getUser(claims.sub) : null;
    const version = user && Number.isSafeInteger(user.tokenVersion) && user.tokenVersion >= 0
      ? user.tokenVersion : 0;
    if (!user || claims.version !== version) throw new HttpError(401, 'unauthorized');
    if (user.banned) throw new HttpError(403, 'banned');
    return user;
  }

  function requireAdmin(req) {
    const user = authenticate(req);
    if (user.role !== 'admin') throw new HttpError(403, 'forbidden');
    return user;
  }

  function limit(limiter, key) {
    const retry = limiter.hit(key);
    if (retry) {
      const err = new HttpError(429, 'rate_limited');
      err.retryAfter = retry;
      throw err;
    }
  }

  function newMessage(user, text, kind, source = 'internal') {
    return store.addMessage({
      id: crypto.randomUUID(), userId: user.id, name: user.displayName,
      text, kind, source, avatar: v.avatar(user.avatar) || 'violet', ts: Date.now(),
    });
  }

  function validApiKey(req, scope) {
    const raw = String(req.headers['x-api-key'] || '');
    if (!raw || raw.length > 256) throw new HttpError(401, 'api_key_required');
    const hash = crypto.createHash('sha256').update(raw).digest('hex');
    const key = store.findApiKeyByHash(hash);
    if (!key) throw new HttpError(401, 'invalid_api_key');
    if (!Array.isArray(key.scopes) || !key.scopes.includes(scope)) throw new HttpError(403, 'api_scope_denied');
    let limiter = apiKeyLimiters.get(key.id);
    if (!limiter) { limiter = createLimiter({ max: 120, windowMs: 60 * 1000 }); apiKeyLimiters.set(key.id, limiter); }
    limit(limiter, key.id);
    return key;
  }

  function integrationReady(name) {
    if (name === 'telegram') return !!(config.telegramEnabled && config.telegramBotToken && config.telegramWebhookSecret && config.telegramChatId);
    if (name === 'whatsapp') return !!(config.whatsappEnabled && config.whatsappAccessToken && config.whatsappPhoneNumberId && config.whatsappVerifyToken && config.whatsappAppSecret);
    return false;
  }

  function safeExternalError(source, err) {
    // Never print provider URLs, response bodies, or exception text: these can contain tokens.
    const name = err && err.name;
    const code = name === 'TimeoutError' || name === 'AbortError' ? 'timeout'
      : /^telegram_http_\d{3}$/.test(String(err && err.message || '')) ? String(err.message)
      : /^whatsapp_http_\d{3}$/.test(String(err && err.message || '')) ? String(err.message)
      : 'request_failed';
    console.error(`[integration:${source}] outbound failed (${code})`);
  }

  async function sendTelegram(text) {
    if (!integrationReady('telegram')) return;
    const response = await fetch(`https://api.telegram.org/bot${config.telegramBotToken}/sendMessage`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: config.telegramChatId, text }),
      signal: AbortSignal.timeout(8000),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || result.ok !== true) throw new Error(`telegram_http_${response.status}`);
  }

  async function sendWhatsApp(text) {
    if (!(integrationReady('whatsapp') && config.whatsappTo)) return;
    const recipient = String(config.whatsappTo).replace(/\D/g, '');
    const lastInbound = whatsappLastInboundAt.get(recipient) || 0;
    // Free-form business replies require an open customer-service window. Templates are not implemented here.
    if (!recipient || !lastInbound || Date.now() - lastInbound >= 24 * 60 * 60 * 1000) return;
    const version = /^v\d+\.\d+$/.test(config.whatsappApiVersion) ? config.whatsappApiVersion : 'v25.0';
    const response = await fetch(`https://graph.facebook.com/${version}/${encodeURIComponent(config.whatsappPhoneNumberId)}/messages`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${config.whatsappAccessToken}` },
      body: JSON.stringify({ messaging_product: 'whatsapp', recipient_type: 'individual', to: config.whatsappTo, type: 'text', text: { preview_url: false, body: text.slice(0, 4000) } }),
      signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) throw new Error(`whatsapp_http_${response.status}`);
  }

  function relayMessageToIntegrations(message) {
    if (!message || !['internal', 'api', 'telegram', 'whatsapp'].includes(message.source)) return;
    const text = `${message.name}: ${message.text}`;
    // Never echo a message back to the platform it came from; the other bridge may still receive it.
    if (message.source !== 'telegram') void sendTelegram(text).catch((err) => safeExternalError('telegram', err));
    if (message.source !== 'whatsapp') void sendWhatsApp(text).catch((err) => safeExternalError('whatsapp', err));
  }

  function secureEqualText(a, b) {
    const left = Buffer.from(String(a || '')); const right = Buffer.from(String(b || ''));
    return left.length === right.length && left.length > 0 && crypto.timingSafeEqual(left, right);
  }

  function webPushReady() {
    return !!(config.webPushEnabled && config.webPushVapidPublicKey && config.webPushVapidPrivateKey
      && /^(mailto:.+|https:\/\/.+)$/.test(config.webPushSubject || ''));
  }

  function validPushSubscription(subscription) {
    if (!subscription || typeof subscription !== 'object' || !isAllowedPushEndpoint(subscription.endpoint)) return false;
    const key = String(subscription.keys?.p256dh || '');
    const auth = String(subscription.keys?.auth || '');
    if (!/^[A-Za-z0-9_-]{80,100}$/.test(key) || !/^[A-Za-z0-9_-]{16,64}$/.test(auth)) return false;
    try {
      const raw = Buffer.from(key, 'base64url');
      return raw.length === 65 && raw[0] === 4 && Buffer.from(auth, 'base64url').length >= 16;
    } catch { return false; }
  }

  async function notifyUsersByPush(message) {
    if (!webPushReady() || !message?.id) return;
    // Push content is intentionally generic to avoid disclosing private/sensitive text on a lock screen.
    const payload = { title: 'Shadow', body: message.kind === 'announcement' ? 'A new announcement is available.' : 'New activity in Shadow.', tag: `shadow-${message.id}`, url: '/' };
    const subscriptions = store.pushSubscriptions.filter((item) => item.userId !== message.userId && store.getUser(item.userId) && !store.getUser(item.userId).banned);
    await Promise.all(subscriptions.map(async (subscription) => {
      try {
        const response = await sendWebPush(subscription, payload, {
          publicKey: config.webPushVapidPublicKey, privateKey: config.webPushVapidPrivateKey,
          subject: config.webPushSubject, timeoutMs: config.webPushTimeoutMs,
        });
        if (response.status === 404 || response.status === 410) store.removePushSubscription(subscription.userId, subscription.endpoint);
        else if (!response.ok) console.error(`[push] provider rejected notification (${response.status})`);
      } catch (err) {
        const tag = err?.name === 'TimeoutError' || err?.name === 'AbortError' ? 'timeout' : 'send_failed';
        console.error(`[push] notification ${tag}`);
      }
    }));
  }

  function saveExternalMessage({ source, externalId, name, text, userId }) {
    const cleanedName = v.displayName(name) || (source === 'telegram' ? 'Telegram' : 'WhatsApp');
    const cleanedText = v.messageText(text);
    if (!cleanedText) return null;
    const message = store.addMessage({
      id: crypto.randomUUID(), userId: userId || `external:${source}`, name: cleanedName,
      text: cleanedText, kind: 'text', source, avatar: source === 'telegram' ? 'blue' : 'green', ts: Date.now(), externalId: String(externalId || ''),
    });
    const result = publicMessage(message);
    hub.broadcast('message', result);
    relayMessageToIntegrations(result);
    void notifyUsersByPush(result);
    return result;
  }

  /* ---------- route handlers ---------- */
  const routes = [];
  const route = (method, pattern, handler) => {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:([a-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method, re, keys, handler });
  };

  route('GET', '/api/health', async (ctx) => sendJson(ctx.res, 200, { ok: true, online: hub.onlineCount }));

  route('GET', '/api/config', async (ctx) =>
    sendJson(ctx.res, 200, { groupName: config.groupName, maxOnline: config.maxOnline }));

  route('POST', '/api/auth/register', async (ctx) => {
    limit(registerLimit, ctx.ip);
    const body = await readJson(ctx.req);
    const username = v.username(body.username);
    if (!username) throw new HttpError(400, 'invalid_username');
    const password = v.password(body.password);
    if (!password) throw new HttpError(400, 'invalid_password');
    const displayName = v.displayName(body.displayName ?? body.username);
    if (!displayName) throw new HttpError(400, 'invalid_display_name');
    const usernameKey = username.toLowerCase();
    if (store.findByUsername(usernameKey) || registeringUsernames.has(usernameKey)) {
      throw new HttpError(409, 'username_taken');
    }

    registeringUsernames.add(usernameKey);
    try {
      const user = store.addUser({
        id: crypto.randomUUID(),
        username,
        displayName,
        passwordHash: await hashPassword(password),
        role: 'user',
        banned: false,
        tokenVersion: 0,
        createdAt: Date.now(),
      });
      sendJson(ctx.res, 201, { token: tokens.issue(user.id, user.tokenVersion || 0), user: publicUser(user) });
    } finally {
      registeringUsernames.delete(usernameKey);
    }
  });

  route('POST', '/api/auth/login', async (ctx) => {
    limit(loginIpLimit, ctx.ip);
    const body = await readJson(ctx.req);
    const name = String(body.username ?? '').trim().toLowerCase().slice(0, 40);
    const password = String(body.password ?? '').slice(0, 128);
    limit(loginNameLimit, name);
    const user = store.findByUsername(name);
    const ok = await verifyPassword(password, user ? user.passwordHash : DUMMY_HASH);
    if (!user || !ok) throw new HttpError(401, 'invalid_credentials');
    if (user.banned) throw new HttpError(403, 'banned');
    sendJson(ctx.res, 200, { token: tokens.issue(user.id, user.tokenVersion || 0), user: publicUser(user) });
  });

  route('GET', '/api/me', async (ctx) => {
    const user = authenticate(ctx.req);
    sendJson(ctx.res, 200, { user: publicUser(user) });
  });

  route('PATCH', '/api/me', async (ctx) => {
    const user = authenticate(ctx.req);
    limit(editLimit, user.id);
    const body = await readJson(ctx.req);
    const displayName = body.displayName === undefined ? user.displayName : v.displayName(body.displayName);
    const avatar = body.avatar === undefined ? (v.avatar(user.avatar) || 'violet') : v.avatar(body.avatar);
    if (!displayName) throw new HttpError(400, 'invalid_display_name');
    if (!avatar) throw new HttpError(400, 'invalid_avatar');
    user.displayName = displayName;
    user.avatar = avatar;
    store.save();
    hub.updateProfile(user);
    sendJson(ctx.res, 200, { user: publicUser(user) });
  });

  route('POST', '/api/stream-ticket', async (ctx) => {
    const user = authenticate(ctx.req);
    // Bound pending tickets as well as active streams to resist resource exhaustion.
    if (!hub.canAccept(user.id)) {
      throw new HttpError(503, hub.isOnline(user.id) ? 'too_many_connections' : 'server_full');
    }
    limit(streamTicketLimit, user.id);
    sendJson(ctx.res, 200, { ticket: tickets.issue(user.id) });
  });

  route('GET', '/api/stream', async (ctx) => {
    const userId = tickets.consume(ctx.url.searchParams.get('ticket') || '');
    const user = userId ? store.getUser(userId) : null;
    if (!user) throw new HttpError(401, 'unauthorized');
    if (user.banned) throw new HttpError(403, 'banned');
    if (!hub.canAccept(user.id)) {
      throw new HttpError(503, hub.isOnline(user.id) ? 'too_many_connections' : 'server_full');
    }

    const { req, res } = ctx;
    req.socket.setTimeout(0);
    req.socket.setNoDelay(true);
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.write('retry: 3000\n\n');
    hub.send(res, 'init', {
      me: publicUser(user),
      groupName: config.groupName,
      messages: store.recentMessages(200).map(publicMessage),
      presence: hub.presence(),
    });
    hub.add(user, res);
    req.on('close', () => hub.remove(user.id, res));
  });

  route('POST', '/api/messages', async (ctx) => {
    const user = authenticate(ctx.req);
    limit(messageLimit, user.id);
    const body = await readJson(ctx.req);
    const text = v.messageText(body.text);
    if (!text) throw new HttpError(400, 'invalid_message');
    const msg = publicMessage(newMessage(user, text, 'text'));
    hub.broadcast('message', msg);
    relayMessageToIntegrations(msg);
    void notifyUsersByPush(msg);
    sendJson(ctx.res, 201, { message: msg });
  });

  /* ----- admin ----- */
  route('GET', '/api/admin/users', async (ctx) => {
    requireAdmin(ctx.req);
    const users = store.users.map((u) => ({
      id: u.id,
      username: u.username,
      displayName: u.displayName,
      role: u.role,
      avatar: v.avatar(u.avatar) || 'violet',
      banned: !!u.banned,
      online: hub.isOnline(u.id),
      createdAt: u.createdAt,
    }));
    sendJson(ctx.res, 200, { users, online: hub.onlineCount, total: users.length, banned: users.filter((u) => u.banned).length });
  });

  function targetUser(id) {
    const user = store.getUser(id);
    if (!user) throw new HttpError(404, 'not_found');
    if (user.role === 'admin') throw new HttpError(400, 'cannot_target_admin');
    return user;
  }

  route('POST', '/api/admin/users/:id/ban', async (ctx) => {
    requireAdmin(ctx.req);
    const user = targetUser(ctx.params.id);
    user.banned = true;
    store.save();
    store.addAudit({ actorId: authenticate(ctx.req).id, action: 'user.ban', targetId: user.id });
    hub.kick(user.id, 'banned');
    sendJson(ctx.res, 200, { ok: true });
  });

  route('POST', '/api/admin/users/:id/unban', async (ctx) => {
    requireAdmin(ctx.req);
    const user = targetUser(ctx.params.id);
    user.banned = false;
    store.save();
    store.addAudit({ actorId: authenticate(ctx.req).id, action: 'user.unban', targetId: user.id });
    sendJson(ctx.res, 200, { ok: true });
  });

  route('DELETE', '/api/admin/users/:id', async (ctx) => {
    requireAdmin(ctx.req);
    const user = targetUser(ctx.params.id);
    hub.kick(user.id, 'removed');
    store.addAudit({ actorId: authenticate(ctx.req).id, action: 'user.delete', targetId: user.id });
    store.removeUser(user.id);
    const ids = store.removeMessagesByUser(user.id);
    if (ids.length) hub.broadcast('messages_removed', { ids });
    sendJson(ctx.res, 200, { ok: true });
  });

  route('DELETE', '/api/admin/messages/:id', async (ctx) => {
    requireAdmin(ctx.req);
    if (!store.removeMessage(ctx.params.id)) throw new HttpError(404, 'not_found');
    store.addAudit({ actorId: authenticate(ctx.req).id, action: 'message.delete', targetId: ctx.params.id });
    hub.broadcast('messages_removed', { ids: [ctx.params.id] });
    sendJson(ctx.res, 200, { ok: true });
  });

  route('POST', '/api/admin/announcements', async (ctx) => {
    const admin = requireAdmin(ctx.req);
    const body = await readJson(ctx.req);
    const text = v.messageText(body.text);
    if (!text) throw new HttpError(400, 'invalid_message');
    const msg = publicMessage(newMessage(admin, text, 'announcement'));
    hub.broadcast('message', msg);
    relayMessageToIntegrations(msg);
    void notifyUsersByPush(msg);
    sendJson(ctx.res, 201, { message: msg });
  });

  /* ----- AI, public API keys and external bridges ----- */
  route('POST', '/api/ai/chat', async (ctx) => {
    const user = authenticate(ctx.req);
    limit(aiLimit, user.id);
    if (!(config.aiEnabled && config.aiApiUrl && config.aiApiKey && config.aiModel)) {
      throw new HttpError(503, 'ai_not_configured');
    }
    let parsedUrl;
    try { parsedUrl = new URL(config.aiApiUrl); } catch { throw new HttpError(503, 'ai_not_configured'); }
    const localProvider = ['localhost', '127.0.0.1', '[::1]', '::1'].includes(parsedUrl.hostname);
    if (parsedUrl.username || parsedUrl.password || (parsedUrl.protocol !== 'https:' && !(parsedUrl.protocol === 'http:' && localProvider))) {
      throw new HttpError(503, 'ai_not_configured');
    }
    const body = await readJson(ctx.req, 32 * 1024);
    const message = v.messageText(body.message);
    if (!message) throw new HttpError(400, 'invalid_message');
    const history = Array.isArray(body.history) ? body.history.slice(-8) : [];
    const messages = [];
    for (const item of history) {
      if (!item || !['user', 'assistant'].includes(item.role) || typeof item.content !== 'string') continue;
      const content = item.content.trim().slice(0, 2000);
      if (content) messages.push({ role: item.role, content });
    }
    messages.push({ role: 'user', content: message });
    let response;
    try {
      response = await fetch(config.aiApiUrl, {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${config.aiApiKey}` },
        body: JSON.stringify({ model: config.aiModel, messages }),
        signal: AbortSignal.timeout(config.aiTimeoutMs),
      });
    } catch (err) {
      if (err && (err.name === 'TimeoutError' || err.name === 'AbortError')) throw new HttpError(504, 'ai_timeout');
      throw new HttpError(502, 'ai_provider_error');
    }
    if (!response.ok) throw new HttpError(response.status === 429 ? 503 : 502, response.status === 429 ? 'ai_busy' : 'ai_provider_error');
    let result;
    try { result = await response.json(); } catch { throw new HttpError(502, 'ai_provider_error'); }
    const answer = result?.choices?.[0]?.message?.content;
    if (typeof answer !== 'string' || !answer.trim()) throw new HttpError(502, 'ai_empty_response');
    sendJson(ctx.res, 200, { answer: answer.slice(0, 8000), model: config.aiModel });
  });

  route('GET', '/api/admin/audit', async (ctx) => {
    requireAdmin(ctx.req);
    sendJson(ctx.res, 200, { entries: store.recentAudit(100) });
  });

  const allowedScopes = new Set(['messages:read', 'messages:write', 'announcements:read']);
  route('GET', '/api/admin/api-keys', async (ctx) => {
    requireAdmin(ctx.req);
    sendJson(ctx.res, 200, { keys: store.apiKeys.map((key) => ({
      id: key.id, label: key.label, prefix: key.prefix, scopes: key.scopes,
      createdAt: key.createdAt, revokedAt: key.revokedAt || null,
    })) });
  });

  route('POST', '/api/admin/api-keys', async (ctx) => {
    const admin = requireAdmin(ctx.req);
    const body = await readJson(ctx.req);
    const label = String(body.label || '').trim().replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 40);
    if (label.length < 2) throw new HttpError(400, 'invalid_key_label');
    const scopes = [...new Set(Array.isArray(body.scopes) ? body.scopes.filter((x) => allowedScopes.has(x)) : [])];
    if (!scopes.length || scopes.length > allowedScopes.size) throw new HttpError(400, 'invalid_api_scopes');
    const rawKey = `shd_live_${crypto.randomBytes(32).toString('base64url')}`;
    const key = {
      id: crypto.randomUUID(), label, prefix: rawKey.slice(0, 14),
      hash: crypto.createHash('sha256').update(rawKey).digest('hex'), scopes,
      createdAt: Date.now(), createdBy: admin.id, revokedAt: null,
    };
    store.addApiKey(key);
    store.addAudit({ actorId: admin.id, action: 'api_key.create', targetId: key.id, details: { label, scopes } });
    sendJson(ctx.res, 201, { apiKey: rawKey, key: { id: key.id, label, prefix: key.prefix, scopes, createdAt: key.createdAt } });
  });

  route('DELETE', '/api/admin/api-keys/:id', async (ctx) => {
    const admin = requireAdmin(ctx.req);
    const key = store.revokeApiKey(ctx.params.id);
    if (!key) throw new HttpError(404, 'not_found');
    store.addAudit({ actorId: admin.id, action: 'api_key.revoke', targetId: key.id });
    sendJson(ctx.res, 200, { ok: true });
  });

  route('GET', '/api/v1/health', async (ctx) => sendJson(ctx.res, 200, { ok: true, online: hub.onlineCount }));
  route('GET', '/api/v1/messages', async (ctx) => {
    validApiKey(ctx.req, 'messages:read');
    const count = Math.max(1, Math.min(100, Number.parseInt(ctx.url.searchParams.get('limit') || '50', 10) || 50));
    sendJson(ctx.res, 200, { messages: store.recentMessages(count).map(publicMessage) });
  });
  route('GET', '/api/v1/announcements', async (ctx) => {
    validApiKey(ctx.req, 'announcements:read');
    sendJson(ctx.res, 200, { announcements: store.data.messages.filter((m) => m.kind === 'announcement').slice(-100).map(publicMessage) });
  });
  route('POST', '/api/v1/messages', async (ctx) => {
    const key = validApiKey(ctx.req, 'messages:write');
    const body = await readJson(ctx.req);
    const text = v.messageText(body.text);
    if (!text) throw new HttpError(400, 'invalid_message');
    const msg = store.addMessage({
      id: crypto.randomUUID(), userId: `external:api:${key.id}`, name: `API · ${key.label}`,
      text, kind: 'text', source: 'api', avatar: 'teal', ts: Date.now(),
    });
    const result = publicMessage(msg);
    hub.broadcast('message', result);
    relayMessageToIntegrations(result);
    void notifyUsersByPush(result);
    sendJson(ctx.res, 201, { message: result });
  });

  route('GET', '/api/push/config', async (ctx) => {
    authenticate(ctx.req);
    sendJson(ctx.res, 200, { enabled: webPushReady(), publicKey: webPushReady() ? config.webPushVapidPublicKey : '' });
  });

  route('POST', '/api/push/subscribe', async (ctx) => {
    const user = authenticate(ctx.req);
    if (!webPushReady()) throw new HttpError(503, 'push_not_configured');
    const body = await readJson(ctx.req, 16 * 1024);
    const subscription = body.subscription;
    if (!validPushSubscription(subscription)) throw new HttpError(400, 'invalid_push_subscription');
    const existing = store.pushSubscriptions.find((item) => item.userId === user.id && item.endpoint === subscription.endpoint);
    const count = store.pushSubscriptions.filter((item) => item.userId === user.id).length;
    if (!existing && count >= 10) throw new HttpError(429, 'push_subscription_limit');
    store.savePushSubscription({ id: existing?.id || crypto.randomUUID(), userId: user.id, endpoint: subscription.endpoint,
      keys: { p256dh: subscription.keys.p256dh, auth: subscription.keys.auth } });
    sendJson(ctx.res, 201, { ok: true });
  });

  route('DELETE', '/api/push/subscribe', async (ctx) => {
    const user = authenticate(ctx.req);
    const body = await readJson(ctx.req, 4096);
    const endpoint = String(body.endpoint || '');
    if (endpoint.length > 2048 || !isAllowedPushEndpoint(endpoint)) throw new HttpError(400, 'invalid_push_endpoint');
    store.removePushSubscription(user.id, endpoint);
    sendJson(ctx.res, 200, { ok: true });
  });

  route('POST', '/api/integrations/telegram/webhook', async (ctx) => {
    limit(webhookLimit, `telegram:${ctx.ip}`);
    if (!integrationReady('telegram')) throw new HttpError(503, 'telegram_not_configured');
    const secret = String(ctx.req.headers['x-telegram-bot-api-secret-token'] || '');
    if (!secureEqualText(secret, config.telegramWebhookSecret)) throw new HttpError(401, 'invalid_webhook_secret');
    const body = await readJson(ctx.req, 64 * 1024);
    if (!body || typeof body !== 'object' || Array.isArray(body) || !Number.isSafeInteger(body.update_id)) throw new HttpError(400, 'invalid_webhook_payload');
    if (store.hasProcessedUpdate('telegram', body.update_id)) return sendJson(ctx.res, 200, { ok: true, duplicate: true });
    const message = body.message || body.channel_post;
    const chat = message && message.chat;
    if (message && chat && String(chat.id) === String(config.telegramChatId) && typeof message.text === 'string') {
      const first = message.from && (message.from.first_name || '');
      const last = message.from && (message.from.last_name || '');
      const name = (`Telegram · ${`${first} ${last}`.trim() || 'user'}`).slice(0, 32);
      if (v.messageText(message.text)) saveExternalMessage({ source: 'telegram', externalId: body.update_id, name, text: message.text, userId: `external:telegram:${chat.id}` });
    }
    store.rememberProcessedUpdate('telegram', body.update_id);
    sendJson(ctx.res, 200, { ok: true });
  });

  route('GET', '/api/integrations/whatsapp/webhook', async (ctx) => {
    limit(webhookLimit, `whatsapp:${ctx.ip}`);
    if (!integrationReady('whatsapp')) throw new HttpError(503, 'whatsapp_not_configured');
    const mode = ctx.url.searchParams.get('hub.mode');
    const token = ctx.url.searchParams.get('hub.verify_token');
    const challenge = ctx.url.searchParams.get('hub.challenge') || '';
    if (mode !== 'subscribe' || !secureEqualText(token, config.whatsappVerifyToken)) throw new HttpError(403, 'webhook_verification_failed');
    ctx.res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    ctx.res.end(challenge.slice(0, 200));
  });

  route('POST', '/api/integrations/whatsapp/webhook', async (ctx) => {
    limit(webhookLimit, `whatsapp:${ctx.ip}`);
    if (!integrationReady('whatsapp')) throw new HttpError(503, 'whatsapp_not_configured');
    const raw = await readRaw(ctx.req, 128 * 1024);
    const supplied = String(ctx.req.headers['x-hub-signature-256'] || '');
    const expected = `sha256=${crypto.createHmac('sha256', config.whatsappAppSecret).update(raw).digest('hex')}`;
    if (!secureEqualText(supplied, expected)) throw new HttpError(401, 'invalid_webhook_signature');
    let body;
    try { body = JSON.parse(raw.toString('utf8')); } catch { throw new HttpError(400, 'bad_request'); }
    if (!body || typeof body !== 'object' || Array.isArray(body) || !Array.isArray(body.entry)) throw new HttpError(400, 'invalid_webhook_payload');
    const candidates = [];
    for (const entry of body.entry) {
      if (!entry || typeof entry !== 'object') continue;
      for (const change of (Array.isArray(entry.changes) ? entry.changes : [])) {
        const value = change && change.value;
        if (String(value?.metadata?.phone_number_id || '') !== String(config.whatsappPhoneNumberId)) continue;
        const contacts = new Map((Array.isArray(value.contacts) ? value.contacts : []).filter((c) => c && typeof c === 'object').map((c) => [String(c.wa_id || ''), c.profile?.name || '']));
        for (const message of (Array.isArray(value.messages) ? value.messages : [])) {
          if (!message || typeof message !== 'object' || message.type !== 'text' || typeof message.text?.body !== 'string' || !message.id) continue;
          candidates.push({ message, name: contacts.get(String(message.from || '')) || 'contact' });
        }
      }
    }
    for (const candidate of candidates) {
      const id = candidate.message.id;
      if (store.hasProcessedUpdate('whatsapp', id)) continue;
      const sender = String(candidate.message.from || '').replace(/\D/g, '');
      const configuredRecipient = String(config.whatsappTo || '').replace(/\D/g, '');
      if (sender && configuredRecipient && sender === configuredRecipient) whatsappLastInboundAt.set(configuredRecipient, Date.now());
      const safeName = `WhatsApp · ${String(candidate.name).replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 20) || 'contact'}`;
      if (v.messageText(candidate.message.text.body)) saveExternalMessage({ source: 'whatsapp', externalId: id, name: safeName, text: candidate.message.text.body, userId: `external:whatsapp:${sender.slice(0, 40)}` });
      store.rememberProcessedUpdate('whatsapp', id);
    }
    sendJson(ctx.res, 200, { ok: true, processed: candidates.length });
  });

  /* ---------- HTTP server ---------- */
  function corsHeaders(req) {
    const allowed = config.corsOrigin;
    const origin = req.headers.origin;
    let allow = null;
    if (allowed === '*') allow = '*';
    else if (origin && allowed.split(',').map((s) => s.trim()).includes(origin)) allow = origin;
    if (!allow) return {};
    return {
      'Access-Control-Allow-Origin': allow,
      'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Authorization,Content-Type,X-API-Key',
      'Access-Control-Max-Age': '86400',
      Vary: 'Origin',
    };
  }

  const frontendReady = config.serveFrontend && fs.existsSync(config.frontendDir);

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const isApi = url.pathname.startsWith('/api/');

    try {
      if (isApi) {
        const cors = corsHeaders(req);
        for (const [k, val] of Object.entries(cors)) res.setHeader(k, val);
        res.setHeader('X-Content-Type-Options', 'nosniff');
        if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

        for (const r of routes) {
          if (r.method !== req.method) continue;
          const m = r.re.exec(url.pathname);
          if (!m) continue;
          const params = {};
          r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
          return await r.handler({ req, res, url, params, ip: clientIp(req) });
        }
        throw new HttpError(404, 'not_found');
      }

      if (frontendReady && (req.method === 'GET' || req.method === 'HEAD')) {
        if (serveStatic(config.frontendDir, url.pathname, res)) return;
        if (serveStatic(config.frontendDir, '/', res)) return;
      }
      throw new HttpError(404, 'not_found');
    } catch (err) {
      if (res.headersSent) { res.destroy(); return; }
      if (err instanceof HttpError) {
        const headers = err.status === 429
          ? { 'Retry-After': String(Math.max(1, err.retryAfter || 30)) }
          : {};
        return sendJson(res, err.status, { error: err.code }, headers);
      }
      console.error('[error]', err);
      sendJson(res, 500, { error: 'server_error' });
    }
  });

  server.keepAliveTimeout = 65000;
  server.headersTimeout = 70000;

  async function close() {
    hub.close();
    limiters.forEach((l) => l.stop());
    for (const limiter of apiKeyLimiters.values()) limiter.stop();
    tickets.stop();
    await new Promise((resolve) => {
      server.close(() => resolve());
      server.closeAllConnections?.();
    });
    await store.flush();
  }

  return { server, store, hub, close, frontendReady };
}

module.exports = { createApp };
