'use strict';

// Control characters (except \n and \t) and bidi override/isolate characters,
// which can be abused to spoof or visually reverse text.
const BAD_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g;

const USERNAME_RE = /^[A-Za-z0-9_.]{3,24}$/;

function cleanLine(value) {
  return String(value ?? '').replace(BAD_CHARS, '').replace(/\s+/g, ' ').trim();
}

function cleanText(value) {
  return String(value ?? '')
    .replace(/\r\n?/g, '\n')
    .replace(BAD_CHARS, '')
    .replace(/\n{4,}/g, '\n\n\n')
    .trim();
}

/** Length in user-perceived characters (code points). */
function len(s) {
  return [...s].length;
}

function username(value) {
  const v = String(value ?? '').trim();
  return USERNAME_RE.test(v) ? v : null;
}

function password(value) {
  const v = String(value ?? '');
  return v.length >= 6 && v.length <= 128 ? v : null;
}

function displayName(value) {
  const v = cleanLine(value);
  const n = len(v);
  return n >= 2 && n <= 32 ? v : null;
}

const AVATARS = new Set(['violet', 'blue', 'pink', 'green', 'orange', 'teal']);
function avatar(value) { const v = String(value ?? '').trim(); return AVATARS.has(v) ? v : null; }

function messageText(value) {
  const v = cleanText(value);
  const n = len(v);
  return n >= 1 && n <= 1000 ? v : null;
}

module.exports = { username, password, displayName, messageText, avatar, AVATARS };
