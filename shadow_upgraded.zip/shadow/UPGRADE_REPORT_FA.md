# گزارش ارتقای پروژه Shadow

**وضعیت:** تغییرات محلی پیاده‌سازی و بررسی شده‌اند؛ تست‌ها و build نهایی موفق‌اند. سرویس‌های بیرونی با حساب و credential واقعی متصل نشده‌اند؛ تست اتصال‌های بیرونی با دادهٔ آزمایشی و mock انجام شده است.

## ۱. نتیجهٔ تست‌ها

- `npm test`: **۲۳ تست موفق، ۰ شکست**. این مجموعه شامل ۱۱ تست اصلی پروژه و ۱۲ تست افزوده برای پروفایل، API، AI، webhookها و Web Push است.
- `npm run build`: موفق؛ خروجی `frontend/www/` با اسکریپت اصلی پروژه دوباره تولید شد.
- `node --check` برای فایل‌های JavaScript بک‌اند، اسکریپت‌ها و تست‌ها: موفق.
- بررسی نحوی ماژول‌های فرانت‌اند و Service Worker در هر دو پوشهٔ `frontend/src/` و `frontend/www/`: موفق.
- وابستگی اجرایی جدید نصب نشده است.
- Android APK ساخته نشد: Android SDK معرفی نشده (`ANDROID_HOME` و `ANDROID_SDK_ROOT` خالی‌اند)، فرمان `gradle` در محیط نیست و پوشهٔ پروژهٔ `frontend/android/` نیز وجود ندارد. در نتیجه، نصب یا آزمایش روی دستگاه واقعی انجام نشده است.

## ۲. آنچه تغییر کرد

### رابط کاربری و حساب‌ها

- انتخاب آواتار پیش‌فرض رنگی و تغییر نام نمایشی در تنظیمات.
- آواتار در پیام‌ها و فهرست کاربران آنلاین؛ نشان منبع برای پیام‌های بیرونی.
- بهبود رابط موبایل و پنل مدیریت، آمار کاربران و جست‌وجو/فیلتر کاربران.
- افزودن فهرست اعلان‌ها، شمارندهٔ اعلان‌های جدید و دکمهٔ تنظیم/فعال‌سازی اعلان‌ها.
- افزودن پنجرهٔ دستیار هوش مصنوعی با حالت‌های انتظار و خطای کنترل‌شده.
- افزودن نمایش و مدیریت کلیدهای API از پنل مدیریت.
- حفظ ساختار HTML/CSS/JavaScript ساده و ترجمه‌های انگلیسی، فارسی، دری و عربی.

### Backend و ذخیره‌سازی

- گسترش سازگار مدل JSON برای آواتار، منبع پیام، اشتراک‌های Push، کلیدهای API، رویدادهای مدیریتی و جلوگیری از پردازش مجدد webhook. داده‌های قدیمی در نظر گرفته شده‌اند.
- بهبود نوشتن هم‌زمان و flush ذخیره‌سازی هنگام بسته‌شدن سرور.
- افزودن API خارجی `/api/v1/` با کلید جدا از توکن ورود، scope، hash کلید در ذخیره‌سازی، لغو کلید و محدودیت نرخ.
- افزودن endpoint دستیار AI در سمت سرور؛ کلید provider به فرانت‌اند فرستاده نمی‌شود، timeout و محدودیت ورودی دارد و در حالت پیش‌فرض خاموش است.
- افزودن اتصال دوطرفهٔ متنی به Telegram Bot API با بررسی secret webhook و جلوگیری از پیام تکراری و حلقهٔ بازگشت.
- افزودن اتصال متنی WhatsApp Cloud API رسمی با بررسی challenge/امضای webhook و جلوگیری از پیام تکراری.
- افزودن اشتراک‌های Web Push، کد Service Worker، تولید VAPID و ارسال اعلان‌های عمومی بدون نمایش متن خصوصی پیام روی صفحهٔ قفل.
- تمام integrationهای خارجی با متغیر `*_ENABLED` خاموش می‌مانند مگر اینکه صریحاً پیکربندی شوند.

## ۳. فایل‌های تغییرکرده

### Backend

- `backend/src/app.js` — مسیرهای API، مجوزها، AI، webhookها، Push و bridge پیام‌ها.
- `backend/src/config.js` — متغیرهای پیکربندی جدید.
- `backend/src/http-utils.js` — خواندن امن ورودی خام و JSON با محدودیت حجم.
- `backend/src/hub.js` — حضور آنلاین و انتشار اطلاعات عمومی پروفایل.
- `backend/src/store.js` — داده‌های جدید، سازگاری نسخهٔ قدیمی و نوشتن/flush پایدارتر.
- `backend/src/validate.js` — اعتبارسنجی آواتار.
- `backend/src/webpush.js` — پیاده‌سازی رمزنگاری و ارسال Web Push بدون وابستگی بیرونی.
- `backend/scripts/generate-vapid.js` — ابزار ساخت کلید VAPID؛ کلیدها باید در محیط سرور نگهداری شوند.
- `backend/test/upgrade.test.js` — تست‌های API، AI و webhookها.
- `backend/test/webpush.test.js` — تست‌های Web Push.
- `backend/.env.example` — نام متغیرها و نمونه‌های غیرمحرمانه.

### Frontend و مستندات

- `frontend/src/index.html`
- `frontend/src/css/app.css`
- `frontend/src/js/main.js`
- `frontend/src/js/sheets.js`
- `frontend/src/js/ui.js`
- `frontend/src/js/i18n.js`
- `frontend/src/sw.js`
- `frontend/www/` — خروجی تولیدشده از منبع با اسکریپت build؛ ویرایش دستی نشده است.
- `README.md` — راهنمای پیکربندی و آزمایش قابلیت‌های جدید.
- `AUDIT_REPORT.md` — مشخص‌کردن گزارش اولیه به‌عنوان خط پایه و ارجاع به این گزارش برای نتایج جدید.

هیچ وابستگی جدیدی به `package.json`ها افزوده نشده است.

## ۴. متغیرهای محیطی جدید

تنظیمات کامل نمونه در `backend/.env.example` است. فایل حاوی credential واقعی نیست.

### هوش مصنوعی

`AI_ENABLED`, `AI_API_URL`, `AI_API_KEY`, `AI_MODEL`, `AI_TIMEOUT_MS`

برای فعال‌کردن: URL سرویس سازگار با API چت، مدل و کلید را فقط در محیط سرور تنظیم کنید و سپس `AI_ENABLED=true` قرار دهید. تا وقتی کلید و endpoint واقعی مشخص نشده‌اند، endpoint باید در حالت خاموش بماند.

### Telegram

`TELEGRAM_ENABLED`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_WEBHOOK_SECRET`, `TELEGRAM_CHAT_ID`

بات را با BotFather بسازید، chat ID گروه را مشخص کنید، راز webhook را تنظیم کنید و endpoint زیر را روی HTTPS در تنظیمات webhook رسمی Telegram قرار دهید:

`/api/integrations/telegram/webhook`

Telegram برای ارسال webhook از هدر `X-Telegram-Bot-Api-Secret-Token` پشتیبانی می‌کند؛ سرور این مقدار را بررسی می‌کند. مستندات رسمی: https://core.telegram.org/bots/api و https://core.telegram.org/bots/webhooks

### WhatsApp Cloud API

`WHATSAPP_ENABLED`, `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_VERIFY_TOKEN`, `WHATSAPP_APP_SECRET`, `WHATSAPP_TO`, `WHATSAPP_API_VERSION`

به اپ Meta، حساب WhatsApp Business و شمارهٔ ثبت‌شده نیاز است. URL webhook روی HTTPS باید به مسیر `/api/integrations/whatsapp/webhook` اشاره کند. مقدار نسخهٔ API در نمونه `v25.0` است؛ پیش از استقرار، نسخه و شرایط جاری Meta را دوباره بررسی کنید.

**محدودیت مهم فعلی:** ارسال پیام متنی معمولی از Shadow به WhatsApp فقط هنگامی مجاز می‌شود که همان گیرنده پیام ورودی معتبر فرستاده باشد و پنجرهٔ ۲۴ساعته باز باشد. پنجره پس از restart به‌صورت fail-closed بسته می‌شود. قالب‌های رسمی برای آغاز پیام خارج از این پنجره در این نسخه پیاده‌سازی نشده‌اند.

### Web Push

`WEB_PUSH_ENABLED`, `WEB_PUSH_VAPID_PUBLIC_KEY`, `WEB_PUSH_VAPID_PRIVATE_KEY`, `WEB_PUSH_SUBJECT`, `WEB_PUSH_TIMEOUT_MS`

از ریشهٔ پروژه اجرا کنید:

`node backend/scripts/generate-vapid.js`

مقادیر تولیدشده را در متغیرهای محیطی سرور قرار دهید، `WEB_PUSH_ENABLED=true` کنید و برنامه را روی HTTPS منتشر کنید. کاربر باید از داخل برنامه و با اقدام خودش مجوز اعلان بدهد. این پیاده‌سازی Web Push برای مرورگرهای سازگار است؛ Push بومی Android/Capacitor به‌طور جداگانه تنظیم نشده است. راهنما: https://developer.mozilla.org/en-US/docs/Web/API/Push_API و https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API

## ۵. API خارجی

- `GET /api/v1/health` — بررسی وضعیت عمومی سرویس.
- `GET /api/v1/messages?limit=...` — خواندن تعداد محدودی پیام با scope `messages:read`.
- `GET /api/v1/announcements` — اطلاعیه‌های مجاز با scope `announcements:read`.
- `POST /api/v1/messages` — ارسال پیام با scope `messages:write`.

درخواست‌های API خارجی از هدر `X-API-Key` استفاده می‌کنند. کلید از پنل ادمین ساخته می‌شود و متن کامل آن فقط یک‌بار نمایش داده می‌شود؛ فقط hash کلید ذخیره می‌شود. کلید را در log، رابط عمومی یا Git قرار ندهید. نمونه‌های `curl` و شرح scopeها در `README.md` آمده‌اند.

## ۶. مواردی که اتصال واقعی آن‌ها تأیید نشده است

- AI: به کلید و endpoint provider واقعی نیاز دارد؛ تست با adapter محلی انجام شده است.
- Telegram: به bot token، chat ID، HTTPS قابل‌دسترسی و تنظیم webhook واقعی نیاز دارد.
- WhatsApp: به Meta Business، شمارهٔ ثبت‌شده، token، app secret و webhook HTTPS نیاز دارد.
- Web Push: تست رمزنگاری و مسیر اشتراک انجام شده؛ ارسال به مرورگر/endpoint واقعی روی HTTPS از این محیط تأیید نشده است.
- Android: APK ساخته یا روی گوشی آزمایش نشده است؛ Android SDK/Gradle در محیط موجود نبود.

عدم وجود این credentialها نباید چت داخلی را از کار بیندازد؛ integrationها به‌صورت پیش‌فرض خاموش هستند.

## ۷. محدودیت‌ها و پیشنهاد مرحلهٔ بعد

- Push بومی Android/Capacitor هنوز اضافه نشده است.
- WhatsApp message templates برای آغاز گفت‌وگو خارج از پنجرهٔ ۲۴ساعته پشتیبانی نمی‌شوند.
- این نسخه به گروه عمومی فعلی محدود است؛ چت خصوصی، چند گروه و roleهای چندسطحی عمداً اضافه نشده‌اند.
- پیش از انتشار عمومی، فایل `.env` امن، HTTPS، پشتیبان‌گیری منظم از JSON، بررسی logها و تست روی سرور واقعی توصیه می‌شود.
- پس از پیکربندی credentialها، هر اتصال باید با webhook و پیام واقعی جداگانه آزمایش شود؛ موفقیت تست mock، اثبات اتصال زنده نیست.
