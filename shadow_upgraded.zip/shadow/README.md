# Shadow

پیام‌رسان سبک با **یک گروه عمومی**، حداکثر **۱۰۰ کاربر هم‌زمان**، فقط **پیام متنی**، یک **ادمین اصلی**، تم تیره (مشکی/خاکستری/بنفش) و پشتیبانی کامل از **فارسی، دری، عربی و انگلیسی** (RTL/LTR).

```
shadow/
├── backend/      سرور Node.js (بدون وابستگی اجرایی خارجی؛ فقط خود Node)
│   ├── server.js
│   ├── src/      config, store, auth, hub (SSE), ratelimit, validate, app (API)
│   ├── test/     تست‌های یکپارچه (npm test)
│   └── .env.example
└── frontend/     وب‌اپ (ES modules خالص) + پوستهٔ Capacitor برای APK
    ├── src/      index.html, css/, js/
    ├── www/      خروجی Build (از قبل ساخته شده)
    ├── scripts/build.js
    └── capacitor.config.json
```

Backend و Frontend کاملاً جدا هستند و فقط از طریق API ‏(`/api/*`) صحبت می‌کنند.
در حالت پیش‌فرض سرور خروجی Build فرانت‌اند را هم سرو می‌کند تا فقط یک پروسه برای اجرا لازم باشد.

---

## اجرای سریع (لینوکس / VPS / Termux)

نیازمند **Node.js 18 یا بالاتر**.

```bash
cd backend
cp .env.example .env
nano .env            # ADMIN_USERNAME و ADMIN_PASSWORD را حتماً تنظیم کنید
node server.js       # یا: npm start
```

سپس `http://IP-SERVER:3000` را باز کنید. با نام کاربری/رمز ادمین وارد شوید.

نکته‌ها:
- اگر `ADMIN_PASSWORD` تنظیم نشده یا کمتر از ۸ نویسه باشد یا همان مقدار نمونه باشد، سرور با پیام روشن بالا نمی‌آید.
- `JWT_SECRET` اختیاری است؛ اگر خالی بماند یک کلید تصادفی در `DATA_DIR/secret.key` ساخته و ذخیره می‌شود.
- با هر بار اجرا، حساب ادمین از روی `.env` ساخته/به‌روز می‌شود. **برای تغییر رمز ادمین کافی است `ADMIN_PASSWORD` را عوض و سرور را ری‌استارت کنید.**
- فقط یک ادمین وجود دارد؛ راهی برای ثبت‌نام ادمین دوم نیست.

### متغیرهای `.env`

| متغیر | پیش‌فرض | توضیح |
|---|---|---|
| `PORT` / `HOST` | `3000` / `0.0.0.0` | آدرس شنود |
| `ADMIN_USERNAME` | `admin` | نام کاربری ادمین (حروف انگلیسی، عدد، `_` `.`) |
| `ADMIN_PASSWORD` | — (الزامی) | رمز ادمین، حداقل ۸ نویسه |
| `JWT_SECRET` | خودکار | کلید امضای توکن |
| `DATA_DIR` | `./data` | محل ذخیرهٔ کاربران و پیام‌ها |
| `GROUP_NAME` | `Shadow` | نام گروه |
| `MAX_ONLINE` | `100` | سقف کاربران هم‌زمان آنلاین |
| `MAX_STORED_MESSAGES` | `1000` | تعداد پیام‌های نگهداری‌شده |
| `TOKEN_TTL_DAYS` | `30` | مدت اعتبار ورود |
| `CORS_ORIGIN` | `*` | مبدأهای مجاز (برای APK مقدار `*` مناسب است) |
| `TRUST_PROXY` | `0` | پشت nginx/Caddy/پروکسی هاست مقدار `1` بگذارید |
| `SERVE_FRONTEND` | `1` | سرو کردن `frontend/www` از همین سرور |

---

## استقرار روی VPS (پیشنهادی: systemd + HTTPS)

۱. فایل‌ها را در `/opt/shadow` بگذارید و `.env` را در `/opt/shadow/backend/.env` بسازید.

۲. سرویس systemd — فایل `/etc/systemd/system/shadow.service`:

```ini
[Unit]
Description=Shadow messenger
After=network.target

[Service]
WorkingDirectory=/opt/shadow/backend
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=3
User=www-data
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

```bash
chown -R www-data /opt/shadow/backend/data   # یا پوشهٔ DATA_DIR
systemctl daemon-reload && systemctl enable --now shadow
journalctl -u shadow -f
```

۳. HTTPS با Caddy (گواهی خودکار) — فایل `Caddyfile`:

```
chat.example.com {
    reverse_proxy 127.0.0.1:3000 {
        flush_interval -1
    }
}
```

و در `.env` مقدار `TRUST_PROXY=1` بگذارید.
اگر از nginx استفاده می‌کنید برای مسیر `/api/stream` حتماً `proxy_buffering off;` و `proxy_read_timeout 1h;` تنظیم کنید (اتصال زنده از نوع SSE است).

## استقرار روی هاست Node.js (مثل WispByte)

۱. کل پوشهٔ پروژه را آپلود کنید (پوشهٔ `frontend/www` از قبل Build شده است).
۲. Startup command را روی `node backend/server.js` (یا `npm start`) بگذارید.
۳. در بخش Environment/Variables پنل، حداقل `ADMIN_USERNAME` و `ADMIN_PASSWORD` را تعریف کنید و اگر پنل پورت می‌دهد `PORT` را همان بگذارید. اگر پنل متغیر محیطی ندارد، فایل `backend/.env` را بسازید.
۴. `TRUST_PROXY=1` را فعال کنید.
۵. اگر هاست دیسک پایدار ندارد، `DATA_DIR` را روی مسیر پایدار بگذارید؛ وگرنه با هر دیپلوی کاربران و پیام‌ها پاک می‌شوند.

---

## ساخت APK

اپ اندروید همان فرانت‌اند است که با **Capacitor** بسته‌بندی می‌شود. APK به یک **آدرس سرور** نیاز دارد (چون خودش سرور ندارد). برای کاربران واقعی از **HTTPS** استفاده کنید؛ فرمان APK فقط URL با `https://` را می‌پذیرد و cleartext در تنظیمات اندروید غیرفعال است تا رمز، توکن و پیام‌ها از راه HTTP ارسال نشوند.

پیش‌نیاز: Node 18+، **JDK 17**، **Android SDK** (یا Android Studio) و متغیر `ANDROID_HOME`.

```bash
cd frontend
cp .env.example .env
nano .env                      # SHADOW_API_URL=https://chat.example.com

npm install
npm run cap:add                # فقط بار اول: پروژهٔ android/ ساخته می‌شود
npm run apk:debug              # Build + sync + gradle assembleDebug
```

خروجی: `frontend/android/app/build/outputs/apk/debug/app-debug.apk`

- آیکن و اسپلش (اختیاری): `npx @capacitor/assets generate --android` (فایل‌های اولیه در `frontend/resources/` آماده‌اند).
- نسخهٔ Release: `npm run apk:release` و سپس امضای APK با keystore خودتان (`apksigner`) یا ساخت AAB از Android Studio.
- فرمان APK اکنون اگر `SHADOW_API_URL` خالی باشد پیش از بازسازی فایل‌ها متوقف می‌شود؛ این کار جلوی APK ظاهراً ساخته‌شده‌ای را می‌گیرد که به سرور وصل نمی‌شود.
- هر حساب حداکثر ۵ اتصال زندهٔ هم‌زمان دارد تا یک حساب نتواند با بازکردن تعداد نامحدود اتصال، سرور را تحت فشار بگذارد؛ درخواست ساخت تیکت اتصال نیز محدود شده است.
- برای آزمایش موقت با سرور HTTP باید تنظیمات توسعه را آگاهانه و جدا از نسخهٔ انتشار تغییر دهید؛ APK پیش‌فرض به سرور HTTPS نیاز دارد.

---

## امکانات

**کاربر:** ثبت‌نام، ورود، ویرایش نام نمایشی و آواتار پیش‌فرض، مشاهدهٔ کاربران آنلاین با هویت واضح، گفت‌وگوی عمومی متنی، اعلان‌های درون‌برنامه‌ای و گزینهٔ اعلان سیستم.
**ادمین:** جست‌وجو/فیلتر کاربران، آمار کاربران، بن و رفع بن، حذف کاربر/پیام، ارسال اطلاعیه، گزارش عملیات حساس، ایجاد و لغو کلید API.
**امنیت و پایداری:** رمزها با scrypt هش می‌شوند؛ توکن امضاشده و زمان‌دار؛ اتصال زنده با تیکت یک‌بارمصرف؛ محدودیت نرخ روی ورود/ثبت‌نام/پیام/AI/API/webhook؛ کلیدهای API به شکل hash ذخیره می‌شوند و فقط هنگام ساخت نمایش داده می‌شوند؛ اسرار AI و سرویس‌های خارجی فقط در بک‌اند هستند؛ ذخیره‌سازی اتمی JSON؛ برچسب‌گذاری پیام‌های خارجی و جلوگیری از ارسال دوباره به همان پلتفرم؛ بازاتصال خودکار SSE.

## تست

```bash
npm test          # تست‌های بک‌اند و ارتقاهای UI/API/AI/webhook/Web Push
npm run build     # تولید فرانت‌اند از frontend/src به frontend/www
```

پس از تغییرات ارتقا، هر دو فرمان بالا باید بدون خطا اجرا شوند. فایل‌های `frontend/www/` فقط خروجی Build هستند؛ آن‌ها را دستی ویرایش نکنید.

## محدودیت‌های آگاهانهٔ نسخهٔ اول (MVP)

- ذخیره‌سازی در یک فایل JSON است؛ برای ≤۱۰۰ کاربر کافی و ساده است. اجرای بیش از یک پروسه/نمونه از سرور پشتیبانی نمی‌شود.
- نام فرستنده در هر پیام هنگام ارسال ذخیره می‌شود؛ تغییر نام نمایشی روی پیام‌های قبلی اثر نمی‌گذارد.
- اعلان Push وب با Web Push/VAPID اختیاری است و تا زمانی که کلیدها و HTTPS تنظیم نشوند خاموش می‌ماند. این تنظیمات به‌خودی‌خود Push بومی APK اندروید را فعال نمی‌کنند؛ برای Push بومی باید integration مخصوص Capacitor اضافه شود.
- متن‌های دری بر پایهٔ فارسی با واژگان دری نوشته شده‌اند؛ بازبینی توسط یک دری‌زبان توصیه می‌شود (فایل `frontend/src/js/i18n.js`).


---

## ارتقاهای Shadow و پیکربندی قابلیت‌های اختیاری

### پروفایل و پنل ادمین

هر حساب آواتار رنگی پیش‌فرض و نام نمایشی دارد. در تنظیمات می‌توان نام و رنگ آواتار را تغییر داد. پنل ادمین جست‌وجو و فیلتر کاربران، آمار آنلاین/کل/بن‌شده، سوابق عملیات مدیریتی و مدیریت کلیدهای API را فراهم می‌کند. ساختار JSON قبلی هنگام بارگذاری به‌صورت سازگار مقدارهای پیش‌فرض جدید را می‌گیرد؛ لازم نیست فایل دادهٔ قدیمی را دستی پاک کنید.

### اعلان‌ها و Web Push

اعلان داخل اپ مستقل از Push کار می‌کند. اعلان سیستم صفحهٔ فعال/پس‌زمینه به اجازهٔ صریح کاربر و پشتیبانی مرورگر نیاز دارد. Push در زمانی که صفحه بسته است فقط پس از تنظیم واقعی Web Push با Service Worker و VAPID قابل استفاده است؛ HTTPS لازم است و همهٔ مرورگرها یا WebViewها رفتار یکسانی ندارند. متن پیام در Push به‌صورت پیش‌فرض افشا نمی‌شود.

۱. کلیدها را در محیط سرور بسازید:

```bash
cd backend
node scripts/generate-vapid.js
```

خروجی شامل کلید عمومی و خصوصی است. آن‌ها را فقط در متغیرهای محیطی سرور ذخیره کنید؛ به مخزن، README، `frontend/.env` یا مرورگر منتقل نکنید.

۲. در backend `.env` تنظیم کنید:

```dotenv
WEB_PUSH_ENABLED=1
WEB_PUSH_VAPID_PUBLIC_KEY=...کلید-عمومی...
WEB_PUSH_VAPID_PRIVATE_KEY=...کلید-خصوصی...
WEB_PUSH_SUBJECT=mailto:admin@example.com
WEB_PUSH_TIMEOUT_MS=8000
```

۳. سرور را با HTTPS در دسترس قرار دهید. کاربر باید در تنظیمات داخل اپ گزینهٔ اعلان سیستم را خودش فعال کند تا مرورگر اجازه و در صورت سازگاری، اشتراک Push ایجاد کند. `WEB_PUSH_SUBJECT` باید راه تماس معتبر مدیر باشد. کلیدها باید از یک جفت ساخته شده باشند.

برای APK/Android WebView، اعلان محلی یا Push بومی تضمین نمی‌شود؛ این نسخه پلاگین Push بومی Capacitor را اضافه نمی‌کند. برای Push بومی اندروید، پیکربندی FCM و پلاگین رسمی/سازگار پروژه در مرحله‌ای جداگانه لازم است.

### دستیار هوش مصنوعی

این نسخه یک endpoint سازگار با ساختار Chat Completions فراهم می‌کند؛ URL باید متعلق به سرویس‌دهنده‌ای باشد که همین قالب درخواست را می‌پذیرد. تا زمانی که همهٔ مقادیر زیر تنظیم نشده باشند، قابلیت خاموش می‌ماند و رابط پیام «پیکربندی نشده» نشان می‌دهد:

```dotenv
AI_ENABLED=1
AI_API_URL=https://provider.example/v1/chat/completions
AI_API_KEY=کلید-فقط-سمت-سرور
AI_MODEL=model-name
AI_TIMEOUT_MS=15000
```

مقدارهای `example` نمونه‌اند و endpoint واقعی نیستند. کلید واقعی را فقط در محیط سرور بگذارید. متن‌هایی که کاربر به دستیار می‌فرستد برای تولید پاسخ به سرویس AI تعیین‌شده منتقل می‌شوند؛ پیش از استفاده، سیاست حریم خصوصی همان سرویس را بررسی کنید. تاریخچهٔ AI در این نسخه به‌صورت دائمی در JSON ذخیره نمی‌شود.

### API عمومی امن

کلید API از پنل ادمین ساخته می‌شود؛ متن کامل آن فقط یک بار نمایش داده می‌شود، پس همان موقع آن را در محل امن کپی کنید. مقدار خام کلید در فایل داده نگهداری نمی‌شود و hash آن ذخیره می‌شود. کلید را revoke کنید تا دسترسی‌اش قطع شود. هر کلید scope جداگانه دارد.

- `GET /api/v1/health` — وضعیت سادهٔ سرویس، بدون نیاز به کلید.
- `GET /api/v1/messages?limit=50` — خواندن پیام‌های مجاز؛ نیازمند scope `messages:read`.
- `GET /api/v1/announcements` — خواندن اطلاعیه‌ها؛ نیازمند scope `announcements:read`.
- `POST /api/v1/messages` — ارسال پیام به گروه؛ نیازمند scope `messages:write`.

نمونهٔ درخواست:

```bash
curl -H 'X-API-Key: YOUR_API_KEY' \
  'https://chat.example.com/api/v1/messages?limit=20'

curl -X POST 'https://chat.example.com/api/v1/messages' \
  -H 'X-API-Key: YOUR_API_KEY' -H 'Content-Type: application/json' \
  -d '{"text":"Message from approved integration"}'
```

`YOUR_API_KEY` را با کلید واقعیِ ساخته‌شده در پنل جایگزین کنید؛ آن را در JavaScript فرانت‌اند قرار ندهید. مجوزها سمت سرور بررسی و درخواست‌های هر کلید rate-limit می‌شوند.

### Telegram Bot API رسمی

در BotFather بات بسازید، بات را فقط به گروه مقصد اضافه کنید، bot token و chat ID همان مقصد را در محیط سرور تنظیم کنید، سپس برای webhook آدرس HTTPS عمومی بدهید و secret را هم در پیکربندی Telegram و هم متغیر سرور یکسان قرار دهید:

```dotenv
TELEGRAM_ENABLED=1
TELEGRAM_BOT_TOKEN=...
TELEGRAM_WEBHOOK_SECRET=یک-راز-طولانی-تصادفی
TELEGRAM_CHAT_ID=-100...
```

Webhook مسیر `POST /api/integrations/telegram/webhook` دارد؛ Telegram باید هدر رسمی `X-Telegram-Bot-Api-Secret-Token` را بفرستد. برنامه فقط متن چت تنظیم‌شده را bridge می‌کند. برای ارسال رو به Telegram، نام و chat ID گروه مقصد باید صحیح باشند. با نبود متغیرها integration خاموش می‌ماند. مستندات رسمی: https://core.telegram.org/bots/api و https://core.telegram.org/bots/webhooks

### WhatsApp Business Platform / Cloud API رسمی Meta

فقط API رسمی WhatsApp Business/Cloud API پشتیبانی می‌شود، نه شبیه‌سازی WhatsApp Web یا حساب شخصی. به Meta Business Portfolio، WhatsApp Business Account، شمارهٔ واجدشرایط، access token و webhook قابل دسترس با HTTPS نیاز دارید. مقادیر زیر فقط در محیط سرور قرار می‌گیرند:

```dotenv
WHATSAPP_ENABLED=1
WHATSAPP_ACCESS_TOKEN=...
WHATSAPP_PHONE_NUMBER_ID=...
WHATSAPP_VERIFY_TOKEN=یک-راز-جداگانه
WHATSAPP_APP_SECRET=...
WHATSAPP_TO=شماره-مقصد-در-قالب-موردنیاز-API
WHATSAPP_API_VERSION=v25.0
```

در داشبورد Meta، webhook را روی `/api/integrations/whatsapp/webhook` تنظیم کنید و فیلد messages را مشترک شوید. سرور challenge تأیید webhook را پاسخ می‌دهد و POSTها را با HMAC امضای Meta بررسی می‌کند. پیام‌های متنی فقط bridge می‌شوند و رویدادهای تکراری نادیده گرفته می‌شوند. برای جلوگیری از ارسال ناخواسته، متن آزاد خروجی تا وقتی یک پیام ورودیِ تأییدشده از همان `WHATSAPP_TO` دریافت نشده باشد، ارسال نمی‌شود؛ این پنجره پس از ۲۴ ساعت بسته می‌شود و پس از راه‌اندازی مجدد سرور نیز به‌صورت fail-closed بسته می‌ماند. قالب‌های تأییدشده برای پیام‌های خارج از پنجره در این نسخه پیاده نشده‌اند. رعایت رضایت کاربر و سیاست رسمی پیام‌رسانی همچنان الزامی است. پیش از deployment نسخهٔ API و قواعد فعلی را در مرجع رسمی بازبینی کنید: https://developers.facebook.com/docs/whatsapp/cloud-api/

### تست و حدود واقعی

```bash
npm test
npm run build
node --check backend/src/app.js
node --check backend/src/webpush.js
node --check frontend/src/js/main.js
```

تست‌ها mock/local هستند؛ تست واحد به معنی اثبات ارسال واقعی به Telegram، Meta یا ارائه‌دهندهٔ AI نیست. بدون credential واقعی و URL HTTPS عمومی، webhookها و Push نهایی از اینترنت قابل تأیید نیستند. Web Push با تست‌های ساخت کلید، امضای VAPID، رمزنگاری payload و مدیریت subscription بررسی می‌شود، نه با یک push واقعی به دستگاه. ساخت APK فقط وقتی قابل گزارش است که JDK/Android SDK/Gradle و تنظیم `SHADOW_API_URL` در محیط موجود باشد.
